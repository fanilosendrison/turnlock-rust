#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
import re
import subprocess
import sys
from typing import Any

import yaml

from proto_ring_executable_binding import (
    ProtoRingExecutableError,
    from_structured_value,
    invoke_compat_result,
    to_structured_value,
)

ROOT = Path(__file__).resolve().parents[1]


class AdrMetadataError(ValueError):
    """A native generic ADR operation rejected the requested value."""


def _native(operation: str, payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return invoke_compat_result(ROOT, operation, payload)
    except ProtoRingExecutableError as error:
        raise AdrMetadataError(str(error)) from error


def _source_bytes(source: Path | bytes) -> bytes:
    return source.read_bytes() if isinstance(source, Path) else source


def _parse(mode: str, source: Path | bytes) -> dict[str, Any]:
    return _native(
        "adr-metadata.parse",
        {"mode": mode, "bytes_hex": _source_bytes(source).hex()},
    )


def configured_profile_path(root: Path) -> Path:
    value = invoke_compat_result(
        ROOT,
        "canonical-adr.resolve",
        {"mode": "configured_profile_path", "repository": str(root)},
    )
    return root / value["relative_path"]


def load_yaml(source: Path | bytes) -> object:
    return from_structured_value(_parse("load_yaml", source)["structured"])


def load_json(source: Path | bytes) -> object:
    return from_structured_value(_parse("load_json", source)["structured"])


def parse_adr(path: Path) -> tuple[dict[str, Any], bytes]:
    value = _parse("parse_adr", path)
    metadata = from_structured_value(value["metadata"])
    if not isinstance(metadata, dict):
        raise AdrMetadataError("ADR metadata must be a mapping")
    return metadata, bytes.fromhex(value["body_hex"])


def decision_body_bytes(data: bytes) -> bytes:
    return bytes.fromhex(_parse("decision_body", data)["body_hex"])


def _h1(data: bytes) -> str:
    return _parse("h1", data)["text"]


def preserved_payload_bytes(data: bytes) -> bytes:
    return bytes.fromhex(_parse("preserved_payload", data)["payload_hex"])


def sha256_hex(data: bytes) -> str:
    return _parse("sha256", data)["sha256"]


def repository_path(root: Path, relative: object) -> Path:
    try:
        value = invoke_compat_result(
            ROOT,
            "adr-metadata.repository-path",
            {"repository": str(root), "relative": relative},
        )
    except ProtoRingExecutableError as error:
        raise AdrMetadataError(str(error)) from error
    return root.resolve() / value["relative"]


def _validation(mode: str, **values: object) -> dict[str, Any]:
    payload = {"mode": mode}
    payload.update({name: to_structured_value(value) for name, value in values.items()})
    return _native("adr-metadata.validation", payload)


def _require_mapping(value: object, location: str) -> dict[str, Any]:
    try:
        decoded = from_structured_value(
            _validation("require_mapping", value=value)["value"]
        )
    except (AdrMetadataError, ProtoRingExecutableError) as error:
        raise AdrMetadataError(f"{location}: {error}") from error
    if not isinstance(decoded, dict):
        raise AdrMetadataError(f"{location}: required mapping result is invalid")
    return decoded


def _require_string(value: object, location: str) -> str:
    try:
        return _validation("require_string", value=value)["text"]
    except AdrMetadataError as error:
        raise AdrMetadataError(f"{location}: {error}") from error


def _require_string_list(value: object, location: str) -> list[str]:
    try:
        return _validation("require_string_list", value=value)["items"]
    except AdrMetadataError as error:
        raise AdrMetadataError(f"{location}: {error}") from error


def relation_target_errors(
    *, source_id: str, relation_type: str, targets: list[str], known_ids: set[str]
) -> list[str]:
    value = _validation(
        "relation_target_errors",
        source_id=source_id,
        relation_type=relation_type,
        targets=targets,
        known_ids=sorted(known_ids),
    )
    return [
        f"{relation_type}: self reference"
        if error["category"] == "self_reference"
        else f"{relation_type}: missing target {error['target']}"
        for error in value["errors"]
    ]


def schema_errors(
    value: object, schema: object, overlay_schema: object
) -> list[str]:
    result = _validation(
        "schema_errors",
        value=value,
        schema=schema,
        overlay_schema=overlay_schema,
    )
    return [
        f"{error['schema']} schema is invalid: error at {error['path']}"
        for error in result["errors"]
    ]
PROFILE_VERSION = "0.1.0"
RELATION_TYPES = ("clarifies", "amends", "supersedes", "confirms")
ANNOTATED_TRACE_ENTRY_START = re.compile(
    r"(?m)^\s*(?P<ordinal>\d+)\.\s+\[(?P<id>ADR-(?P<number>[0-9]{3})):"
)
ANNOTATED_TRACE_ENTRY_HEADER = re.compile(
    r"(?s)^\s*(?P<ordinal>\d+)\.\s+\[(?P<id>ADR-[0-9]{3}):\s*(?P<title>.*?)\]"
    r"(?:\((?P<inline>[^)]+)\)|\[(?P<reference>[^\]]+)\])"
)
ANNOTATED_TRACE_STATUS = re.compile(r"\s*—\s*\*\*([^*]+)\*\*")
MARKDOWN_LINK_DEFINITION = re.compile(r"(?m)^\s*\[([^\]]+)\]:\s*(\S+)\s*$")


def load_profile(root: Path) -> dict[str, Any]:
    profile_path = configured_profile_path(root)
    profile = _require_mapping(load_yaml(profile_path), str(profile_path))
    if profile.get("profile_version") != PROFILE_VERSION:
        raise AdrMetadataError(
            f"{profile_path} must use profile_version {PROFILE_VERSION}"
        )

    canonical = _require_mapping(profile.get("canonical_schema"), "canonical_schema")
    for key in (
        "id",
        "repository",
        "source_path",
        "source_commit",
        "sha256",
        "vendored_path",
    ):
        _require_string(canonical.get(key), f"canonical_schema.{key}")
    if not re.fullmatch(r"[0-9a-f]{40}", canonical["source_commit"]):
        raise AdrMetadataError("canonical_schema.source_commit must be a full Git SHA")
    if not re.fullmatch(r"[0-9a-f]{64}", canonical["sha256"]):
        raise AdrMetadataError("canonical_schema.sha256 must be lowercase SHA-256")
    if not canonical["repository"].startswith("https://"):
        raise AdrMetadataError("canonical_schema.repository must use HTTPS")

    overlay = _require_mapping(profile.get("local_overlay"), "local_overlay")
    _require_string(overlay.get("id"), "local_overlay.id")
    overlay_hash = _require_string(overlay.get("sha256"), "local_overlay.sha256")
    if not re.fullmatch(r"[0-9a-f]{64}", overlay_hash):
        raise AdrMetadataError("local_overlay.sha256 must be lowercase SHA-256")
    _require_string(overlay.get("path"), "local_overlay.path")

    repository = _require_mapping(profile.get("repository"), "repository")
    for key in (
        "domain",
        "adr_directory",
        "filename_pattern",
        "id_pattern",
        "h1_separator",
    ):
        _require_string(repository.get(key), f"repository.{key}")
    if not isinstance(repository.get("id_width"), int) or repository["id_width"] < 1:
        raise AdrMetadataError("repository.id_width must be a positive integer")
    if repository.get("require_contiguous_ids") is not True:
        raise AdrMetadataError("repository.require_contiguous_ids must be true")
    if repository.get("retain_allocated_ids") is not True:
        raise AdrMetadataError("repository.retain_allocated_ids must be true")
    non_adr = _require_string_list(
        repository.get("non_adr_markdown"), "repository.non_adr_markdown"
    )
    if any(Path(name).name != name or not name.endswith(".md") for name in non_adr):
        raise AdrMetadataError(
            "repository.non_adr_markdown entries must be Markdown basenames"
        )
    try:
        re.compile(repository["filename_pattern"])
        re.compile(repository["id_pattern"])
    except re.error as error:
        raise AdrMetadataError(f"repository regex is invalid: {error}") from error

    legacy = _require_mapping(profile.get("legacy"), "legacy")
    _require_string_list(legacy.get("without_frontmatter"), "legacy.without_frontmatter")
    _require_string_list(legacy.get("null_dates"), "legacy.null_dates")

    generated_index = _require_mapping(profile.get("generated_index"), "generated_index")
    _require_string(generated_index.get("path"), "generated_index.path")
    if not isinstance(generated_index.get("required"), bool):
        raise AdrMetadataError("generated_index.required must be boolean")

    annotated = _require_mapping(profile.get("annotated_history"), "annotated_history")
    _require_string(annotated.get("path"), "annotated_history.path")
    if not isinstance(annotated.get("required"), bool):
        raise AdrMetadataError("annotated_history.required must be boolean")
    _require_string(annotated.get("start_marker"), "annotated_history.start_marker")
    _require_string(annotated.get("end_marker"), "annotated_history.end_marker")
    if annotated["start_marker"] == annotated["end_marker"]:
        raise AdrMetadataError(
            "annotated_history start and end markers must differ"
        )

    migration = _require_mapping(profile.get("migration_evidence"), "migration_evidence")
    _require_string(migration.get("path"), "migration_evidence.path")
    if not isinstance(migration.get("required"), bool):
        raise AdrMetadataError("migration_evidence.required must be boolean")
    _require_string_list(migration.get("ids"), "migration_evidence.ids")
    baseline = migration.get("baseline_commit")
    if migration["required"]:
        if not isinstance(baseline, str) or not re.fullmatch(r"[0-9a-f]{40}", baseline):
            raise AdrMetadataError(
                "migration_evidence.baseline_commit must be a full Git SHA when required"
            )
    elif baseline is not None:
        raise AdrMetadataError(
            "migration_evidence.baseline_commit must be null when evidence is optional"
        )

    commands = _require_mapping(profile.get("commands"), "commands")
    _require_string(commands.get("check"), "commands.check")
    _require_string(commands.get("render"), "commands.render")
    return profile


def _derived_identity(
    path: Path, filename_pattern: re.Pattern[str], id_width: int
) -> tuple[str, str, int]:
    match = filename_pattern.fullmatch(path.name)
    if match is None:
        raise AdrMetadataError("filename does not match repository.filename_pattern")
    number_text = match.group("number")
    slug = match.group("slug")
    if len(number_text) != id_width:
        raise AdrMetadataError(f"filename number must use exactly {id_width} digits")
    number = int(number_text)
    if number < 1:
        raise AdrMetadataError("ADR number must be positive")
    return f"ADR-{number_text}", slug, number


def _load_schemas(
    root: Path, profile: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any], list[str]]:
    errors: list[str] = []
    canonical = profile["canonical_schema"]
    try:
        vendored_path = repository_path(root, canonical["vendored_path"])
        vendored_bytes = vendored_path.read_bytes()
    except (AdrMetadataError, OSError) as error:
        return {}, {}, [f"canonical schema: {error}"]

    actual_hash = sha256_hex(vendored_bytes)
    if actual_hash != canonical["sha256"]:
        errors.append(
            "vendored canonical schema SHA-256 mismatch: "
            f"expected {canonical['sha256']}, found {actual_hash}"
        )
    try:
        base = json.loads(vendored_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        errors.append(f"vendored canonical schema is invalid JSON: {error}")
        base = {}
    if not isinstance(base, dict):
        errors.append("vendored canonical schema must be a JSON object")
        base = {}
    if base.get("$id") != canonical["id"]:
        errors.append(
            "vendored canonical schema $id mismatch: "
            f"expected {canonical['id']}, found {base.get('$id')}"
        )

    try:
        overlay_path = repository_path(root, profile["local_overlay"]["path"])
        overlay_bytes = overlay_path.read_bytes()
        overlay = json.loads(overlay_bytes.decode("utf-8"))
    except (AdrMetadataError, OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        errors.append(f"local overlay: {error}")
        overlay_bytes = b""
        overlay = {}
    if not isinstance(overlay, dict):
        errors.append("local overlay schema must be a JSON object")
        overlay = {}
    overlay_hash = sha256_hex(overlay_bytes)
    if overlay_hash != profile["local_overlay"]["sha256"]:
        errors.append(
            "local overlay SHA-256 mismatch: expected "
            f"{profile['local_overlay']['sha256']}, found {overlay_hash}"
        )
    if not overlay:
        errors.append("local overlay must be a non-empty JSON Schema")
    if overlay.get("$id") != profile["local_overlay"]["id"]:
        errors.append(
            "local overlay $id mismatch: expected "
            f"{profile['local_overlay']['id']}, found {overlay.get('$id')}"
        )

    properties = overlay.get("properties")
    required = overlay.get("required")
    if not isinstance(properties, dict):
        properties = {}
    if not isinstance(required, list):
        required = []
    expected_constraints = {
        "adr_profile_version": ("const", profile["profile_version"]),
        "domain": ("const", profile["repository"]["domain"]),
        "id": ("pattern", profile["repository"]["id_pattern"]),
    }
    for field, (keyword, expected) in expected_constraints.items():
        constraint = properties.get(field)
        if not isinstance(constraint, dict) or constraint.get(keyword) != expected:
            errors.append(f"local overlay {field} constraint mismatch")
        if field not in required:
            errors.append(f"local overlay must require {field}")
    return base, overlay, errors


def _git_baseline_blob(root: Path, commit: str, relative_path: str) -> bytes:
    result = subprocess.run(
        ["git", "-C", str(root), "show", f"{commit}:{relative_path}"],
        check=False,
        capture_output=True,
    )
    if result.returncode != 0:
        detail = result.stderr.decode("utf-8", errors="replace").strip()
        raise AdrMetadataError(
            f"baseline commit {commit} cannot provide {relative_path}: {detail}"
        )
    return result.stdout


def _migration_evidence_errors(
    root: Path,
    profile: dict[str, Any],
    records_by_id: dict[str, dict[str, Any]],
) -> list[str]:
    section = profile["migration_evidence"]
    if not section["required"]:
        return []
    errors: list[str] = []
    try:
        path = repository_path(root, section["path"])
        evidence = _require_mapping(load_yaml(path), section["path"])
    except AdrMetadataError as error:
        return [f"migration evidence: {error}"]

    baseline = section["baseline_commit"]
    if evidence.get("schema_version") != 1:
        errors.append("migration evidence must use schema_version 1")
    if evidence.get("profile_version") != profile["profile_version"]:
        errors.append("migration evidence profile_version mismatch")
    if evidence.get("baseline_commit") != baseline:
        errors.append("migration evidence baseline_commit does not match profile")

    ancestor = subprocess.run(
        ["git", "-C", str(root), "merge-base", "--is-ancestor", baseline, "HEAD"],
        check=False,
        capture_output=True,
    )
    if ancestor.returncode != 0:
        detail = ancestor.stderr.decode("utf-8", errors="replace").strip()
        errors.append(
            f"migration baseline commit {baseline} is unavailable or not an ancestor"
            + (f": {detail}" if detail else "")
        )

    expected = set(section["ids"])
    entries = evidence.get("records")
    if not isinstance(entries, list):
        return errors + ["migration evidence records must be a list"]

    seen: set[str] = set()
    for entry in entries:
        if not isinstance(entry, dict):
            errors.append("migration evidence record must be a mapping")
            continue
        adr_id = entry.get("id")
        if not isinstance(adr_id, str):
            errors.append("migration evidence record id must be a string")
            continue
        if adr_id in seen:
            errors.append(f"duplicate migration evidence record {adr_id}")
        seen.add(adr_id)
        record = records_by_id.get(adr_id)
        if record is None:
            errors.append(f"migration evidence references missing {adr_id}")
            continue
        if entry.get("path") != record["relative_path"]:
            errors.append(f"migration evidence {adr_id} path mismatch")
            continue

        try:
            baseline_bytes = _git_baseline_blob(
                root, baseline, record["relative_path"]
            )
            baseline_payload = preserved_payload_bytes(baseline_bytes)
            current_payload = preserved_payload_bytes(record["data"])
            baseline_body = decision_body_bytes(baseline_bytes)
        except AdrMetadataError as error:
            errors.append(f"migration evidence {adr_id}: {error}")
            continue

        if baseline_payload != baseline_bytes:
            errors.append(
                f"migration evidence {adr_id}: baseline file must begin at its H1"
            )
        if current_payload != baseline_bytes:
            errors.append(
                f"migration evidence {adr_id}: H1-to-EOF payload differs from baseline"
            )

        expected_hashes = {
            "baseline_file_sha256": sha256_hex(baseline_bytes),
            "migrated_payload_sha256": sha256_hex(current_payload),
            "before_decision_body_sha256": sha256_hex(baseline_body),
            "after_decision_body_sha256": sha256_hex(record["body"]),
        }
        for field, expected_hash in expected_hashes.items():
            if entry.get(field) != expected_hash:
                errors.append(
                    f"migration evidence {adr_id} {field} does not match actual bytes"
                )

    if seen != expected:
        missing = sorted(expected - seen)
        extra = sorted(seen - expected)
        if missing:
            errors.append("migration evidence missing IDs: " + ", ".join(missing))
        if extra:
            errors.append("migration evidence has unexpected IDs: " + ", ".join(extra))
    return errors


def _annotated_history_errors(
    root: Path,
    profile: dict[str, Any],
    records_by_id: dict[str, dict[str, Any]],
) -> list[str]:
    section = profile["annotated_history"]
    if not section["required"]:
        return []
    errors: list[str] = []
    try:
        history_path = repository_path(root, section["path"])
        text = history_path.read_text(encoding="utf-8")
    except (AdrMetadataError, OSError, UnicodeError) as error:
        return [f"annotated ADR history: {error}"]

    start_marker = section["start_marker"]
    end_marker = section["end_marker"]
    if text.count(start_marker) != 1:
        errors.append("annotated ADR history start marker missing or duplicated")
    if text.count(end_marker) != 1:
        errors.append("annotated ADR history end marker missing or duplicated")
    if errors:
        return errors

    start_index = text.index(start_marker) + len(start_marker)
    end_index = text.index(end_marker)
    if start_index > end_index:
        return ["annotated ADR history start marker must precede end marker"]
    block = text[start_index:end_index]

    definitions = dict(MARKDOWN_LINK_DEFINITION.findall(text))
    matches = list(ANNOTATED_TRACE_ENTRY_START.finditer(block))
    entries: list[dict[str, Any]] = []
    for index, match in enumerate(matches):
        next_start = (
            matches[index + 1].start() if index + 1 < len(matches) else len(block)
        )
        entry_text = block[match.start() : next_start]
        header = ANNOTATED_TRACE_ENTRY_HEADER.match(entry_text)
        if header is None:
            errors.append(
                f"annotated ADR history {match.group('id')} entry is malformed"
            )
            continue
        inline_target = header.group("inline")
        reference_label = header.group("reference")
        if inline_target is not None:
            target = inline_target.strip()
        elif reference_label is not None:
            target = definitions.get(reference_label.strip())
        else:
            target = None
        status_match = ANNOTATED_TRACE_STATUS.match(entry_text[header.end() :])
        status = status_match.group(1).strip() if status_match is not None else None
        annotation = (
            entry_text[header.end() + status_match.end() :]
            if status_match is not None
            else ""
        )
        entries.append(
            {
                "ordinal": int(header.group("ordinal")),
                "id": header.group("id"),
                "number": int(header.group("id").split("-")[1]),
                "title": " ".join(header.group("title").split()),
                "target": target,
                "status": status,
                "annotation": annotation,
            }
        )

    canonical_records = sorted(
        records_by_id.values(), key=lambda record: record.get("number", 0)
    )
    canonical_ids = [record["id"] for record in canonical_records]
    discovered_ids = [entry["id"] for entry in entries]
    counts = Counter(discovered_ids)
    for adr_id, count in sorted(counts.items()):
        if count > 1:
            errors.append(f"annotated ADR history contains duplicate {adr_id}")
    for adr_id in canonical_ids:
        if adr_id not in counts:
            errors.append(f"annotated ADR history missing {adr_id}")
    for adr_id in sorted(set(discovered_ids) - set(canonical_ids)):
        errors.append(f"annotated ADR history contains unknown {adr_id}")
    if discovered_ids != canonical_ids:
        errors.append("annotated ADR history coverage/order mismatch")

    for entry in entries:
        adr_id = entry["id"]
        if entry["ordinal"] != entry["number"]:
            errors.append(f"annotated ADR history {adr_id} list ordinal mismatch")
        record = records_by_id.get(adr_id)
        if record is None:
            continue
        metadata = record.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {}
        name = metadata.get("name")
        if isinstance(name, str) and entry["title"] != " ".join(name.split()):
            errors.append(f"annotated ADR history {adr_id} title mismatch")
        if entry["target"] != record["path"].name:
            errors.append(f"annotated ADR history {adr_id} link target mismatch")
        status = metadata.get("status")
        if isinstance(status, str):
            if not isinstance(entry["status"], str) or (
                entry["status"].lower() != status.lower()
            ):
                errors.append(f"annotated ADR history {adr_id} status mismatch")
        if isinstance(entry["status"], str) and not re.search(
            r"\w", entry["annotation"]
        ):
            errors.append(f"annotated ADR history {adr_id} has no narrative annotation")
    return errors


def collect_errors(root: Path, *, check_generated: bool = True) -> list[str]:
    root = root.resolve()
    errors: list[str] = []
    try:
        profile = load_profile(root)
    except AdrMetadataError as error:
        return [str(error)]

    base_schema, overlay_schema, schema_load_errors = _load_schemas(root, profile)
    errors.extend(schema_load_errors)
    repository = profile["repository"]
    try:
        adr_directory = repository_path(root, repository["adr_directory"])
    except AdrMetadataError as error:
        return errors + [str(error)]
    filename_pattern = re.compile(repository["filename_pattern"])
    id_pattern = re.compile(repository["id_pattern"])
    id_width = repository["id_width"]
    separator = repository["h1_separator"]
    legacy_ids = set(profile["legacy"]["without_frontmatter"])
    null_date_ids = set(profile["legacy"]["null_dates"])

    excluded_markdown = set(repository["non_adr_markdown"])
    paths = sorted(
        path
        for path in adr_directory.glob("*.md")
        if path.name not in excluded_markdown
    )
    records_by_id: dict[str, dict[str, Any]] = {}
    legacy_found: set[str] = set()
    numbers: list[int] = []

    for path in paths:
        prefix = path.relative_to(root).as_posix()
        try:
            derived_id, _filename_slug, number = _derived_identity(
                path, filename_pattern, id_width
            )
        except AdrMetadataError as error:
            errors.append(f"{prefix}: {error}")
            continue
        numbers.append(number)
        if derived_id in records_by_id:
            errors.append(f"duplicate ADR identity {derived_id}")
            continue

        try:
            data = path.read_bytes()
            body = decision_body_bytes(data)
            heading = _h1(data)
        except (OSError, UnicodeError, AdrMetadataError) as error:
            errors.append(f"{prefix}: {error}")
            continue

        record = {
            "id": derived_id,
            "number": number,
            "path": path,
            "relative_path": prefix,
            "data": data,
            "body": body,
            "metadata": None,
        }
        records_by_id[derived_id] = record

        if not data.startswith(b"---\n"):
            legacy_found.add(derived_id)
            if derived_id not in legacy_ids:
                errors.append(
                    f"{prefix}: {derived_id} is frontmatter-free but not allowlisted"
                )
            expected_prefix = derived_id + separator
            if not heading.startswith(expected_prefix):
                errors.append(
                    f"{prefix}: H1 must begin with {expected_prefix!r}, found {heading!r}"
                )
            continue

        if derived_id in legacy_ids:
            errors.append(
                f"{prefix}: stale legacy without_frontmatter entry {derived_id}"
            )
        try:
            metadata, parsed_body = parse_adr(path)
        except AdrMetadataError as error:
            errors.append(f"{prefix}: {error}")
            continue
        record["metadata"] = metadata
        record["body"] = parsed_body
        for error in schema_errors(metadata, base_schema, overlay_schema):
            errors.append(f"{prefix}: {error}")

        metadata_id = metadata.get("id")
        if metadata_id != derived_id:
            errors.append(
                f"{prefix}: metadata id {metadata_id!r} does not match {derived_id}"
            )
        elif not id_pattern.fullmatch(metadata_id):
            errors.append(f"{prefix}: metadata id violates repository.id_pattern")

        name = metadata.get("name")
        if isinstance(name, str):
            expected_h1 = derived_id + separator + name
            if heading != expected_h1:
                errors.append(
                    f"{prefix}: H1 {heading!r} does not equal {expected_h1!r}"
                )

        actual_body_hash = sha256_hex(parsed_body)
        if metadata.get("decision_body_sha256") != actual_body_hash:
            errors.append(
                f"{prefix}: decision_body_sha256 mismatch; expected {actual_body_hash}"
            )

        date = metadata.get("date")
        if date is None and derived_id not in null_date_ids:
            errors.append(f"{prefix}: null date is not allowlisted for {derived_id}")
        if date is not None and derived_id in null_date_ids:
            errors.append(f"{prefix}: stale legacy null_dates entry {derived_id}")

    all_ids = set(records_by_id)
    for adr_id in sorted(legacy_ids - legacy_found):
        errors.append(f"stale legacy without_frontmatter entry {adr_id}")
    for adr_id in sorted(null_date_ids - all_ids):
        errors.append(f"stale legacy null_dates entry {adr_id}")

    if len(numbers) != len(set(numbers)):
        errors.append("duplicate ADR numbers")
    if numbers:
        expected_numbers = list(range(1, max(numbers) + 1))
        if sorted(numbers) != expected_numbers:
            errors.append(
                "ADR IDs must be contiguous from 1 through " + str(max(numbers))
            )

    for adr_id, record in sorted(records_by_id.items()):
        metadata = record["metadata"]
        if not isinstance(metadata, dict):
            continue
        relations = metadata.get("relations")
        if not isinstance(relations, dict):
            continue
        for relation_type in RELATION_TYPES:
            targets = relations.get(relation_type)
            if not isinstance(targets, list):
                continue
            for relation_error in relation_target_errors(
                source_id=adr_id,
                relation_type=relation_type,
                targets=targets,
                known_ids=all_ids,
            ):
                errors.append(f"{record['relative_path']}: {relation_error}")

    errors.extend(_migration_evidence_errors(root, profile, records_by_id))
    errors.extend(_annotated_history_errors(root, profile, records_by_id))

    generated = profile["generated_index"]
    if check_generated and generated["required"]:
        try:
            expected_index = render_index(root)
            index_path = repository_path(root, generated["path"])
            actual_index = index_path.read_text(encoding="utf-8")
            if actual_index != expected_index:
                errors.append(
                    f"generated ADR index is stale; run {profile['commands']['render']}"
                )
        except (AdrMetadataError, OSError, UnicodeError) as error:
            errors.append(f"generated ADR index: {error}")
    return errors


def _structured_records(root: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    profile = load_profile(root)
    adr_directory = repository_path(root, profile["repository"]["adr_directory"])
    filename_pattern = re.compile(profile["repository"]["filename_pattern"])
    id_width = profile["repository"]["id_width"]
    records: list[dict[str, Any]] = []
    for path in sorted(adr_directory.glob("adr-*.md")):
        adr_id, _, number = _derived_identity(path, filename_pattern, id_width)
        try:
            metadata, body = parse_adr(path)
        except AdrMetadataError as error:
            raise AdrMetadataError(
                f"cannot render while {adr_id} is unstructured: {error}"
            ) from error
        records.append(
            {
                "id": adr_id,
                "number": number,
                "path": path,
                "relative_path": path.relative_to(root).as_posix(),
                "metadata": metadata,
                "body": body,
            }
        )
    records.sort(key=lambda record: record["number"])
    return profile, records


def _markdown_cell(value: str) -> str:
    return value.replace("\\", "\\\\").replace("|", "\\|").replace("\n", "<br>")


def render_index(root: Path) -> str:
    profile, records = _structured_records(root.resolve())
    domain = profile["repository"]["domain"]
    lines = [
        "---",
        'okf_version: "1.0"',
        'kind: "KnowledgeAsset"',
        'asset_type: "generated-architecture-decision-index"',
        f'domain: "{domain}"',
        'severity: "strict"',
        'name: "Generated TURNLOCK Architecture Decision Record index"',
        "---",
        "",
        "# Generated TURNLOCK Architecture Decision Record index",
        "",
        "> Generated by `scripts/adr-metadata.py`. Do not edit manually.",
        "> Source frontmatter stores outgoing relations; incoming relations below",
        "> are derived projections complete only relative to recorded assertions.",
        "",
        "## Decisions",
        "",
        "| ID | Decision | Status | Date | Relation coverage | Governs |",
        "|---|---|---|---|---|---|",
    ]
    path_by_id = {record["id"]: record["path"].name for record in records}
    for record in records:
        metadata = record["metadata"]
        date = metadata["date"] if metadata["date"] is not None else "Unknown"
        governed_scopes = "<br>".join(
            _markdown_cell(scope) for scope in metadata["governs"]
        ) or "—"
        lines.append(
            f"| [{record['id']}]({record['path'].name}) | "
            f"{_markdown_cell(metadata['name'])} | {metadata['status']} | {date} | "
            f"{metadata['relation_completeness']} | {governed_scopes} |"
        )

    outgoing: list[tuple[str, str, str]] = []
    incoming: list[tuple[str, str, str]] = []
    inverse = {
        "clarifies": "clarified by",
        "amends": "amended by",
        "supersedes": "superseded by",
        "confirms": "confirmed by",
    }
    for record in records:
        relations = record["metadata"]["relations"]
        for relation_type in RELATION_TYPES:
            for target in relations[relation_type]:
                outgoing.append((record["id"], relation_type, target))
                incoming.append((target, inverse[relation_type], record["id"]))

    lines.extend(
        [
            "",
            "## Recorded outgoing relations",
            "",
            "| Source | Relation | Target |",
            "|---|---|---|",
        ]
    )
    if outgoing:
        for source, relation, target in sorted(outgoing):
            lines.append(
                f"| [{source}]({path_by_id[source]}) | {relation} | "
                f"[{target}]({path_by_id[target]}) |"
            )
    else:
        lines.append("| — | — | — |")

    lines.extend(
        [
            "",
            "## Derived incoming relations",
            "",
            "| Target | Relation | Source |",
            "|---|---|---|",
        ]
    )
    if incoming:
        for target, relation, source in sorted(incoming):
            lines.append(
                f"| [{target}]({path_by_id[target]}) | {relation} | "
                f"[{source}]({path_by_id[source]}) |"
            )
    else:
        lines.append("| — | — | — |")
    lines.append("")
    return "\n".join(lines)


def check_command(root: Path) -> int:
    errors = collect_errors(root)
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        print(f"ADR metadata: FAILED ({len(errors)} errors)", file=sys.stderr)
        return 1
    profile, records = _structured_records_if_possible(root)
    legacy_count = len(profile["legacy"]["without_frontmatter"])
    print(f"ADR metadata: OK ({len(records)} structured, {legacy_count} legacy)")
    return 0


def _structured_records_if_possible(
    root: Path,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    profile = load_profile(root)
    adr_directory = repository_path(root, profile["repository"]["adr_directory"])
    records: list[dict[str, Any]] = []
    for path in sorted(adr_directory.glob("adr-*.md")):
        if path.read_bytes().startswith(b"---\n"):
            metadata, body = parse_adr(path)
            records.append({"path": path, "metadata": metadata, "body": body})
    return profile, records


def render_command(root: Path) -> int:
    errors = collect_errors(root, check_generated=False)
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        print("ADR index rendering refused because source validation failed", file=sys.stderr)
        return 1
    try:
        profile = load_profile(root)
        rendered = render_index(root)
        output_path = repository_path(root, profile["generated_index"]["path"])
        output_path.write_text(rendered, encoding="utf-8", newline="\n")
    except (AdrMetadataError, OSError, UnicodeError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print(f"Rendered {output_path.relative_to(root)}")
    return 0


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate and render TURNLOCK ADR metadata")
    parser.add_argument("command", choices=("check", "render"))
    parser.add_argument("--root", type=Path, default=ROOT)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    arguments = parse_args(argv)
    root = arguments.root.resolve()
    if arguments.command == "check":
        return check_command(root)
    return render_command(root)


if __name__ == "__main__":
    raise SystemExit(main())
