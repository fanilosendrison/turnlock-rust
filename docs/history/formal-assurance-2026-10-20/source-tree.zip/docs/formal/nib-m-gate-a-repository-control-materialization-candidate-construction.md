---
okf_version: "1.0"
kind: "RuntimeArtifact"
format: "nib-module"
workspace: "turnlock-rust"
date: "2026-10-01"
step_id: 2
id: NIB-M-GATE-A-REPOSITORY-CONTROL-MATERIALIZATION-CANDIDATE-CONSTRUCTION
version: "2.1.2"
scope: gate-a-campaign-runner/repository-control/materialization-candidate-construction
status: active
consumers: [architect, coding-agent]
superseded_by: []
---

# NIB-M — Gate A Repository Control — Materialization and Candidate Construction

It consumes exactly:

```text
NIB-S-GATE-A-CAMPAIGN-RUNNER 13.0.3
NIB-M-GATE-A-CONTRACTS 1.4.0
NIB-M-GATE-A-ASSURANCE-LEDGER-REPOSITORY-PROJECTION-READINESS 1.0.1
NIB-M-GATE-A-REPOSITORY-CONTROL-PUBLICATION-REMOTE-RECOVERY 2.0.1
CampaignArtifactStore
DC-GIT-CLI-GATE-A-REPOSITORY-CONTROL
```

Version `2.1.2` synchronizes NIB-S `13.0.3` and M7-B `2.0.1`
with the Issue #78 generic-governance/exact-Git-operation boundary. Its
19 Git primitives, baseline object closure, bundle, canonical candidate,
tree/commit construction, repair/projection bytes, successor T, isolation,
replay and error behavior remain unchanged. This is construction
responsibility placement, not a Git CLI transport selection.

Version `2.1.1` is dependency/boundary synchronization with NIB-S `13.0.0`,
M0 `1.4.0`, and M7-B `1.0.0`. It changes no M7-A algorithm, public type,
candidate construction, Git primitive use, materialization, successor
projection, evidence, identity, recovery, or publication behavior. M7-A still
owns `T`; M7-B consumes that exact `T` and owns remote publication concerns.

Version `2.1.0` closes C9-F synchronization between the complete M5-D
assurance projection and M7-A mechanical candidate materialization. It closes:

```text
M0 canonical-runner-JSON ownership synchronization
exact P6/P8 assurance projection namespace validation
exact projection path/media-type validation
projection-content to canonical candidate-blob carrier conversion
raw Git-path overlap validation for combined repair plus projection
```

It changes none of the following:

```text
public M7-A type shape
CandidateConstructionRequest
CandidateSealResult
Git primitives
RepairIntent semantics
AssuranceRepositoryProjection semantics
candidate lineage
publication-successor algorithm
M7-B
M6
TURNLOCK product semantics
hostile-review protocol semantics
P6 behavior reinterpretation
P8 semantics
P8 activation
```

Version `2.0.7` was a dependency-only synchronization with NIB-S `10.0.0`. It
changed no M7-A algorithm, type, ownership, repair, materialization, candidate,
Git, recovery, or repository semantic.

Version `2.0.6` is a dependency-only / construction-only compatibility
synchronization with NIB-S `9.1.2`. It makes no execution algorithm change, no
provider change, no retry semantic change, no hard-limit change, no recovery
change, and no repository semantic change.

Version `2.0.5` is a dependency-only / construction-only compatibility
synchronization with NIB-S `9.1.1`. It changes no algorithm, type, provider,
recovery, or repository semantics.

Version `2.0.4` was a dependency-only compatibility synchronization with NIB-S
`9.1.0`. It changed no algorithm, type, or module invariant.

Version `2.0.3` is dependency-only synchronization with NIB-S `9.0.1`. No M7-A
repository, candidate, or materialization semantics change.

Version `2.0.2` was dependency-only compatibility synchronization with
NIB-S-GATE-A-CAMPAIGN-RUNNER `9.0.0`.

This Module Brief is implementation-construction authority only. It creates no
TURNLOCK product semantics, hostile-review protocol semantics, canonical formal
semantics, review evidence, or verification evidence.

## 1. Responsibility boundary

M7 is decomposed exactly as:

```text
M7 repository-control
├── M7-A materialization / candidate construction
└── M7-B publication / remote observation / recovery
```

M7-A owns exactly:

```text
repository inspection
baseline repository authority observation
publication-target identity resolution from local Git configuration
baseline raw-object acquisition
complete reachable closure rooted at C
closure purification
bundle-v3 baseline carrier
independent offline restore verification
baselineGitBasis
C0 candidate materialization
candidate canonical representation
Git path admissibility
candidate-to-tree projection
tree round-trip verification
exact RepairIntent approved-patch application
exact AssuranceRepositoryProjection mechanical application
assurance-only successor materialization
combined repair-plus-assurance successor materialization
assurance projection construction provenance
candidate sealing/evidence
deterministic publication-successor projection T
restart-safe local materialization of exact projected T
repository-inspection producer cause descriptors
```

M7-A does not own:

```text
Python validator invocation
Gate A semantic-subject mechanical derivation
hostile-review protocol/review-authority mechanical projection
M6 subject derivation
M6 review-authority projection
campaign currentness
assurance semantic interpretation
review finding interpretation
projection semantic selection
protocol selection
repair semantic sufficiency
RepairIntent qualification
authoritative candidate admission
remote predecessor P observation
P <= T proof
PublicationIntent construction/admission
publication WorkItem admission
Arm
remote ref mutation
already-current fresh remote observation
publication recovery
publication confirmation/non-application
published-repository post-publication qualification
OperationalBlocker identity
Operator Action Request identity
authoritative campaign state mutation
```

M7-B consumes the exact successor projection produced by M7-A. M7-B may verify
that projection and materialize its exact Git objects, but it may not derive
another successor, modify commit metadata, select another parent, or make
successor identity depend on current remote state.

### 1.1 Proto-ring governance versus Git baseline ownership

The mandatory proto-ring Canonical RepositoryState observes exact mutable local
HEAD/index/worktree/filesystem state, under its own explicit coherence
conditions. M7-A's `RepositoryInspectionRef`, immutable Git object closure,
`baselineGitBasis` and independently restored tree serve a different,
publication-capable baseline purpose. M7-A MUST NOT present those values as
Canonical RepositoryState identities, perform an alternative Repository
Integrity evaluation, infer generic projection/evidence-binding truth from an
OID, or silently reimplement a proto-ring governance capability. Applicable
generic checks remain bound to the consumer's pinned proto-ring provider; M6
continues to own execution of the Turnlock-specific qualification authority.

`inspectRepositoryHead`, `listTreeEntries`, `buildTree`, and other Git
operations in Section 2 are exact Git data primitives, not competing public
governance observation/evaluation APIs. `classifyGitMetadataPath` protects
raw Git-tree candidate paths and must not be equated with a different
proto-ring path or whitespace contract merely because both validate paths.

No new general-purpose Git storage library, state-governance engine, authoring
decision, or commit-publication service is authorized by this clarification.

## 2. Construction dependencies

M7-A consumes exactly these construction dependencies:

```text
NIB-S-GATE-A-CAMPAIGN-RUNNER 13.0.3
NIB-M-GATE-A-CONTRACTS 1.4.0
NIB-M-GATE-A-ASSURANCE-LEDGER-REPOSITORY-PROJECTION-READINESS 1.0.1
NIB-M-GATE-A-REPOSITORY-CONTROL-PUBLICATION-REMOTE-RECOVERY 2.0.1
CampaignArtifactStore
DC-GIT-CLI-GATE-A-REPOSITORY-CONTROL
```

The Git Dependency Contract is required before GREEN. Its separate artifact is
not created by this Module Brief.

M7-A consumes exactly these 19 primitives from the shared Git Dependency
Contract:

```text
01 qualifyRuntime
02 inspectRepositoryHead
03 inspectRepositoryObjectSources
04 inspectPushConfiguration
05 resolveRemotePushEndpoints
06 parsePushRefspec
07 classifyEndpoint
08 readRawObject
09 writeRawObject
10 inspectCommitObject
11 traverseReachableClosure
12 acquirePromisorObjects
13 acquireConfiguredUpstreamHistory
14 createIsolatedObjectDatabase
15 listTreeEntries
16 buildTree
17 classifyGitMetadataPath
18 createBaselineBundleV3
19 restoreAndInspectBaselineBundleV3
```

The NIB owns when and why these primitives are invoked and how their typed
results are interpreted.

The Dependency Contract owns Git executable qualification, exact commands,
flags, controlled environment, config semantics, byte/NUL parsing, refspec
grammar, object-format mechanics, raw object mechanics, bundle mechanics,
credential boundary, and Git error interpretation.

M7-B `2.0.1` extends the same future shared Dependency Contract with exactly:

```text
20 observePublicationTarget
21 acquirePublicationTargetHistory
22 provePublicationAncestorOrEqual
23 conditionalUpdatePublicationTarget
```

The total future shared surface is exactly 23 primitives. M7-A does not consume
these four M7-B-only primitives.

## 3. Git runtime qualification

Require the Dependency Contract to qualify at least:

```text
sha1 object format
sha256 object format
raw object read/write
missing-object traversal
NUL-safe tree listing
NUL-safe tree construction
bundle v3
```

Require capability qualification in addition to any minimum Git version.
Classify a missing required dependency capability as:

```text
construction/runtime dependency failure
```

Do not classify it as an operational blocker.

## 4. Canonical runner JSON

M7-A consumes M0 `CanonicalRunnerJsonBytesV1` exactly. It owns no competing
object-key sorting algorithm, number policy, Unicode policy, escaping policy, or
canonical JSON serializer.

For every M7-A runner-owned JSON artifact execute exactly:

```text
construct the exact validated value
→ M0 CanonicalRunnerJsonBytesV1
→ CampaignArtifactStore.sealRunnerArtifact with mediaType application/json
```

Keep all M7-A-specific media-type and path rules. If M0 rejects a runner-owned
M7 value, classify that result as an implementation/process/integrity failure,
never an operator blocker.

Protocol-v8 semantic canonical JSON remains M6/Python authority and is not
reimplemented here.

## 5. Baseline Git basis

Define exactly:

```ts
type GateAGitObjectFormatV1 = "sha1" | "sha256";

interface GateABaselineGitBasisV1 {
  readonly schema: "gate-a-baseline-git-basis.v1";
  readonly gitObjectFormat: GateAGitObjectFormatV1;
  readonly baselineAuthority: RepositoryAuthorityRef;
  readonly carrier: {
    readonly kind: "git-bundle-v3";
    readonly bundle: ArtifactRef;
    readonly internalRef: "refs/turnlock/baseline";
    readonly prerequisiteObjectIds: readonly [];
  };
  readonly verification: ArtifactRef;
}

interface GateABaselineGitBasisVerificationV1 {
  readonly schema: "gate-a-baseline-git-basis-verification.v1";
  readonly gitObjectFormat: GateAGitObjectFormatV1;
  readonly bundle: ArtifactRef;
  readonly internalRef: "refs/turnlock/baseline";
  readonly prerequisiteObjectIds: readonly [];
  readonly expectedAuthority: RepositoryAuthorityRef;
  readonly restoredAuthority: RepositoryAuthorityRef;
  readonly closureObjectCount: number;
  readonly closureSetSha256: Sha256;
  readonly reachableClosureComplete: true;
  readonly standaloneRestoreVerified: true;
}
```

Require:

```text
expectedAuthority == restoredAuthority == RepositoryInspectionRef.baselineAuthority
```

`baselineGitBasis` is the `ArtifactRef` of the canonical
`GateABaselineGitBasisV1` JSON. It is not the raw bundle.

Use exactly these media types and path bindings:

```text
baselineGitBasis descriptor      application/json
verification record              application/json
raw bundle                       application/octet-stream

repositoryPath = null for all three
```

## 6. Closure identity and semantics

Define the exact closure fingerprint:

```text
ClosureSet =
all unique Git objects reachable from C under the M7-A closure semantics

sort ClosureSet by lowercase full OID ASCII lexicographic order

for each OID:
    resolve exact Git object type
    emit:
        type + SP + oid + LF

closureSetSha256 =
    SHA256(UTF8(concatenated emitted lines))
```

`closureObjectCount` equals the exact `ClosureSet` cardinality.

Define reachable closure exactly as:

```text
Closure(C)
=
C
+
all parent commits recursively
+
every tree recursively reachable from those commits
+
every nested tree
+
every blob
```

For tree mode `160000`:

```text
retain exact gitlink OID as candidate material
do NOT traverse into the referenced submodule commit
do NOT contact a submodule repository
```

No tag, note, stash, reflog, unrelated ref, remote-tracking ref, or unreachable
object belongs to `Closure(C)` merely because it exists locally.

## 7. Object acquisition architecture

Use exactly four conceptual repositories:

```text
SOURCE
→ read-only mutable source repository

ACQUISITION
→ isolated object database permitted to use authorized acquisition sources

CLOSURE
→ isolated object database containing only exact Closure(C)

VERIFICATION
→ new isolated empty object database populated only from the final bundle
```

Never hydrate, fetch, unshallow, configure, or mutate `SOURCE`.

Use allowed acquisition source classes in this exact order:

```text
1. source repository object database
   including repository-declared objects/info/alternates

2. explicitly declared promisor remotes

3. configured current-branch fetch/upstream source
   only when required to complete shallow ancestry
```

Forbid these acquisition sources:

```text
ambient GIT_ALTERNATE_OBJECT_DIRECTORIES
implicit origin fallback
arbitrary remotes
publication target solely because an object is missing
submodule remotes
URLs found in .gitmodules
server-added promisor remotes
guessed URLs
```

Always read the source repository with lazy fetching disabled.

### 7.1 Acquisition loop

Execute exactly:

```text
copy raw C into ACQUISITION
verify recomputed C OID

repeat:
    traverse exact graph from C in ACQUISITION
    with:
        no shallow boundary
        no replace objects
        no lazy fetch

    compute PRESENT and MISSING

    if MISSING empty:
        stop

    attempt missing-object acquisition from authorized sources
    in exact source-class order

    every acquired object's recomputed OID must equal the requested OID

    if no requested missing object becomes newly available:
        return baseline-git-closure-unavailable

    repeat
```

Extra objects returned by Git or server fetch mechanics may exist in
`ACQUISITION`. They do not become baseline objects unless they are members of
exact `Closure(C)`.

### 7.2 Shallow completion

Allow configured shallow-history acquisition only when:

```text
source repository is shallow

current symbolic branch has one explicit effective branch.<B>.remote

current symbolic branch has exactly one branch.<B>.merge

branch.<B>.merge is fully qualified under refs/heads/*
```

There is no implicit `origin`.

Fetch only in `ACQUISITION`. Remote advancement does not change baseline
authority. After acquisition, always recompute `Closure(C)`, never closure of
the remote tip.

## 8. Closure purification, bundle, and restore

After `Closure(C)` is complete, execute exactly:

```text
create CLOSURE as a new isolated same-object-format object database

for each exact ClosureSet OID:
    read raw object from ACQUISITION
    write raw object into CLOSURE
    require written OID == expected OID

re-traverse C in CLOSURE

require:
    no missing objects
    same closureObjectCount
    same closureSetSha256
    tree(C) == baselineAuthority.treeSha
```

Require `CLOSURE` to have:

```text
zero remotes
zero alternates
zero promisor configuration
zero shallow state
zero replace refs
zero worktree
zero index
```

Create the baseline bundle from `CLOSURE` with exactly:

```text
Git bundle v3

exactly one internal ref:
refs/turnlock/baseline -> C

zero prerequisites
same exact object format
no filter capability
```

Bundle bytes need not be deterministic. Once sealed, the exact produced bundle
bytes are immutable evidence for that inspection occurrence.

Restore the bundle into a new `VERIFICATION` repository that has:

```text
same object format
zero remotes
zero alternates
zero promisor configuration
zero shallow state
zero replace refs
zero lazy fetch path
```

Require:

```text
refs/turnlock/baseline == C
raw C readable
tree(C) == expected tree
Closure(C) complete
closureObjectCount identical
closureSetSha256 identical
```

Only after this succeeds may the baseline Git basis be considered valid.

## 9. Publication-target identity resolution

Define the success artifact exactly:

```ts
interface GateARepositoryPublicationTargetResolutionV1 {
  readonly schema:
    "gate-a-repository-publication-target-resolution.v1";

  readonly symbolicHeadRef: string;

  readonly remoteSelection:
    | "branch-push-remote"
    | "remote-push-default"
    | "branch-remote";

  readonly refSelection:
    | "remote-push-refspec"
    | "push-default-current"
    | "push-default-simple"
    | "push-default-upstream";

  readonly target: RepositoryPublicationTargetRef;
}
```

This artifact must not contain the local remote alias.

### 9.1 Push configuration dependency result

Require `inspectPushConfiguration` to expose Git-effective single-valued
configuration for:

```text
branch.<B>.pushRemote
remote.pushDefault
branch.<B>.remote
push.default
```

Require it to expose all effective values for the legitimately multi-valued:

```text
branch.<B>.merge
remote.<R>.push
```

The Dependency Contract owns Git config precedence and effective-value semantics
for single-valued configuration. M7-A does not reinterpret Git config-file
precedence.

### 9.2 Publication remote selection

Select remote alias `R` exactly:

```text
if branch.<B>.pushRemote exists:
    R = that value
else if remote.pushDefault exists:
    R = that value
else if branch.<B>.remote exists:
    R = that value
else:
    publication-target-unavailable
    reason = missing
    component = push-remote
```

There is no implicit `origin` fallback.

Treat the selected remote alias as ephemeral. Never retain it in durable target
identity or success evidence.

### 9.3 Effective push endpoint

Call exactly:

```text
resolveRemotePushEndpoints(repositoryPath, R)
```

Require exactly one effective endpoint:

```text
0 endpoints
→ missing / push-endpoint

>1 endpoints
→ ambiguous / push-endpoint
```

Classify the exact Git-resolved endpoint. Support only:

```text
https
ssh-uri
ssh-scp-like
```

Reject:

```text
http
git
file
local-path
remote-helper
unknown
```

Reject any endpoint classified as credential-bearing. Reject a URI query or
fragment.

Do not:

```text
strip .git
normalize provider paths
lowercase repository paths
translate scp syntax to ssh URI
merge HTTPS/SSH identities
resolve path components
```

`remoteEndpoint` is the exact credential-free Git-resolved effective endpoint.

Define exactly:

```text
repositoryIdentity =
"git-push-endpoint-sha256:" +
lowercaseHex(
    SHA256(
        UTF8(remoteEndpoint)
    )
)
```

Permit no network, API, or provider-specific repository identity lookup.

### 9.4 Push ref selection

If `remote.<R>.push` has one or more effective refspecs:

```text
require exactly one refspec
parse through DC parsePushRefspec
```

Require:

```text
force == false
deletion == false
wildcard == false

source ==
    "HEAD"
    OR exact symbolic current branch refs/heads/<B>

destination is fully qualified refs/heads/*
```

Map any force, deletion, wildcard, matching, multi-ref, unqualified, or
foreign-source refspec to:

```text
publication-target-unavailable
reason = unsupported-refspec
component = push-ref
```

Map a fully qualified destination outside `refs/heads/*` to:

```text
reason = non-branch-target
component = push-ref
```

When accepted, require:

```text
refSelection = remote-push-refspec
target.refName = exact destination
```

### 9.5 `push.default` selection

If no `remote.<R>.push` refspec exists, use effective `push.default`. If absent,
treat it as `simple`.

Apply exactly:

```text
current:
    target = refs/heads/<B>

simple:
    if selected push remote differs from branch.<B>.remote:
        target = refs/heads/<B>
    else:
        require exactly one branch.<B>.merge
        require it equals refs/heads/<B>
        target = refs/heads/<B>

upstream or tracking:
    require selected push remote == branch.<B>.remote
    require exactly one branch.<B>.merge
    require branch.<B>.merge under refs/heads/*
    target = exact branch.<B>.merge
```

Apply the exact failure mapping:

```text
push.default = nothing
→ missing / push-ref

push.default = matching
→ unsupported-push-mode / push-ref

unknown push.default
→ unsupported-push-mode / push-ref

simple with absent upstream where central simple requires one
→ missing / push-ref

simple with mismatching upstream branch name
→ incompatible-upstream / push-ref

upstream/tracking with different push remote
→ incompatible-upstream / push-ref

upstream/tracking with absent merge ref
→ missing / push-ref

upstream/tracking with merge ref outside refs/heads/*
→ non-branch-target / push-ref
```

`push.autoSetupRemote` has no semantic effect on M7-A target identity. M7-A
never mutates Git config to establish an upstream.

## 10. Candidate materialization

Define exactly:

```ts
interface GateACandidateMaterializationV1 {
  readonly schema: "gate-a-candidate-materialization.v1";
  readonly gitObjectFormat: GateAGitObjectFormatV1;
  readonly rootTreeObjectId: string;
  readonly entries: readonly CandidateMaterializedEntryV1[];
}

type CandidateMaterializedEntryV1 =
  | {
      readonly pathBytesBase64url: string;
      readonly kind: "blob";
      readonly mode: "100644" | "100755";
      readonly content: ArtifactRef;
    }
  | {
      readonly pathBytesBase64url: string;
      readonly kind: "symlink";
      readonly mode: "120000";
      readonly content: ArtifactRef;
    }
  | {
      readonly pathBytesBase64url: string;
      readonly kind: "gitlink";
      readonly mode: "160000";
      readonly objectId: string;
    };
```

No directory entries occur. An empty repository is representable. Empty
directories are not.

### 10.1 Candidate path rules

`pathBytesBase64url` is:

```text
canonical unpadded RFC 4648 base64url
of the exact full raw Git path bytes
```

Use raw Git byte `0x2f` as the path separator. Reject:

```text
empty path
absolute path
trailing slash
NUL
empty component
.
..
unsafe Git-metadata-equivalent component
```

Use `classifyGitMetadataPath` for metadata-equivalent detection.

Do not use:

```text
Unicode normalization
locale
filesystem separator semantics
realpath
case folding for general candidate collisions
host filesystem path normalization
```

Require exact paths to be unique. Reject leaf/prefix collisions. Order candidate
entries by decoded raw path bytes in unsigned bytewise lexicographic ascending
order.

### 10.2 Candidate content

For blob and symlink entries, require:

```text
content ArtifactRef
mediaType = application/octet-stream
repositoryPath = null
exact bytes
```

Symlink target bytes are content bytes. Never create filesystem symlinks.

For a gitlink, require:

```text
mode = 160000
exact objectId
no ArtifactRef content
no submodule resolution
```

### 10.3 Candidate tree projection

Define exactly:

```ts
interface GateACandidateTreeProjectionVerificationV1 {
  readonly schema:
    "gate-a-candidate-tree-projection-verification.v1";

  readonly gitObjectFormat: GateAGitObjectFormatV1;
  readonly materialization: ArtifactRef;
  readonly computedRootTreeObjectId: string;
  readonly roundTripVerified: true;
}
```

Project through an isolated object database with:

```text
no worktree
no index
no filters
```

After `buildTree`, call `listTreeEntries` and reconstruct the manifest. Require
byte-for-byte canonical materialization equality and exact root-tree identity.

### 10.4 C0 construction

Derive `C0` only from the exact independently verified baseline tree:

```text
read exact verified tree(C)
list exact raw tree entries
validate paths and modes
seal every blob/symlink exact content
retain gitlink OIDs
construct canonical GateACandidateMaterializationV1
seal materialization
project materialization back to Git tree
require projected root == baselineAuthority.treeSha
seal tree-projection verification
construct SealedCandidateMaterializationRef:
    runId = inspection runId
    parentCandidateId = null
    producedByRepairIntentId = null
    producedByAssuranceProjectionId = null
```

Never derive `C0` from mutable worktree bytes.

## 11. Exact candidate patching

Define exactly:

```ts
interface GateAExactCandidatePatchV1 {
  readonly schema: "gate-a-exact-candidate-patch.v1";
  readonly sourceMaterialization: ArtifactRef;
  readonly operations: readonly CandidateEntryReplacementV1[];
}

interface CandidateEntryReplacementV1 {
  readonly pathBytesBase64url: string;
  readonly before: CandidateEntryStateV1 | null;
  readonly after: CandidateEntryStateV1 | null;
}

type CandidateEntryStateV1 =
  | {
      readonly kind: "blob";
      readonly mode: "100644" | "100755";
      readonly content: ArtifactRef;
    }
  | {
      readonly kind: "symlink";
      readonly mode: "120000";
      readonly content: ArtifactRef;
    }
  | {
      readonly kind: "gitlink";
      readonly mode: "160000";
      readonly objectId: string;
    };
```

### 11.1 Patch canonicality and admissibility

Require:

```text
canonical runner JSON
>= 1 operation
operations ordered by canonical decoded path order
one operation per exact path
no before == after no-op
sourceMaterialization exact source candidate
every before checked against the same immutable source materialization
all preimages checked before any mutation
```

If any preimage mismatches, reject the entire patch as an
implementation/process/integrity failure.

Never:

```text
fuzzy match
offset
context repair
3-way merge
manual conflict resolution
partial patch application
```

Represent operations exactly as:

```text
rename = delete + create
copy = create
chmod/type change = single replacement
```

Patch `after` content is already sealed by exact `ArtifactRef`. Permit no inline
arbitrary file bytes.

### 11.2 Assurance projection validation

For request `R`, projection ref `A = R.assuranceProjection`, decoded projection
`P`, and source candidate `C = R.sourceCandidate`, M7-A reads exact
`A.projection` bytes from `CampaignArtifactStore` and validates mechanically,
before any mutation:

```text
A.runId == R.runId
A.sourceCandidateId == C.candidateId
A.semanticSubject == C.semanticSubject

A.projection exact and intact
A.projection.mediaType == application/json
A.projection.repositoryPath == null

complete projection bytes ==
    M0 CanonicalRunnerJsonBytesV1(decoded complete projection value)

P.schema == gate-a-assurance-repository-projection.v1
P.sourceCandidateId == A.sourceCandidateId
P.semanticSubject == A.semanticSubject
P.protocolBundle == A.protocolBundle
P.entries non-empty
P.entries strict exact UTF-8 repositoryPath byte order
P.entries duplicate-free by exact repositoryPath bytes

every entry.content exact and intact
every entry.content.repositoryPath == null
every entry path/mediaType obeys NIB-S 13.0.3
```

M7-A never independently decides whether `A.protocolBundle` is current. After
the exact cross-binding above, namespace selection uses only:

```text
A.protocolBundle.protocolId
```

It never uses generic latest protocol, a mutable `formal/verification.yaml`
reread, a mutable protocol-file reread, role inference, or content inference.

For exact protocol ID `gate-a-campaign-protocol-v6`, preserve the pre-C9-F P6
projection namespace. Permit only direct `.json` targets in exactly:

```text
formal/reviews/<ReviewCampaignId>.json
formal/reviews/packets/*.json
formal/reviews/challenge-packets/*.json
formal/reviews/executions/*.json
formal/reviews/raw/*.json
formal/reviews/adjudications/*.json
formal/reviews/challenges/*.json
```

The root and each listed directory accept only direct-child `.json` paths under
existing candidate-path safety rules. Do not add new historical P6 filename
semantics. P6 does not newly project supplements, semantic-question bindings, or
semantic-admission origin witnesses.

For exact protocol ID `gate-a-campaign-protocol-v8`, accept only these exact
patterns:

```text
^formal/reviews/REVIEW-[0-9A-F]{64}\.json$
^formal/reviews/packets/[0-9a-f]{64}\.json$
^formal/reviews/executions/EXEC-[0-9A-F]{64}\.json$
^formal/reviews/raw/EXEC-[0-9A-F]{64}-ATTEMPT-[1-9][0-9]*\.json$
^formal/reviews/adjudications/[0-9a-f]{64}\.json$
^formal/reviews/challenges/[0-9a-f]{64}\.json$
^formal/reviews/supplements/[0-9a-f]{64}\.json$
^formal/reviews/semantic-question-bindings/[0-9a-f]{64}\.json$
^formal/reviews/semantic-admission-origin-witnesses/[0-9a-f]{64}\.json$
```

Exact P8 rejects `formal/reviews/challenge-packets/**` and
`formal/reviews/adjudication-packets/**`; P8 semantic execution packets use only
`formal/reviews/packets/<sha256>.json`.

Exact protocol ID `gate-a-campaign-protocol-v7` rejects every attempted new
assurance projection because P7 is permanently inactive. M7-A has no P7
materialization branch. Any other protocol identity is an
implementation/process/integrity failure; no generic future-protocol branch
exists. Existing historical candidate files are neither removed nor
reinterpreted.

For every validated `repositoryPath`, first require complete projection
canonical-byte equality, then encode the path as exact UTF-8 bytes with no
Unicode, case, or filesystem normalization. Reject any path failing existing
candidate Git-path rules. Convert it exactly as:

```text
pathBytesBase64url =
canonical unpadded RFC 4648 base64url(exact UTF-8 repositoryPath bytes)
```

Use those same raw bytes for candidate lookup, projection duplicate detection,
repair/projection overlap detection, and leaf/prefix collision detection.

M7-A validates only projection shape and cross-bindings, path namespace and
grammar, path order and duplicates, `ArtifactRef` integrity, path-qualified
media type, exact bytes, candidate path state, Git representability, and
repair/projection collision. It never inspects ReviewCampaign finding meaning,
materiality/refutation, supplement effective adjudication, SemanticAdmission,
QLEK, Fact, qualification, origin-witness or receipt semantic truth, model
output meaning, or candidate readiness meaning.

### 11.3 Projection content to candidate content

For one projection entry `E` whose target is absent from the source candidate,
set `sourceRef = E.content` and require:

```text
sourceRef exact and intact
sourceRef.repositoryPath == null
sourceRef.mediaType obeys the NIB-S path/media mapping
```

Then execute exactly:

```ts
sourceBytes = await CampaignArtifactStore.readVerified(sourceRef);

candidateContentRef =
  await CampaignArtifactStore.sealRunnerArtifact({
    bytes: sourceBytes,
    mediaType: "application/octet-stream"
  });
```

Require exactly:

```text
candidateContentRef.sha256 == sourceRef.sha256
candidateContentRef.byteLength == sourceRef.byteLength
candidateContentRef.mediaType == application/octet-stream
candidateContentRef.repositoryPath == null
bytes(candidateContentRef) == sourceBytes
```

Use `candidateContentRef` only in `GateACandidateMaterializationV1`. Never
mutate or replace `E.content` inside the assurance projection. The carrier is
candidate/Git byte transport only. It is not new hostile-review evidence,
semantic evidence identity, receipt, raw output, adjudication, origin witness,
or M5 product. The original exact M5/M4 `ArtifactRef` remains provenance
authority. Physical CAS identity remains SHA-based under the existing
`CampaignArtifactStore` contract.

If the immutable source candidate already contains the exact target as mode
`100644`, kind `blob`, read verified existing and projection bytes. If equal,
retain the exact existing `CandidateMaterializedEntryV1` unchanged, do not
replace its content `ArtifactRef`, and do not create a candidate carrier solely
for that path. Different bytes, wrong mode or type fails. A projection whose
every entry is already identical remains a complete no-op and fails candidate
construction exactly as before.

### 11.4 Source-candidate independence and combined prevalidation

Every assurance entry must be valid independently against the immutable source
candidate before either repair or assurance projection is applied. Permit only:

```text
source target absent and no source leaf/prefix collision
OR
source target is an exact 100644 blob with byte-identical content
```

Reject existing different bytes, mode other than `100644`, symlink, gitlink,
directory/prefix collision, a target that prefixes another source leaf, or a
source leaf that prefixes the target. Never depend on repair application to make
an otherwise-invalid assurance path applicable.

Before mutation, decode every repair operation `pathBytesBase64url` to exact raw
Git bytes and encode every assurance `repositoryPath` to exact UTF-8 raw Git
bytes. Require no exact equality. Prevalidate the complete final created or
replaced leaf set so no repair after-state path and assurance target create a
leaf/prefix collision. Never resolve a conflict by repair-wins,
projection-wins, application order, merge, rename, or 3-way behavior.

### 11.5 Exact candidate-change construction

Consume exactly one `CandidateConstructionRequest` with nullable repair and
projection authorities. Require the exact run/source bindings and at least one
non-null authority. For repair, validate and use only exact
`repairIntent.approvedPatch`. For projection, validate and use only exact
`assuranceProjection.projection`.

Execute one deterministic mutation engine in this exact order:

```text
1. verify exact CandidateConstructionRequest bindings
2. read and validate exact immutable source candidate
3. if repair != null:
   validate entire RepairIntent approvedPatch
   validate every repair preimage against source candidate
4. if assurance projection != null:
   verify/decode exact projection
   validate canonical runner JSON through M0
   validate all projection path/media/content bindings
   validate all source-candidate path states
5. prevalidate repair/projection exact-path and leaf/prefix disjointness
6. perform NO mutation if any prevalidation failed
7. apply exact repair replacements in canonical repair order
8. apply exact assurance projection targets in canonical repositoryPath order
9. validate complete candidate manifest
10. construct canonical GateACandidateMaterializationV1 through M0 canonical JSON
11. project exact candidate to Git tree through isolated Git object database
12. round-trip verify
13. seal candidate materialization
14. return CandidateSealResult
```

No partial candidate survives a failure. There is no second mutation engine,
precedence rule, merge, or conflict resolver.

Repair-only behavior remains exactly the pre-2.1.0 behavior: patch preimages,
operation representation, candidate content representation, tree projection,
evidence and provenance are unchanged.

For assurance-only construction require sealed provenance exactly:

```text
parentCandidateId = sourceCandidate.candidateId
producedByRepairIntentId = null
producedByAssuranceProjectionId = assuranceProjection.projectionId
```

M7-A does not derive the successor semantic subject. Future/current M1 invokes
M6 on the sealed successor. If the M6-derived successor subject differs from the
source subject, admit no `CandidateRevision`, do not consume the projection, and
fail as implementation/process/integrity before M2 admission.

For combined repair plus assurance construction require sealed provenance
exactly:

```text
parentCandidateId = sourceCandidate.candidateId
producedByRepairIntentId = repairIntent.repairIntentId
producedByAssuranceProjectionId = assuranceProjection.projectionId
```

M7-A performs no semantic interpretation of whether `S` should change. M1, M6
and M2 own later derivation and admission. One repair and one projection each
produce at most one admitted candidate; M2 is the authoritative consumption
enforcer.

## 12. Evidence ordering

Define exact `ArtifactRef` equality as structural equality over:

```text
artifactId
sha256
byteLength
mediaType
repositoryPath
```

For every M7-A ordered duplicate-free array:

```text
construct exact source sequence
scan left-to-right
retain first occurrence
drop later exact-ArtifactRef duplicates
```

Never deduplicate only by SHA.

Define `candidateContentArtifacts(M)` exactly as:

```text
iterate candidate entries in canonical candidate-path order

blob    → append content
symlink → append content
gitlink → append nothing

then exact-ArtifactRef first-occurrence dedup
```

Require exact baseline candidate evidence:

```text
sealedBaselineCandidate.materializationEvidence =
[
  ...candidateContentArtifacts(C0),
  baselineCandidateTreeProjectionVerification
]
```

Require exact repository-inspection evidence:

```text
RepositoryInspectionRef.evidence =
[
  publicationTargetResolution,
  baselineBundle,
  baselineGitBasisVerification
]
```

Require descriptor bindings:

```text
baselineGitBasis.carrier.bundle ==
RepositoryInspectionRef.evidence[1]

baselineGitBasis.verification ==
RepositoryInspectionRef.evidence[2]
```

For source `P`, nullable repair `R`, nullable assurance projection `A`, result
`M`, and tree verification `V`, require:

```text
sealedCandidate.materializationEvidence =
[
  P.materialization,
  R.approvedPatch if R != null,
  A.projection if A != null,
  ...candidateContentArtifacts(M),
  V
]
```

Apply exact-`ArtifactRef` first-occurrence deduplication. Do not recursively
include parent `materializationEvidence`, separately add `A.basisArtifacts`,
insert original projection-entry content merely because M7 generated octet-
stream candidate carriers, insert M5 semantic provenance or M6 semantic
evidence, or separately add repair after-content references.

The identity distinction is exact:

```text
projection entry content ArtifactRef
= assurance/runtime artifact identity

candidate blob content ArtifactRef
= canonical repository-byte carrier
```

They may have the same exact bytes, SHA-256 and byte length while differing in
media type and, when the source was external, possibly `artifactId`. This creates
no additional semantic evidence result. M7-A never substitutes the candidate
carrier back into a receipt, origin witness, semantic-question binding,
supplement, M5 `AdjudicationRef`, `EvidenceRef`, or
`AssuranceRepositoryProjectionArtifactV1`.

## 13. Publication-successor projection

Define exactly:

```ts
interface PublicationSuccessorProjectionRequestV1 {
  readonly repositoryInspection: RepositoryInspectionRef;
  readonly candidate: CandidateRevisionRef;
}

interface PublicationSuccessorProjectionResultV1 {
  readonly projection: ArtifactRef;
  readonly successorAuthority: RepositoryAuthorityRef;
}

interface GateAGitPublicationSuccessorProjectionV1 {
  readonly schema:
    "gate-a-git-publication-successor-projection.v1";

  readonly algorithm:
    "baseline-single-parent.v1";

  readonly gitObjectFormat:
    GateAGitObjectFormatV1;

  readonly baselineAuthority:
    RepositoryAuthorityRef;

  readonly candidateMaterialization:
    ArtifactRef;

  readonly candidateTreeObjectId:
    string;

  readonly candidateTreeProjectionVerification:
    ArtifactRef;

  readonly mode:
    | "reuse-baseline-commit"
    | "synthetic-single-parent";

  readonly successorAuthority:
    RepositoryAuthorityRef;

  readonly syntheticCommitBody:
    ArtifactRef | null;
}

interface MaterializeProjectedSuccessorRequestV1 {
  readonly repositoryInspection: RepositoryInspectionRef;
  readonly candidate: CandidateRevisionRef;
  readonly projection: ArtifactRef;
}

interface MaterializedProjectedSuccessorV1 {
  readonly authority: RepositoryAuthorityRef;
  readonly repositoryPath: string;
}
```

`repositoryPath` is operational only and never durable identity.

### 13.1 Deterministic successor algorithm

Let:

```text
C  = baselineAuthority.commitSha
TC = baselineAuthority.treeSha
TM = exact projected candidate tree
```

If:

```text
TM == TC
```

then require:

```text
mode = reuse-baseline-commit
successorAuthority = baselineAuthority
syntheticCommitBody = null
```

Otherwise construct these exact raw commit bytes:

```text
tree <TM>
parent <C>
author TURNLOCK Gate A Runner <turnlock-gate-a-runner@turnlock.invalid> <baseline_committer_unix_seconds> +0000
committer TURNLOCK Gate A Runner <turnlock-gate-a-runner@turnlock.invalid> <baseline_committer_unix_seconds> +0000

TURNLOCK Gate A publication
```

The final message includes exactly one trailing LF. Headers occur exactly in
this order:

```text
tree
parent
author
committer
```

Add no header. Do not sign. Use no current clock, run ID, or candidate ID.

Seal the exact raw commit bytes as:

```text
application/octet-stream
repositoryPath = null
```

Store exact type `commit` through the Git Dependency Contract. Require exact OID
readback. Set `successorAuthority.treeSha = TM`.

For identical:

```text
baseline authority
candidate materialization
Git object format
baseline committer timestamp
```

require the successor OID to be identical.

### 13.2 M7-A to M7-B boundary

Expose exactly these internal functions:

```ts
project_publication_successor(
  request: PublicationSuccessorProjectionRequestV1,
): Promise<PublicationSuccessorProjectionResultV1>

materialize_projected_successor(
  request: MaterializeProjectedSuccessorRequestV1,
): Promise<MaterializedProjectedSuccessorV1>
```

The `RepositoryInspectionRef` supplied for publication-successor projection is
the exact retained preflight inspection projected as:

```text
GateARunSnapshot.repositoryInspection
```

M1 passes that exact retained value through `PublicationPreparationRequest`.

M7 must reject an invocation whose `repositoryInspection` is not the exact
retained inspection for the `GateARun`, even if its `baselineAuthority`,
`publicationTarget`, or referenced artifact bytes appear equivalent.

M7 does not rediscover or reconstruct the preflight inspection from mutable
repository state.

`project_publication_successor` performs:

```text
NO network
NO remote observation
NO mutable repository reread
NO current clock
NO randomness
```

`materialize_projected_successor` realizes an already-derived projection. It
must verify:

```text
projection.baselineAuthority ==
repositoryInspection.baselineAuthority

projection.candidateMaterialization ==
candidate.materialization

materialized authority ==
projection.successorAuthority
```

It may not derive a different successor.

M7-B owns `P` and `P <= T`. M7-A owns `T`.

## 14. Repository-inspection operational causes

Define the exact root union:

```ts
type GateARepositoryInspectionOperationalCauseV1 =
  | RepositoryHeadUnavailableCauseV1
  | RepositoryFormatUnsupportedCauseV1
  | PublicationTargetUnavailableCauseV1
  | BaselineGitClosureUnavailableCauseV1
  | BaselineGitCommitUnsupportedCauseV1
  | BaselineCandidateUnsupportedCauseV1;
```

Every member has exactly:

```text
schema =
"gate-a-repository-inspection-operational-cause.v1"
```

Serialize every cause descriptor as canonical runner JSON with:

```text
mediaType = application/json
repositoryPath = null
```

Construct every resulting `NonRecoveryOperationalCauseRefV1` with exactly:

```text
producer = "repository-control"

resolutionContracts = [
  { kind: "request-operational-recheck" }
]
```

No execution-replacement resolution contract is lawful.

### 14.1 Head and format causes

Define exactly:

```ts
interface RepositoryHeadUnavailableCauseV1 {
  readonly schema:
    "gate-a-repository-inspection-operational-cause.v1";
  readonly kind: "repository-head-unavailable";
  readonly reason:
    | "not-git-repository"
    | "unborn-head"
    | "detached-head";
}

interface RepositoryFormatUnsupportedCauseV1 {
  readonly schema:
    "gate-a-repository-inspection-operational-cause.v1";
  readonly kind: "repository-format-unsupported";
  readonly observedObjectFormat: string;
}
```

For both, require:

```text
basisArtifacts = []
```

Support only:

```text
sha1
sha256
```

### 14.2 Publication-target cause and evidence

Define exactly:

```ts
interface PublicationTargetUnavailableCauseV1 {
  readonly schema:
    "gate-a-repository-inspection-operational-cause.v1";

  readonly kind:
    "publication-target-unavailable";

  readonly reason:
    | "missing"
    | "ambiguous"
    | "unsupported-endpoint"
    | "credential-bearing-endpoint"
    | "unsupported-refspec"
    | "unsupported-push-mode"
    | "incompatible-upstream"
    | "non-branch-target";

  readonly component:
    | "push-remote"
    | "push-endpoint"
    | "push-ref";
}
```

Allow only these reason/component combinations:

```text
missing / push-remote
missing / push-endpoint
missing / push-ref
ambiguous / push-endpoint
unsupported-endpoint / push-endpoint
credential-bearing-endpoint / push-endpoint
unsupported-refspec / push-ref
unsupported-push-mode / push-ref
incompatible-upstream / push-ref
non-branch-target / push-ref
```

Define the failure evidence exactly:

```ts
interface GateARepositoryPublicationTargetResolutionFailureV1 {
  readonly schema:
    "gate-a-repository-publication-target-resolution-failure.v1";

  readonly symbolicHeadRef: string;

  readonly remoteSelection:
    | "branch-push-remote"
    | "remote-push-default"
    | "branch-remote"
    | null;

  readonly failure: {
    readonly reason:
      PublicationTargetUnavailableCauseV1["reason"];
    readonly component:
      PublicationTargetUnavailableCauseV1["component"];
  };

  readonly effectivePushEndpointCount:
    number | null;

  readonly configuredPushRefspecCount:
    number | null;

  readonly pushDefaultMode:
    string | null;

  readonly endpointClass:
    | "https"
    | "ssh-uri"
    | "ssh-scp-like"
    | "http"
    | "git"
    | "file"
    | "local-path"
    | "remote-helper"
    | "unknown"
    | null;

  readonly candidateRefName:
    string | null;
}
```

It must not contain:

```text
remote alias
remote endpoint bytes
credentials
credential helper output
repositoryPath
raw config
```

For `publication-target-unavailable`, require:

```text
basisArtifacts =
[
  targetResolutionFailure
]
```

### 14.3 Closure-unavailable cause and evidence

Define exactly:

```ts
interface BaselineGitClosureUnavailableCauseV1 {
  readonly schema:
    "gate-a-repository-inspection-operational-cause.v1";
  readonly kind:
    "baseline-git-closure-unavailable";
  readonly gitObjectFormat:
    GateAGitObjectFormatV1;
  readonly baselineCommitObjectId:
    string;
}

interface GateABaselineGitClosureUnavailableEvidenceV1 {
  readonly schema:
    "gate-a-baseline-git-closure-unavailable-evidence.v1";
  readonly gitObjectFormat:
    GateAGitObjectFormatV1;
  readonly baselineCommitObjectId:
    string;
  readonly missingObjectCount:
    number;
  readonly missingObjectSetSha256:
    Sha256;
  readonly sourceClassesAttempted:
    readonly (
      | "source-object-database"
      | "declared-alternates"
      | "declared-promisor-remotes"
      | "configured-upstream-history"
    )[];
}
```

Compute the missing-set fingerprint exactly:

```text
sort missing lowercase full OIDs ASCII lexicographic
bytes = oid1 + LF + oid2 + LF + ...
SHA256(bytes)
```

Require:

```text
missingObjectCount > 0
basisArtifacts = [closureUnavailableEvidence]
```

Do not retain remote aliases, remote URLs, or transient network diagnostics.

### 14.4 Commit-unsupported cause

Define exactly:

```ts
interface BaselineGitCommitUnsupportedCauseV1 {
  readonly schema:
    "gate-a-repository-inspection-operational-cause.v1";
  readonly kind:
    "baseline-git-commit-unsupported";
  readonly reason:
    | "malformed-commit"
    | "invalid-committer-date";
  readonly gitObjectFormat:
    GateAGitObjectFormatV1;
  readonly commitObjectId:
    string;
}
```

Require:

```text
basisArtifacts =
[
  exact raw baseline commit body
]
```

The raw body has `mediaType = application/octet-stream` and
`repositoryPath = null`. Its exact Git object hash must equal `commitObjectId`.

### 14.5 Candidate-unsupported causes

Define exactly:

```ts
type BaselineCandidateUnsupportedCauseV1 =
  | UnsafeGitMetadataPathCauseV1
  | UnsupportedTreeEntryModeCauseV1
  | InvalidTreeStructureCauseV1;

interface UnsafeGitMetadataPathCauseV1 {
  readonly schema:
    "gate-a-repository-inspection-operational-cause.v1";
  readonly kind:
    "baseline-candidate-unsupported";
  readonly reason:
    "unsafe-git-metadata-path";
  readonly gitObjectFormat:
    GateAGitObjectFormatV1;
  readonly treeObjectId:
    string;
  readonly pathBytesBase64url:
    string;
}

interface UnsupportedTreeEntryModeCauseV1 {
  readonly schema:
    "gate-a-repository-inspection-operational-cause.v1";
  readonly kind:
    "baseline-candidate-unsupported";
  readonly reason:
    "unsupported-tree-entry-mode";
  readonly gitObjectFormat:
    GateAGitObjectFormatV1;
  readonly treeObjectId:
    string;
  readonly pathBytesBase64url:
    string;
  readonly observedMode:
    string;
}

interface InvalidTreeStructureCauseV1 {
  readonly schema:
    "gate-a-repository-inspection-operational-cause.v1";
  readonly kind:
    "baseline-candidate-unsupported";
  readonly reason:
    "invalid-tree-structure";
  readonly gitObjectFormat:
    GateAGitObjectFormatV1;
  readonly treeObjectId:
    string;
  readonly treePathBytesBase64url:
    string | null;
}
```

For all three require:

```text
basisArtifacts =
[
  exact raw failing tree body
]
```

The hash of the raw tree body must equal `treeObjectId`.

### 14.6 Inspection failure ordering

Return at most one cause from one repository inspection. Detect in this exact
order:

```text
1. repository/head validity
2. object format
3. publication target
4. baseline commit parse / committer date
5. baseline closure acquisition
6. baseline candidate/tree admissibility
7. bundle construction / independent restoration
8. C0 projection
```

At steps 7 and 8, treat contradiction after previously valid inputs as an
implementation/process/integrity failure, not an operational cause.

For candidate/tree admissibility, select the first failure under deterministic:

```text
root-first recursive traversal
children by canonical raw Git path-byte order
```

## 15. Repository inspection

Keep the NIB-S public boundary unchanged:

```ts
interface RepositoryInspectionRequest {
  readonly runId: GateARunId;
  readonly repositoryPath: string;
}
```

Execute the successful algorithm exactly:

```text
qualify Git dependency
inspect repository/head
resolve exact publication target
parse exact baseline commit
complete exact Closure(C)
purify closure
construct baseline bundle
independently restore/verify basis
derive C0 only from exact verified tree(C)
round-trip C0 back to exact tree(C)
seal all exact artifacts
construct RepositoryInspectionRef
```

Admit no authoritative baseline before every successful output artifact is
already sealed.

Require exact repository-inspection evidence:

```text
RepositoryInspectionRef.evidence =
[
  publicationTargetResolution,
  baselineBundle,
  baselineGitBasisVerification
]
```

Apply exact-`ArtifactRef` first-occurrence deduplication.

## 16. Replay, interruption, and failure taxonomy

Apply exactly:

```text
repository inspection
→ may observe different mutable repository/config state on a later retry before
  preflight admission
→ creates no campaign fact until M2 admits its exact result

candidate construction
→ exact immutable inputs
→ deterministic/replay-safe
→ no authoritative fact until candidate admission

successor projection
→ exact immutable inputs
→ deterministic/replay-safe

local resource/process failure before authoritative admission
→ invocation failure
→ no OperationalBlocker
→ retry from durable state allowed
```

An operationally blocked inspection consists only of the exact D3 cause union
in Section 14.

Implementation/process/integrity failure includes at least:

```text
DC returns impossible result under its contract
raw object hash mismatch
ArtifactStore returns invalid ArtifactRef
canonical serializer contract violation
purified closure loses object
closure fingerprint contradiction
bundle has prerequisite after complete closure
bundle has filter capability
offline restore changes C/tree/closure
C0 round-trip fails after input was accepted
successor object hash mismatch
noncanonical assurance projection JSON
projection cross-binding mismatch
unsupported projection protocol
forbidden namespace
P8 path grammar mismatch
projection path/mediaType mismatch
projection content repositoryPath != null
projection ArtifactRef corruption
projection target source-state mismatch
projection target prefix collision
repair/projection exact path overlap
repair/projection leaf-prefix collision
candidate carrier reseal changes SHA
candidate carrier reseal changes byteLength
candidate carrier returned non-octet-stream media type
candidate carrier returned non-null repositoryPath
complete assurance projection no-op
```

None of these cases creates Operator Action Required or OperationalBlocker.

Replay requires:

```text
same immutable source candidate
+ same RepairIntent/null
+ same AssuranceRepositoryProjection/null
→ same exact GateACandidateMaterializationV1 bytes
→ same exact Git root tree
→ same exact sealed CandidateSealResult
```

A crash after projection read but before seal, after candidate-content carrier
sealing but before candidate seal, or after candidate seal but before M2
candidate admission replays the same result. Candidate carriers are CAS
artifacts and do not establish authoritative candidate state.

Transient local failures include:

```text
disk full
temp directory failure
local process interruption
local resource exhaustion
CAS local write interruption
```

These do not become `GateARun` blockers.

Remote acquisition unavailability from an already-authorized acquisition source
may produce `baseline-git-closure-unavailable` when exact closure cannot be
completed.

## 17. Explicitly forbidden behaviors

M7-A must never:

```text
read candidate bytes from mutable worktree after baseline capture
hydrate or mutate SOURCE repository
use ambient alternates
use implicit origin fallback
probe arbitrary remotes
use publication target as arbitrary object source
fetch or update submodules
use Unicode/case/filesystem path normalization
materialize filesystem symlinks
fuzzy patch
3-way patch
partially apply a patch
make M7 repair semantic judgment
allow remote state to influence T
allow M7-B to recompute T
use current clock or randomness in T
use git commit/commit-tree as successor construction authority
use Git replace objects
permit implicit lazy fetch during ordinary object reads
create bundle prerequisites
create a filtered baseline bundle
retain temporary paths as durable identity
retain credentials in any artifact
order evidence by hash, artifactId, or filesystem discovery
implement canonical runner JSON locally in competition with M0
change projection content bytes or source mediaType
use projection-entry repositoryPath as ArtifactRef identity
use an M5-A Stage-B alias as projection content authority
insert application/json ArtifactRef directly as canonical candidate blob content
without candidate-carrier conversion
treat application/octet-stream carrier as new semantic evidence
parse raw model output merely because its repository path ends in .json
repair JSON
normalize Unicode paths
compare repair/projection paths as strings without raw-byte conversion
depend on repair application to make an invalid assurance path valid
materialize a P7 projection
use a generic future/latest protocol projection branch
interpret assurance semantics
```

## 18. Required invariants

M7-A must satisfy all of these:

```text
M7A-01 baseline authority is exact C + tree(C).

M7A-02 baselineGitBasis exists before preflight admission.

M7A-03 independently restored basis reconstructs exact C/tree(C).

M7A-04 baseline closure is standalone and has zero prerequisites.

M7A-05 C0 is derived only from verified baseline tree.

M7A-06 candidate manifest round-trips to exact Git tree.

M7A-07 candidate paths preserve exact Git path bytes.

M7A-08 gitlink target objects are never required for candidate closure.

M7A-09 RepairIntent approvedPatch is the only accepted repair patch.
M7A-09A AssuranceRepositoryProjection.projection is the only accepted assurance
         projection artifact.
M7A-09B Repair and projection path sets are disjoint.
M7A-09C M7-A interprets no assurance semantics and performs no subject
         derivation.

M7A-10 all patch preimages are validated against one immutable source before
        any replacement is applied.

M7A-11 one successful non-C0 candidate construction preserves the exact source
        parent and the exact nullable RepairIntent and
        AssuranceRepositoryProjection provenance supplied by the accepted
        CandidateConstructionRequest; at least one of those two provenance
        authorities is non-null.

M7A-12 identical baseline/candidate/object-format inputs produce identical T.

M7A-13 remote predecessor/current state never influences T.

M7A-14 M7-B may materialize but never recompute or alter T.

M7A-15 inspection evidence arrays use exact NIB-defined order.

M7A-16 blocked inspection returns exactly one producer cause and exactly
        request-operational-recheck.

M7A-17 M7-A never creates OperationalBlocker identity.
M7A-17A Every non-C0 sealed candidate names repair provenance, assurance
         provenance, or both.
M7A-17B Assurance projection cannot mutate judging authority or overwrite
         different evidence bytes.

M7A-18 no mutable repository path/config/ref forms retained baseline authority.

M7A-19 no credential-bearing endpoint becomes durable target identity.

M7A-20 Git dependency contradiction is integrity failure, never operator
        blocker.

M7A-21 M7-A uses M0 CanonicalRunnerJsonBytesV1 and owns no competing canonical
        runner JSON algorithm.

M7A-22 Assurance repository placement never changes exact projection source
        bytes.

M7A-23 Projection entry repositoryPath is placement authority; entry.content
        repositoryPath is always null.

M7A-24 Projection media type is path-qualified exactly by NIB-S 13.0.3.

M7A-25 Every assurance-projected Git blob is represented in candidate
        materialization through an exact application/octet-stream candidate-
        content carrier.

M7A-26 Candidate-content carrier construction preserves exact source bytes, SHA
        and byteLength.

M7A-27 Candidate-content carrier is not semantic/review evidence authority.

M7A-28 Repair and assurance projection are prevalidated against one immutable
        source candidate before any mutation.

M7A-29 Repair/projection conflict is determined over exact raw Git path bytes,
        never string normalization or application order.

M7A-30 Exact P8 projection namespaces are accepted only under exact P8 protocol
        identity; P7 has no materialization branch.

M7A-31 M7-A interprets no assurance semantic content.
```

## 19. Required edge cases

Cover all of these explicitly in NIB-T:

```text
non-Git directory
unborn symbolic branch
detached HEAD
sha1 repository
sha256 repository
unsupported object format
repository using declared alternates
partial clone with missing blob/tree
multiple promisor remotes
shallow repository with configured upstream
shallow repository without configured upstream
remote history advanced beyond C
C no longer obtainable from authorized sources
gitlink/submodule tree entry
symlink with non-UTF8 target bytes
non-UTF8 Git pathname
case-colliding paths
.git metadata-equivalent component
unsupported tree mode
empty repository tree representation where valid
duplicate file-content ArtifactRefs
patch delete/create/rename/copy/chmod/type change
patch preimage mismatch
candidate tree identical to baseline tree
candidate tree different from baseline tree
invalid baseline committer date
multiple effective push endpoints
credential-bearing endpoint
unsupported transport
remote push refspec with force/wildcard/delete
push.default current/simple/upstream/tracking/matching/nothing
simple upstream-name mismatch
upstream push-remote mismatch
C0 both provenance IDs null
assurance-only success
repair-only success
repair + assurance success
both null for non-C0 request
projection source mismatch
projection S mismatch
projection P mismatch
empty projection
unordered projection
duplicate path
forbidden namespace
existing identical file
existing different file
existing wrong mode/type
repair/projection path overlap
assurance-only M6-derived S mismatch
crash after projection admission before M7
crash after M7 sealing before candidate admission
already-consumed projection
restart before candidate admission
restart after successor projection artifact exists
P6 projection legacy namespace regression
P6 challenge-packet remains accepted
P6 new P8-only namespace rejected
P8 packet path accepted
P8 challenge-packet path rejected
P8 supplement path accepted
P8 binding path accepted
P8 origin-witness path accepted
P8 wrong hash filename rejected
P8 wrong EXEC filename rejected
P8 raw attempt ordinal zero rejected
structured path with text/plain content rejected
raw path with application/json content rejected
raw path with text/plain exact bytes accepted
protocol-invalid malformed raw bytes preserved exactly
entry.content repositoryPath non-null rejected
projection path Unicode normalization is not performed
repair raw path equals assurance UTF-8 path rejected
repair-created prefix collision rejected
projection source-prefix collision rejected
source existing identical 100644 file retained unchanged
source existing different bytes rejected
source existing 100755 exact bytes rejected
source symlink rejected
source gitlink rejected
absent structured JSON projection produces application/octet-stream candidate
carrier with the same exact bytes and SHA
absent text/plain raw projection produces application/octet-stream candidate
carrier with the same exact bytes and SHA
candidate carrier never replaces original projection content identity
repair-only regression
complete projection no-op rejected
assurance-only derived-S mismatch remains rejected before M2 admission
M0 canonical JSON exact-byte regression
P7 projection rejected
P8 remains inactive
```

Exact identical projected evidence is retained idempotently. Conflicting bytes,
wrong mode/type, forbidden namespace, empty/unordered/duplicate projection, or
repair/projection overlap fails as implementation/process/integrity failure.
An assurance-only M6-derived subject mismatch is rejected before M2 admission.
After projection admission but before M7, the projection remains unconsumed.
After sealing but before candidate admission, replay from the same immutable
inputs reproduces the same successor. An already-consumed projection is rejected
by M2, which remains the authoritative consumption enforcer.

## 20. Construction classifications and boundary

Record exactly:

```text
statement:
M7-A 2.0.7 locally restates canonical runner JSON even though active M0 1.3.0
owns the exact global runner canonicalization contract

semantic disposition:
derived-from-existing-authority

mechanism:
M7-A consumes M0 CanonicalRunnerJsonBytesV1 directly

normative impact:
none
```

```text
statement:
AssuranceRepositoryProjection placement paths are UTF-8 strings while repair
paths are exact raw Git bytes, so combined candidate construction requires one
exact comparison representation before conflict detection

semantic disposition:
no-normative-impact

mechanism:
encode validated projection repositoryPath to exact UTF-8 bytes and compare to
decoded repair raw path bytes without normalization

affected layer:
architecture-or-implementation
```

```text
statement:
canonical candidate materialization requires application/octet-stream blob
carriers while assurance projection content retains its exact runtime
application/json or text/plain media type

semantic disposition:
no-normative-impact

mechanism:
M7-A seals an exact-byte application/octet-stream candidate carrier without
changing or replacing the original projection content ArtifactRef

affected layer:
architecture-or-implementation
```

No ADR is required.

C9-F closes M7-A construction synchronization with M5-D. C9-G synchronizes the
M7-A/M7-B boundary and closes M7-B separately without changing any M7-A
algorithm. Complete M7 A/B Module Brief coverage now exists.

GREEN for M7-A remains forbidden until
`DC-GIT-CLI-GATE-A-REPOSITORY-CONTROL` exists and realizes every required
primitive with the exact contract consumed here. This Dependency Contract
remains absent and is not created by C9-G.

M7-B `2.0.1` owns publication, remote observation, publication recovery, and
repository-control executor-domain recovery behavior.
