# TURNLOCK formal assurance

This directory documents how the normative TURNLOCK specification is connected
to formal-assurance artifacts. The governing decisions are
[ADR-015](../adr/adr-015-evolve-the-normative-and-formal-specifications-together.md),
[ADR-041](../adr/adr-041-establish-turnlock-formal-assurance-architecture.md),
and, for hostile-review campaign execution, adjudication, and exact evidence
binding,
[ADR-042](../adr/adr-042-define-auditable-hostile-review-campaign-execution-and-adjudication.md),
[ADR-043](../adr/adr-043-bind-hostile-review-evidence-to-exact-reviewed-inputs.md),
[ADR-044](../adr/adr-044-require-one-unambiguous-gate-a-review-subject.md),
[ADR-045](../adr/adr-045-bind-gate-a-campaigns-to-versioned-review-protocol-and-derived-evidence.md),
[ADR-053](../adr/adr-053-define-deterministic-minimum-effective-hostile-reviewer-acquisition.md), and
[ADR-054](../adr/adr-054-define-provider-reported-effective-model-identity-resolution.md).

## Architecture

```text
normative authority
├─ assurance decomposition → TL-CLAIM
└─ semantic formalization → candidate/canonical formal semantics

TL-CLAIM
↔ hostile-reviewed backend correspondence
↔ actual formal realization

mechanical verifier
→ bounded evidence
→ bounded assurance conclusion
```

Normative product meaning remains `docs/specification/turnlock-spec.md` together
with accepted ADRs. `formal/verification.yaml` is the canonical machine-readable
formal-assurance and traceability graph. It is not product semantics, not the
canonical formal semantics, and not verification evidence.

A future formal realization binding is prospective assurance structure:

```text
formal realization exists
!=
correspondence reviewed
!=
canonical model
!=
verification ready
!=
claim supported
```

## Artifact roles

```text
docs/specification/turnlock-spec.md
= normative product meaning

formal/verification.yaml
= formal-assurance graph: required assurance claims, normative coverage,
  residual assurance, domain bindings, review requirements, evidence contracts

formal/verification.schema.json
= schema for that graph

formal/reviews/*
= durable hostile semantic-review evidence for exact reviewed artifacts

formal/results/*
= concrete mechanism-specific bounded mechanical evidence

formal/migrations/*
= historical migration evidence

formal/Turnlock.tla
= future candidate canonical formal semantic representation (not yet present)

docs/formal/invariant-mapping.md
= generated human-readable projection of the assurance graph
```

## Formalization versus projection

Formalization maps normative natural-language semantics to a formal semantic
representation. It is a reviewed non-mechanical boundary, not a mechanical
derivation.

A formal semantic projection exists only between formal semantic
representations, and its soundness is claim-relative or observation-relative.
A global `equivalent`, `over-approximation`, or `under-approximation` label is
not valid beyond the observations for which the relation is justified. Liveness
requires an explicit preservation argument; projection direction alone does not
establish it.

Verification restriction or instantiation selects and bounds what a focused
checker configuration explores. It is not a new semantics. Independent
formalization is a separately authored formal model used for
semantic-interpretation diversity.

## Review invalidation follows semantic dependency

Review invalidation follows semantic dependency, not physical file
co-location:

```text
formal/verification.yaml
├─ claims + coverage            → Gate A review dependency
└─ formal_realizations          → later correspondence dependency

Changing the second does not invalidate a review whose declared subject is only
the first.
```

Gate A uses the derived `gate-a-assurance-decomposition-v1` subject, which binds
normative authority, the relevant formal-assurance context, the required
assurance claims, and normative coverage. Generated subject fingerprints are
non-authoritative projections of canonical sources.

Semantic dependency also excludes meaningless collection ordering. The Gate A
subject canonicalizes formal semantic domains by `id` and canonicalizes
behavioral/assurance domain sets lexicographically before hashing.

Domain identity is explicit: `policy.formal_semantic_domains[*].id` is unique.

That same identity is used for formal claim bindings and canonical ordering in
the Gate A subject.

## Readiness gates

- **Gate A — Formal-Architecture-Ready** authorizes authoring a candidate
  executable formal model. It requires the accepted assurance architecture, a
  valid metamodel, coverage for every `TL-INV-*`, claims and modalities for the
  candidate scope, explicit residual assurance, an explicit scope, interaction
  closure or justified exclusions, a hostile-review protocol, discovery routing,
  and repository integrity. It also requires valid current campaign evidence
  bound to both the semantic subject `S` and the current hostile-review protocol
  bundle `P`: protocol-qualified reviewer profiles with evidence-derived model
  identities; distinct full and effective model identity counts; complete
  required attack coverage in each qualifying execution; the same exact
  canonical packet and prompt; exact content-addressed
  packet/prompt/protocol/receipt/raw/challenge artifacts; exact one-to-one raw
  finding normalization; a valid zero-objection materiality challenge for every
  non-material finding; no surviving current material `open`, `routed`, or
  `resolved` finding; a valid zero-objection structured challenge for every
  current material `refuted` finding; and current-protocol re-adjudication of
  every stale-protocol finding over the current subject. It requires no checker
  evidence.
- **Gate B — Canonical-Formal-Semantics-Ready** promotes an exact candidate
  artifact/version to the current canonical formal semantics after hostile
  semantic review, disposition of every material finding, re-review of changed
  boundaries, and non-vacuity or semantic-adequacy witnesses.
- **Gate C — Formal-Verification-Ready** authorizes checker executions to
  support assurance claims after real backend bindings and hostile
  claim/property correspondence review, with adequate profiles, explicit bounds,
  exact artifact identity, and evidence-lifting rules.

The current Gate A state is **BLOCKED** only because the required hostile
`assurance-decomposition` review campaign over the exact current
`formal/verification.yaml` has not yet been recorded, not because the metamodel
is incomplete. `scripts/check-formal-traceability.py` derives this state from
repository artifacts and review evidence rather than from a stored status.

Gate A review adequacy is derived from the policy in
`formal/verification.yaml`, from the review-evidence contract, and from the
referenced campaign artifacts, not merely from the existence of a review record.

Gate A distinguishes two things that must not be conflated:

```text
Gate A semantic subject
!=
Gate A review protocol
```

The semantic subject is the derived `gate-a-assurance-decomposition-v1` subject.
The review protocol is how a campaign is executed, sealed, normalized, and
adjudicated.

ADR-042 changes review adequacy mechanics, not
`gate-a-assurance-decomposition-v1` dependencies. ADR-042 is not added to
`formal/verification.yaml authority.architecture_decisions`.

ADR-043 amends hostile-review evidence mechanics only.

ADR-043 does not enter `gate-a-assurance-decomposition-v1`.

ADR-044 amends hostile-review evidence mechanics only.

It does not enter `gate-a-assurance-decomposition-v1`.

It closes subject confusion by making the unique Gate A derived subject the
single identity used for packet binding and currentness.

ADR-045 amends hostile-review protocol and evidence mechanics only.

It does not enter `gate-a-assurance-decomposition-v1`.

Gate A currentness now requires BOTH the exact semantic subject `S` and the
exact current content-addressed hostile-review protocol bundle `P`. The protocol
bundle owns reviewer-profile qualification, evidence-derived model-version
resolution, structured JSON raw outputs, execution receipts, sealed completed
attempts, one-to-one normalization, conservative challenge closure, and the
external campaign outcomes. A protocol change never erases a finding: every
stale-protocol finding over the current subject requires current-protocol
re-adjudication before it can cease affecting Gate A. The review-evidence schema
is version 5.0.

The Gate A semantic subject remains owned by the existing authority dependency
set.

The current valid Gate A semantic-subject fingerprint is mechanically derived
from its authoritative dependency set and is displayed in the generated
[`invariant-mapping.md`](invariant-mapping.md) under
`Gate A assurance-decomposition subject`.

This README does not maintain an independent mutable subject fingerprint.
`formal/verification.yaml` owns the assurance graph; the generated mapping
presents its derived current subject. ADR-042, ADR-043, and ADR-045 do not own
that semantic subject.

Gate A review packets are self-contained canonical JSON artifacts. Verification
recomputes the packet subject SHA from its embedded `subject_payload`, requires
the packet subject to equal a subject declared by the review record, and
recomputes each embedded authority SHA from its UTF-8 contents. A stale
historical packet validates against its own embedded historical subject rather
than current repository authority, so historical evidence remains verifiable
after the repository evolves. Material refutation challenges are bound by
`challenged_refutation_sha256` to the exact canonical refutation subject, and
review evidence paths must be direct non-symlink repository paths.

## Hostile review is first-class evidence, not proof

Hostile semantic review is a first-class assurance mechanism with durable
evidence under `formal/reviews/`. It is adversarial falsification, not majority
voting: one surviving valid material objection blocks acceptance of the reviewed
semantic link regardless of how many reviewers approved. Review evidence never
constitutes mathematical proof of natural-language/formal equivalence; the
strongest valid conclusion is bounded reviewed semantic correspondence under the
executed review protocol. Review evidence is distinct from mechanical checker
evidence. Materiality is derived from explicit impact axes; a non-material
conclusion requires a zero-objection hostile materiality challenge; a material
refutation requires a zero-objection hostile challenge bound to the exact
refutation subject; challenge results are derived from objections without a
free verdict field; and invalid review evidence forces Gate A BLOCKED rather
than being ignored. Failure to establish a valid refutation does not establish
that the finding is true. Every malformed or referentially invalid review
artifact fails repository integrity.

## Generated mapping

`invariant-mapping.md` is generated from `formal/verification.yaml` and current
repository evidence:

```bash
.venv/bin/python scripts/render-formal-mapping.py
```

`scripts/check-formal-traceability.py` validates cross-artifact consistency,
review-evidence integrity, legacy migration totals, and generated-projection
freshness. The renderer first runs a full traceability and review-evidence
validation pass with `check_generated=False`; if that pass reports any error,
rendering fails closed and no readiness state is projected from invalid
evidence. Machine-readable linkage validates traceability consistency; it does
not prove that a future TLA+ formula faithfully captures the prose meaning.
Semantic correspondence remains a hostile-review obligation.

## Hostile-review protocol v6 and immutable meta-schemas

The current hostile-review protocol identity `P` is
`gate-a-campaign-protocol-v6`, and review evidence remains schema `5.0`.
Protocol v6 has exact v5 predecessor, binds
`formal/reviews/meta-schemas/review-protocol-bundle-v6.schema.json`, and
continues to bind unchanged
`formal/reviews/meta-schemas/review-evidence-v5.schema.json`. Execution receipts
remain schema `3.0`. Protocol v1-v5 artifacts remain immutable history. Frozen
unversioned aliases remain inactive.

Protocol v6 preserves v5 deterministic minimum-effective reviewer acquisition
and closes provider-reported effective identity resolution. ADR-054 changes P,
not S, and does not enter Gate A subject dependencies.

Protocol v6 commits minimum-effective, deterministic, content-independent,
round-based reviewer acquisition through the sole protocol-owned
`profile_order`. Registry membership is eligibility, not execute-all authority.
Pinned static duplicate identities may be skipped; provider-reported identities
are not guessed or pre-collapsed; qualified collisions may acquire the next
ordered profile. Selected-WorkItem retry exhaustion never becomes automatic
profile substitution, and pool exhaustion below the effective minimum routes to
`OPERATOR-ACTION-REQUIRED`. `minimum_independent_reviewers` remains
`formal/verification.yaml` policy outside P.

The Python checker remains the finite schema-selection root, challenge input
binding and role-aware retry rules remain unchanged, and protocol history is
recursively validated through `v5 -> v4 -> v3 -> v2 -> v1`. ADR-053 changes no
TURNLOCK semantics and does not enter the Gate A semantic subject.

## Gate A campaign runner construction

The non-authoritative construction sequence for the Gate A hostile-review
campaign runner is documented in
[`gate-a-campaign-runner-construction-plan.md`](gate-a-campaign-runner-construction-plan.md).

The campaign-runner System Brief is stored in
[`nib-s-gate-a-campaign-runner.md`](nib-s-gate-a-campaign-runner.md). Its current
version is `13.0.3`. The brief's own NIB metadata is the sole source for its
construction lifecycle status.

M0 `contracts` is covered by
[`nib-m-gate-a-contracts.md`](nib-m-gate-a-contracts.md), version `1.5.1`. It
consumes active
[`DC-ZOD-GATE-A-CONTRACTS`](dependency-contract-zod-gate-a-contracts.md)
version `1.0.0`, owns the exact 33-domain runner-ID registry, structural runtime
validation, canonical runner JSON, `CampaignArtifactStore` contract,
deterministic Gate A qualification and mechanical-validation obligation
identities, and structural receipt v3/v4 validators without becoming semantic
authority.

M1 `orchestrator` is covered by
[`nib-m-gate-a-orchestrator.md`](nib-m-gate-a-orchestrator.md), version `1.0.0`.
It owns runtime composition, start/resume and recovery choreography, the fresh-
authority loop, deterministic single-step scheduling, P6 execution routing, the
inactive P8 reuse-first lane, candidate/qualification/publication sequencing,
execution-owned abort controllers and final authoritative `RunnerResult`
projection. M1 chooses no campaign semantic, semantic answer, protocol branch,
retry, repair, QLEK, Admission, blocker identity, publication authority or
recovery classification.

M2 `campaign-state` is explicitly decomposed into three active Module Briefs:

- [`nib-m-gate-a-campaign-state-persistence-ownership.md`](nib-m-gate-a-campaign-state-persistence-ownership.md),
  version `3.0.4` — SQLite schema-v2 authoritative persistence, immutable
  artifact storage, bootstrap, ownership, semantic history and fencing;
- [`nib-m-gate-a-campaign-state-mutation-execution.md`](nib-m-gate-a-campaign-state-mutation-execution.md),
  version `9.1.0` — authoritative mutation admission, deterministic Gate A
  qualification-ID admission, mechanical-validation blocker producer checks,
  corrected FindingRef
  provenance, generalized candidate provenance, path-qualified assurance-
  projection media/integrity admission, publication-preparation obligation
  lifecycle, M7-B publication binding validation,
  `AssuranceRepositoryProjectionRef` retention/consumption integrity,
  obligations/blockers, retries, dispatch, recovery admission, qualification,
  and publication state transitions;
- [`nib-m-gate-a-campaign-state-snapshot-integrity.md`](nib-m-gate-a-campaign-state-snapshot-integrity.md),
  version `8.1.0` — deterministic snapshot reconstruction, exact read-only
  historical Execution/Arm/outcome-origin view, corrected finding provenance
  integrity, publication-preparation lifecycle and confirmation-identity
  integrity, M7-B binding validation, unresolved-execution projection,
  retained projection history/consumption integrity, generalized candidate
  provenance integrity, and provenance-root materialization.

M3 `campaign-authority` is covered by one active Module Brief:
[`nib-m-gate-a-campaign-authority.md`](nib-m-gate-a-campaign-authority.md),
version `4.0.1`. It owns deterministic preflight authority interpretation,
exact `(S,P)` currentness, repository review observation/import merge including
exact
M6-projected `referencedArtifacts` closure preservation, reviewer-prerequisite
interpretation, campaign-authority operational causes and blocking obligations,
`GateACampaignAuthorityEvaluationV1` sealing, pure campaign+candidate
`ReviewContext` construction, and preservation of exact M6-projected initial-
reviewer execution inputs.

M3 consumes NIB-S `10.0.0`.

NIB-S 13.0.1 preserves the separation of immutable per-campaign `ReviewContext` from
current-candidate `ResolutionContextV1`.

`ReviewContext` remains production provenance and is never retargeted when a
campaign remains current across a candidate-only change with unchanged `(S, P)`.

M5-B/M5-C post-review roles use `ResolutionContextV1` so candidate-bound repair
realization can continue against the exact current candidate without rewriting
review evidence or campaign provenance.

The Pi M4 Dependency Contract remains text-input/provider-bound and does not
receive either context object.

The active reviewer/campaign boundary is:

```text
M6
→ mechanically projects exact initial-reviewer execution inputs
→ mechanically projects exact P retry policy

M3
→ validates/preserves both without reinterpretation

ReviewCampaignPrerequisiteBasisRefV1
→ retains both durably

M1
→ selects first-round reviewer candidates only

M5
→ consumes retained retry policy for protocol-side retry admissibility
→ uses authoritative Execution history + M2 limits for runner-side caps
```

M6 also projects exact protocol policy. M3 validates it and computes the
complete lexical qualifying set, protocol-ordered acquisition candidates,
statically known pinned identities, and optimistic maximum capacity. M3 never
executes reviewers or resolves provider-reported identity. This boundary changes
no hostile-review semantics.

M3 requires no external Dependency Contract.

M3 performs no Python/Git/provider invocation and no authoritative state write.

M4 `cognitive-execution` is construction-decomposed into M4-A execution /
capture and M4-B recovery observation.

The active M4-A Module Brief is
[`nib-m-gate-a-cognitive-execution-capture.md`](nib-m-gate-a-cognitive-execution-capture.md),
version `2.1.1`.
It owns protocol-qualified context validation, the immutable cognitive WorkItem operation, pre-Arm preparation,
cognitive-call identity, durable execution journal and effect fence, selected
cognitive dependency invocation, exact raw completion and runtime-evidence
capture, the technical-failure versus uncertainty distinction, abort handling,
and non-authoritative liveness telemetry.

The active M4-B Module Brief is
[`nib-m-gate-a-cognitive-execution-recovery-observation.md`](nib-m-gate-a-cognitive-execution-recovery-observation.md),
version `1.1.0`.

It owns exact P8-aware recovery observation and validation of the cognitive recovery capability, read-only M4
journal interpretation, positive PREPARED-only non-execution proof, exact local
terminal reconstruction, and executor-domain indeterminacy for MAYBE-SENT
without terminal truth.

For the selected Pi backend, M4-B has no legal `pending` branch because the
active Pi Dependency Contract exposes no qualified safe observational
provider-side recovery operation and forbids replay.

The active Pi M4 Dependency Contract is
[`dependency-contract-pi-m4-cognitive-execution.md`](dependency-contract-pi-m4-cognitive-execution.md),
`DC-PI-M4-GATE-A-COGNITIVE-EXECUTION` version `1.1.4`.

It pins `@earendil-works/pi-ai@0.99.2` / Pi
`005af57d88ee23b33778f343a9595b32e67ff788`, the direct
`Models.streamSimple(...)` boundary, the selected `openai-codex` SSE execution
path, exact request/provider evidence capture, raw completion extraction,
credential injection, terminal/uncertain classification, and the conservative
no-provider-recovery limitation. Version `1.1.0` preserves version `1.0.1`'s
exact four-field synchronous planning interface, unsealed three-result adapter
boundary, and M4-owned strict UTF-8, evidence-sealing, raw-result, and terminal-
journal ownership closures.

ADR-054 resolves provider-reported semantics. M4-A remains version `2.1.1` and
delegates exact identity-channel capability qualification to the Pi M4
Dependency Contract while preserving raw evidence. Pi M4 Dependency Contract
version `1.1.4` retains provider-owned response/effective-model evidence
capture as `ESTABLISHED`, but records
`provider-owned-canonical-effective-model-identity-v1` as `NOT-ESTABLISHED` for
the current `openai-codex` / `gpt-6.1-sol` qualification evidence.

M5 `assurance-ledger` is decomposed into exactly four active Module Briefs:

- [`nib-m-gate-a-assurance-ledger-campaign-work-execution-receipt.md`](nib-m-gate-a-assurance-ledger-campaign-work-execution-receipt.md),
  M5-A version `3.1.0` — campaign work, common cognitive execution history,
  P6 receipt-v3, P8 receipt-v4, Stage-B evidence packaging and explicit P8
  completion/contribution facades;
- [`nib-m-gate-a-assurance-ledger-finding-adjudication.md`](nib-m-gate-a-assurance-ledger-finding-adjudication.md),
  M5-B version `1.1.0` — finding import/normalization, materiality/refutation
  progression, exact M6-work exposure and P8 supplements;
- [`nib-m-gate-a-assurance-ledger-resolution-qualification.md`](nib-m-gate-a-assurance-ledger-resolution-qualification.md),
  M5-C version `1.1.0` — serialized surviving-material resolution, exact
  M6-work exposure, DecisionRequest and exact-candidate RepairIntent
  qualification;
- [`nib-m-gate-a-assurance-ledger-repository-projection-readiness.md`](nib-m-gate-a-assurance-ledger-repository-projection-readiness.md),
  M5-D version `1.1.0` — deterministic repository projection with exact source
  bytes and path-qualified media, readiness, mechanical A/B/C/D composition and
  the pure replayable M5↔M6 progression broker.

The active M6 Module Brief is
[`nib-m-gate-a-mechanical-validation.md`](nib-m-gate-a-mechanical-validation.md),
version `1.2.0`. It owns exact Python-backed mechanical validation, the additive
C9-E helper surfaces and exact mechanical-validation failure
obligation/cause derivation while preserving C9-D Stage A/Stage B.

### Accepted M5 adjudication / resolution protocol evolution

ADR-055 is accepted protocol authority for the next Gate A
hostile-review protocol evolution.

It defines protocol v7 structured contracts for M5-B review-evidence
adjudication and M5-C resolution qualification, including deterministic
supporting-role acquisition, structured adjudication packets/outputs,
candidate-bound realization, explicit already-realized repair qualification,
genuine decision-necessity qualification, and mandatory bounded same-family
closure revision.

The detailed P7 construction now additionally fixes:

```text
closure challenge contracts are selected by
(challenge_kind, challenge_subject.selector), never challenge_kind alone

UniqueCorrection and RealizationScope therefore use separate derivation
challenge contracts and separate exact objective sets

review-evidence schema 5.0 remains the immutable ReviewCampaign-record schema

protocol v7 adds a separate immutable FindingAdjudicationSupplementV1 artifact
for append-only current adjudication of an immutable original finding

supplements are not ReviewCampaigns and never count toward independent-reviewer
minimums

a supplement can make a finding non-blocking only through:
- qualified non-materiality
- qualified refutation

every other terminal P7 lineage remains surviving-material

repair qualification, NoNormativeImpact, DecisionRequest, SemanticBlocker and
operator outcomes do not erase a material finding

new P7 cross-campaign adjudication uses supplements rather than emitting a new
schema-5 re_adjudications[] member
```

Historical schema-5 `re_adjudications[]` remain valid for the protocol versions
that produced them.

ADR-055 remains accepted authority for the published protocol-v7 structured
adjudication design. ADR-056 is accepted authority for the next Gate A
hostile-review protocol evolution.

The stable non-authoritative protocol-v8 construction sequence is documented in
[`gate-a-protocol-v8-construction-plan.md`](gate-a-protocol-v8-construction-plan.md).
The C1 SemanticQuestionContract construction closure is documented in
[`gate-a-protocol-v8-semantic-question-contract-catalog.md`](gate-a-protocol-v8-semantic-question-contract-catalog.md).
The C2 semantic-identity-algebra construction closure is documented in
[`gate-a-protocol-v8-semantic-identity-algebra.md`](gate-a-protocol-v8-semantic-identity-algebra.md).
The C3 SemanticAdmission-authority and execution-fencing construction closure is
documented in
[`gate-a-protocol-v8-semantic-admission-authority-execution-fencing.md`](gate-a-protocol-v8-semantic-admission-authority-execution-fencing.md).
The C4 SemanticFact and qualification-resolution construction closure is
documented in
[`gate-a-protocol-v8-semantic-fact-qualification-resolution.md`](gate-a-protocol-v8-semantic-fact-qualification-resolution.md).
The C5 candidate-bound identity and CandidateView construction closure is
documented in
[`gate-a-protocol-v8-candidate-bound-identity-candidate-view.md`](gate-a-protocol-v8-candidate-bound-identity-candidate-view.md).

The C6 packet, receipt, and evidence-projection construction closure is
documented in
[`gate-a-protocol-v8-packet-receipt-evidence-projections.md`](gate-a-protocol-v8-packet-receipt-evidence-projections.md).

Protocol v7 is an immutable validated predecessor and regression artifact. Under
ADR-056 it is permanently inactive and MUST NOT subsequently be selected as
current.

Protocol v8 artifact and construction authority now exists, but no protocol-v8
artifact is current merely because construction is complete. Protocol v6
remains current until C15 explicitly selects the exact immutable P8 bundle.

Therefore:

```text
P6 remains current
execution-receipt schema 3.0 remains current for P6
review-evidence schema 5.0 remains current for P6
NIB-S-GATE-A-CAMPAIGN-RUNNER 13.0.3 is active
M5-A/B/C/D construction is closed by the four active briefs
P7 remains immutable, mechanically validated and permanently inactive
P8 artifact/construction authority exists and remains inactive until C15
C9-E is closed
C9-F is closed
C9-G is closed
C9-H is closed
all M0-M8 implementation modules now have active decisional-complete NIB-M coverage
Issue #30 acceptance is satisfied by the C9-H repository revision
C9-I/A Zod dependency-contract closure is closed
DC-ZOD-GATE-A-CONTRACTS 1.0.0 is active
C9 / G-C9 remains open because DC-GIT-CLI-GATE-A-REPOSITORY-CONTROL is absent
C9-I dependency-contract closure continues only with the separate Git boundary
C10/NIB-T has not begun
no protocol-v7 or protocol-v8 behavior becomes active through these briefs
```

The inactive protocol-v7 candidate fixes the exact adjudication-packet namespace
as `formal/reviews/adjudication-packets/*.json`, keeps adjudication outputs under
`formal/reviews/adjudications/*.json`, and projects immutable supplements under
`formal/reviews/supplements/<supplement-sha256>.json`. The checker validates the
candidate bundle and these closed namespace, identity, supporting-DAG, and
effective-overlay contracts without selecting P7 as current.

Protocol-v8 construction authority under ADR-056 preserves immutable
`ReviewContext` for initial-review production provenance and preserves
the accepted separation of post-review adjudication/resolution provenance from
initial-review production provenance.

`FindingAdjudicationSubject` bootstraps the exact materiality/refutation lineage.

A positively material finding whose lawful refutation path terminates without a
qualified refutation may then be promoted to the separate surviving-material
resolution boundary.

Where later adjudication belongs to an immutable source campaign rather than the
same not-yet-projected campaign record, the accepted adjudication architecture
uses an append-only finding-adjudication overlay rather than rewriting the source
campaign or creating a synthetic writable campaign.

Campaign currentness remains defined only over real ReviewCampaign records.

M7 `repository-control` is construction-decomposed into M7-A materialization /
candidate construction and M7-B publication / remote observation / recovery.

The active M7-A Module Brief is
[`nib-m-gate-a-repository-control-materialization-candidate-construction.md`](nib-m-gate-a-repository-control-materialization-candidate-construction.md),
version `2.1.2`. It owns repository inspection, exact baseline Git basis,
publication-target identity resolution, canonical C0 materialization, exact
RepairIntent patch application, exact assurance repository projection
application, combined repair plus assurance successor construction, Git tree
projection, deterministic publication successor `T`, and the internal M7-A →
M7-B successor boundary.

Version `2.1.0` closes:

```text
C9-F M5-D→M7 assurance-projection synchronization
M0 canonical-JSON ownership synchronization
exact P6/P8 projection namespace validation
raw evidence media preservation
exact projection-content→candidate-blob carrier conversion
repair+projection raw-path prevalidation
```

M5 chooses assurance content and intended repository placement. M7-A applies
that projection mechanically and interprets no hostile-review or semantic
meaning. M2 remains the authoritative state writer, M6 remains the semantic-
subject/mechanical-validation boundary, and M1 remains choreography owner.

It selects `DC-GIT-CLI-GATE-A-REPOSITORY-CONTROL` as a required separate
Dependency Contract before GREEN. The contract remains absent, so M7-A is not
GREEN.

The active M7-B Module Brief is
[`nib-m-gate-a-repository-control-publication-remote-recovery.md`](nib-m-gate-a-repository-control-publication-remote-recovery.md),
version `2.0.1`. It owns exact target-predecessor observation, positive
fast-forward proof, publication preparation and realization selection,
publication intent/obligation/WorkItem construction, pre-Arm target
revalidation, conditional predecessor-enforced mutation, direct outcome
capture, confirmation/non-application qualification, published-view
construction, and read-only repository-control recovery.

Together M7-A and M7-B provide complete M7 Module Brief coverage while
preserving `M7-A = T` and `M7-B = P / P <= T / remote execution and recovery`.
M7-B consumes M0 canonical JSON and leaves recovery classification and blocker
materialization to unchanged M8-A/M8-B.

Issue #87 correction: selected v1 M7-B cannot infer the historical terminal
outcome of an uncertain armed publication Execution from the current remote
target equaling T. Exact T observation yields read-only pending continuability,
not a recovered captured result. M8/M2 remain the existing recovery/admission
owners. The Git Dependency Contract remains absent and live publication
transport conformance remains unqualified.

M8 `recovery-operator` is architecturally decomposed into two active Module
Briefs:

- [`nib-m-gate-a-recovery-operator-reconciliation.md`](nib-m-gate-a-recovery-operator-reconciliation.md),
  version `2.1.0` — M8-A exact unresolved-execution validation, executor-owned
  recovery-port invocation, deterministic bounded re-observation, recovery evidence
  projection, immutable reconciliation traces, and restart-safe episode
  behavior;
- [`nib-m-gate-a-recovery-operator-boundary.md`](nib-m-gate-a-recovery-operator-boundary.md),
  version `2.1.0` — M8-B deterministic operational-blocker
  identity/materialization, immutable Operator Action Requests, recovery-blocker reuse/disposition, aggregate
  RecoveryPlan blocker behavior, operator-resolution ingestion, and explicit
  operator-authorized Execution supersession mapping.

Together these briefs close M8 construction responsibility while preserving the
boundary that executor/domain modules establish domain facts, M8 normalizes the
operator/recovery boundary, and M2 alone admits authoritative state changes.

The persistence/ownership Module Brief consumes active
`DC-SQLITE-NODE-GATE-A-CAMPAIGN-STATE` version `1.0.1`. M0 consumes active
[`DC-ZOD-GATE-A-CONTRACTS`](dependency-contract-zod-gate-a-contracts.md)
version `1.0.0`; this closes M0's external validation dependency boundary
without adding production implementation. C9-H selected no new external
dependency. `DC-GIT-CLI-GATE-A-REPOSITORY-CONTROL` remains required and absent;
M7-A, M7-B, M1 and the TURNLOCK runner are not GREEN. Complete M0-M8 NIB-M and
M0 Dependency Contract coverage does not establish Formal-Architecture-Ready or
alter formal assurance readiness.

That document is a stable construction map, not a live work tracker, product
authority, hostile-review protocol, or evidence record. GitHub Issues, native
relationships, and Turnlock-Rust Engineering own live implementation work
state.
