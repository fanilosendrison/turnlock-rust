---
okf_version: "1.0"
kind: "RuntimeArtifact"
format: "nib-module"
workspace: "turnlock-rust"
date: "2026-09-20"
step_id: 2
id: NIB-M-GATE-A-CAMPAIGN-STATE-MUTATION-EXECUTION
version: "9.1.0"
scope: gate-a-campaign-runner/campaign-state/mutation-execution
status: active
consumers: [architect, coding-agent]
superseded_by: []
---

# NIB-M — Gate A Campaign State — Mutation Admission and Execution Lifecycle

## 1. Status, authority, and purpose

This document is one of three active Module Briefs that together close M2
`campaign-state` for the Gate A hostile-review campaign runner.

It consumes:

```text
NIB-S-GATE-A-CAMPAIGN-RUNNER 13.0.1
NIB-M-GATE-A-CONTRACTS 1.5.0
NIB-M-GATE-A-MECHANICAL-VALIDATION 1.2.0
NIB-M-GATE-A-REPOSITORY-CONTROL-PUBLICATION-REMOTE-RECOVERY 1.0.0
```

Version `9.1.0` additively synchronizes M2 with NIB-S `13.0.1`, M0 `1.5.0`
and M6 `1.2.0`. It adds deterministic GateAQualificationId admission and exact
mechanical-validation blocker producer validation. It adds no mutation kind,
changes no closed mutation-union shape, SQLite schema, persistence ownership,
product/protocol semantic, recovery classification, blocker ownership or M2
state-writer authority.

Version `9.0.0` is a breaking implementation-construction synchronization with
NIB-S `13.0.0`, M0 `1.4.0`, and M7-B `1.0.0`. It adds exact publication-
preparation obligation lifecycle plumbing, M7-B publication binding validation,
deterministic confirmation identity validation, and mandatory publication
recovery-capability validation. It changes no mutation-union shape, SQLite
schema, persistence ownership, product semantic, protocol semantic, recovery
classification, blocker ownership, or M2 state-writer authority.

Version `8.0.1` is a representation/dependency synchronization with NIB-S
`12.0.1` and the complete M5-D projection contract. It changes no mutation
kind, authoritative schema, SQLite schema or migration, and no M2 ownership.
M2 remains the structural/integrity and authoritative-admission boundary; it
acquires no review or model-output semantic interpretation.

Version `8.0.0` is a breaking construction-contract revision only because the
`FindingRef` provenance shape changes. It adds no finding semantic
interpretation and preserves M2 as structural/authority admission owner only.

Version `7.0.0` is a breaking construction-contract revision. It adds the exact
protocol-v8 semantic Execution authorization, atomic semantic Arm, authoritative
M6 validation retention, completion/admission reconciliation, conflict, and
cross-domain merge effects while preserving all P1-P7 behavior. No production
runner state exists, so no runtime migration mechanism is required.

Version `6.0.1` was a dependency-only synchronization with NIB-S `10.0.0`. It
changes no mutation algorithm, type, ownership, retry, hard-limit, provider,
recovery, or repository semantic. The retained
`ReviewCampaignPrerequisiteBasisRefV1.reviewContext` remains exact immutable
review provenance and is not replaced by `ResolutionContextV1`.

Version `6.0.0` is a breaking construction-contract revision because the
complete persisted `ReviewCampaignPrerequisiteBasisRefV1` gains the exact
retry-policy fact projected from the campaign's bound protocol P. No mutation
kind, hostile-review semantic, retry semantic, runner hard limit, or M2
ownership changes.

Version `5.0.0` is a breaking construction-contract revision because the
complete persisted `ReviewCampaignPrerequisiteBasisRefV1` shape gains the
retained `ReviewContext` and initial-reviewer execution-input basis required
before M5-A. No SQLite implementation exists yet, so no runtime migration is
required. M2 ownership and authoritative mutation semantics are unchanged.

Version `4.0.2` was a dependency-only compatibility synchronization with NIB-S
`9.1.0`. It changed no algorithm, type, or module invariant.

Version `4.0.1` closes only the exact retained prerequisite-basis projection
required by NIB-S `9.0.1`. M2 gains no acquisition-selection semantics.

Version `4.0.0` is a breaking construction-contract revision only because the
persisted reviewer-prerequisite admission basis shape changes under ADR-053.
M2 remains the sole authoritative state writer and acquires no reviewer-
acquisition selection, round-construction, identity-resolution, finding-
interpretation, or assurance-cause semantics.

It is implementation-construction authority only. It does not define TURNLOCK
product semantics, canonical formal semantics, hostile-review protocol
semantics, formal-assurance claims, review evidence, or verification evidence.

This brief defines the complete M2 authoritative run-mutation language, the
algorithms that admit campaign facts into Authoritative History, and the exact
T4/T5 global semantic-history effects.

Every successful GateARun mutation is one atomic append-only `StateRevision`.
T4 and T5 are separate global semantic-history transitions and create no
GateARun `StateRevision`.

M2 validates authority, identity, structural consistency, causal preconditions,
and global invariants.

It does not invent M3 currentness, M5 assurance meaning, M6 validator
conclusions, M7 repository facts, or M8 recovery classifications.

Persistence and ownership mechanics are defined by
`NIB-M-GATE-A-CAMPAIGN-STATE-PERSISTENCE-OWNERSHIP`.

Snapshot reconstruction and retained-state integrity are defined by
`NIB-M-GATE-A-CAMPAIGN-STATE-SNAPSHOT-INTEGRITY`.

## 2. Public input/output

The public mutation boundary remains exactly:

```ts
interface CommitAuthoritativeMutationRequest {
  readonly runId: GateARunId;
  readonly authority: WriteAuthorityRef;
  readonly expectedStateRevision: StateRevision;
  readonly mutation: AuthoritativeMutationRef;
}

type CommitAuthoritativeMutationResult =
  | {
      readonly kind: "committed";
      readonly newStateRevision: StateRevision;
      readonly snapshot: GateARunSnapshot;
    }
  | {
      readonly kind: "stale-state";
      readonly currentStateRevision: StateRevision;
    }
  | {
      readonly kind: "ownership-lost";
      readonly currentOwnershipGeneration: OwnershipGeneration;
    };
```

Malformed mutation input, contradictory proposed history, or inability to trust
authoritative state is not encoded as another branch of this union.

It rejects the invocation as an implementation/process/integrity failure.

The separate global semantic completion boundary is exactly:

```ts
reconcileSemanticCompletion(
  request: ReconcileSemanticCompletionRequestV1
): Promise<ReconcileSemanticCompletionResultV1>;
```

T5 uses the exact cross-module request/result declared by M0 and the persistence
brief. Neither global boundary uses `CommitAuthoritativeMutationRequest` or
requires GateARun WriteAuthority.

## 3. Serialized mutation envelope

`AuthoritativeMutationRef.artifact` must contain UTF-8 JSON validating exactly
as:

```ts
interface GateAStateMutationArtifactV1 {
  readonly schema: "gate-a-state-mutation.v1";
  readonly runId: GateARunId;
  readonly baseStateRevision: StateRevision;
  readonly mutation: GateAStateMutationV1;
}
```

The artifact must already exist in the immutable artifact store before the
SQLite transaction begins.

The mutation artifact itself is immutable provenance.

M2 additionally inserts normalized authoritative facts from its validated
content.

## 4. Closed mutation union

```ts
type GateAStateMutationV1 =
  | EstablishPreflightV1
  | AdmitCandidateV1
  | EstablishReviewCampaignBundleV1
  | EstablishOperationalBlockersV1
  | AuthorizeExecutionV1
  | AuthorizeSemanticExecutionV1
  | ArmExecutionDispatchV1
  | ArmSemanticExecutionDispatchV1
  | AdmitExecutionOutcomeV1
  | AdmitExecutionUncertaintyV1
  | AdmitExecutionRecoveryV1
  | AdmitAssuranceLedgerDeltaV1
  | AdmitMechanicalValidationObservationV1
  | AdmitProtocolV8SemanticValidationV1
  | AdmitGateAQualificationV1
  | EstablishPublicationIntentV1
  | AdmitPublicationObservationQualificationV1
  | AdmitOperatorResolutionV1
  | EstablishGateAReadyV1;
```

No `"generic"`, `"custom"`, `"patch"`, or `"other"` mutation kind exists.

## 5. Mutation types

### 5.1 Preflight

```ts
interface EstablishPreflightV1 {
  readonly kind: "establish-preflight";
  readonly repositoryInspection: RepositoryInspectionRef;
  readonly baselineAuthority: RepositoryAuthorityRef;
  readonly publicationTarget: RepositoryPublicationTargetRef;
  readonly protocolBundle: ProtocolBundleRef;
  readonly baselineSemanticSubject: SemanticSubjectRef;
  readonly subjectProjection: ArtifactRef;
  readonly reviewAuthorityProjection: ArtifactRef;
  readonly preflightEvidence: readonly ArtifactRef[];
  readonly rootObligationDisposition: Extract<
    ObligationDispositionRef,
    { readonly kind: "satisfied" }
  >;
}
```

This mutation is accepted at most once per run.

M2 validates:

```text
repositoryInspection.runId == exact run

baselineAuthority ==
    repositoryInspection.baselineAuthority

publicationTarget ==
    repositoryInspection.publicationTarget

baselineSemanticSubject ==
    exact established PreflightResolution.baselineSemanticSubject

subjectProjection ==
    exact established PreflightResolution.subjectProjection

reviewAuthorityProjection ==
    exact established PreflightResolution.reviewAuthorityProjection

subjectProjection intact
reviewAuthorityProjection intact

repositoryInspection sealed-baseline bindings pass NIB-S

every RepositoryInspectionRef ArtifactRef exists and is intact

preflightEvidence duplicate-free
every preflightEvidence ArtifactRef intact

subjectProjection is not duplicated inside preflightEvidence
reviewAuthorityProjection is not duplicated inside preflightEvidence

rootObligationDisposition names exact bootstrap root obligation

rootObligationDisposition.basisEvidenceIds == []

rootObligationDisposition.basisArtifacts equals exactly the ordered

duplicate-free first-occurrence sequence:

[
    repositoryInspection.baselineGitBasis,
    repositoryInspection.sealedBaselineCandidate.materialization,
    ...repositoryInspection.sealedBaselineCandidate.materializationEvidence,
    ...repositoryInspection.evidence,
    subjectProjection,
    reviewAuthorityProjection,
    ...preflightEvidence
]
```

After successful admission of `EstablishPreflightV1`, the returned
`GateARunSnapshot` must satisfy:

```text
snapshot.repositoryInspection ==
    mutation.repositoryInspection

snapshot.preflightSemanticSubject ==
    mutation.baselineSemanticSubject

snapshot.preflightProtocolBundle ==
    mutation.protocolBundle

snapshot.preflightSubjectProjection ==
    mutation.subjectProjection

snapshot.preflightReviewAuthorityProjection ==
    mutation.reviewAuthorityProjection

snapshot.run.initialRepositoryAuthority ==
    mutation.baselineAuthority

snapshot.run.publicationTarget ==
    mutation.publicationTarget
```

This is a projection requirement only. It adds no persisted fact or write path.

The following is a legal resumable state:

```text
unique EstablishPreflightV1 exists
root preflight obligation satisfied
repositoryInspection != null
preflightSemanticSubject != null
preflightProtocolBundle != null
preflightSubjectProjection != null
preflightReviewAuthorityProjection != null
candidates == []
currentCandidate == null
```

It represents interruption after `EstablishPreflightV1` and before
`AdmitCandidateV1(C0)`. Admission of C0 after restart uses only the exact
retained preflight facts and exact sealed baseline candidate.

### 5.2 Candidate

```ts
interface AdmitCandidateV1 {
  readonly kind: "admit-candidate";
  readonly sealedCandidate: SealedCandidateMaterializationRef;
  readonly candidate: CandidateRevisionRef;
}
```

Candidate identity is M2-owned.

Before the C0/Cn+1 split, M2 requires the following common bindings:

```text
candidate.runId ==
    exact GateARun runId

sealedCandidate.runId ==
    exact GateARun runId

candidate.materialization ==
    sealedCandidate.materialization
```

A mismatch is:

```text
INVALID_MUTATION
```

For `C0`, retain every accepted preflight requirement and require:

```text
ordinal = 0
parentCandidateId = null
producedByRepairIntentId = null
producedByAssuranceProjectionId = null

sealedCandidate.parentCandidateId == null
sealedCandidate.producedByRepairIntentId == null
sealedCandidate.producedByAssuranceProjectionId == null

candidate.parentCandidateId == null
candidate.producedByRepairIntentId == null
candidate.producedByAssuranceProjectionId == null
```

For `AdmitCandidateV1` when `ordinal = 0`:

```text
exact EstablishPreflightV1 exists
sealedCandidate ==
    EstablishPreflightV1.repositoryInspection.sealedBaselineCandidate
candidate.semanticSubject ==
    EstablishPreflightV1.baselineSemanticSubject ==
    snapshot.preflightSemanticSubject
EstablishPreflightV1.subjectProjection exists and is intact
EstablishPreflightV1.reviewAuthorityProjection exists and is intact
```

C0 does not require another subject derivation and cannot replace any retained
preflight fact. The legal crash state between preflight and C0 remains intact.

For every non-C0 admission, let:

```text
P = exact currentCandidate before mutation
R = exact retained RepairIntentRef named by
    candidate.producedByRepairIntentId, or null
A = exact retained AssuranceRepositoryProjectionRef named by
    candidate.producedByAssuranceProjectionId, or null
```

Require:

```text
R != null OR A != null
candidate.ordinal == P.ordinal + 1
candidate.parentCandidateId == P.candidateId
sealedCandidate.parentCandidateId == P.candidateId
candidate.producedByRepairIntentId ==
    sealedCandidate.producedByRepairIntentId
candidate.producedByAssuranceProjectionId ==
    sealedCandidate.producedByAssuranceProjectionId
candidate.materialization == sealedCandidate.materialization
```

If `R != null`, require exactly one such retained value and:

```text
R.runId == exact GateARun runId
R.candidateId == P.candidateId
candidate.producedByRepairIntentId == R.repairIntentId
sealedCandidate.materializationEvidence contains exact R.approvedPatch
```

If `R == null`, both repair provenance fields are null.

If `A != null`, require exactly one such retained value and:

```text
A.runId == exact GateARun runId
A.sourceCandidateId == P.candidateId
A.semanticSubject == P.semanticSubject
A.projection exists and is intact
candidate.producedByAssuranceProjectionId == A.projectionId
sealedCandidate.materializationEvidence contains exact A.projection
```

If `A == null`, both assurance-projection provenance fields are null.

Every non-C0 sealed candidate retains exact `P.materialization`. Every required
artifact exists and is intact. `contains exact` means exact `ArtifactRef`
structural equality.

For assurance-only (`R == null`, `A != null`), require:

```text
candidate.semanticSubject == P.semanticSubject == A.semanticSubject
```

Failure is `INVALID_MUTATION`; M2 makes no campaign interpretation.

Identity is exactly:

```text
deriveId(
  "candidate-revision.v2",
  runId,
  decimal ordinal,
  parentCandidateId or "-",
  producedByRepairIntentId or "-",
  producedByAssuranceProjectionId or "-"
)
```

The materialization and semantic subject are payload bound to that slot. A
second incompatible payload is `INVALID_MUTATION`.

Before admission require independently:

```text
if R != null:
    zero prior CandidateRevision names R.repairIntentId

if A != null:
    zero prior CandidateRevision names A.projectionId
```

A second consumer is `INVALID_MUTATION`. No mutable repair/projection consumed
flag or consumed revision exists. Candidate existence is the append-only
consumption fact. Repair and projection authority are exact parent-occurrence
specific.

Replay semantics:

M7-A may seal deterministic successor artifacts and crash before
`AdmitCandidateV1`.

Because no authoritative candidate was admitted, restart may replay the same
exact sourceCandidate plus the same exact nullable RepairIntentRef and
AssuranceRepositoryProjectionRef and reproduce the same sealed successor.

For every replayed non-C0 construction, at least one of the repair/projection
authorities remains non-null exactly as required by the accepted
CandidateConstructionRequest.

Once an admitted CandidateRevision names a non-null RepairIntent R through
`producedByRepairIntentId == R.repairIntentId`, R is consumed and ordinary
orchestration must not invoke M7-A using R again.

Once an admitted CandidateRevision names a non-null
AssuranceRepositoryProjection A through
`producedByAssuranceProjectionId == A.projectionId`, A is consumed and ordinary
orchestration must not invoke M7-A using A again.

For a combined repair + assurance successor, that one admitted
CandidateRevision consumes both exact authorities simultaneously.

No mutable repair/projection consumed flag exists.

No special recovery protocol is introduced.

No Execution is involved.

No external-effect Arm is involved.

During every successful non-C0 `AdmitCandidateV1`, for every outstanding
publication-preparation obligation whose `candidateId` equals the prior current
candidate `P.candidateId`, append exactly one disposition in the same revision:

```ts
{
  kind: "superseded",
  obligationId: exact old preparation obligation,
  replacementObligationIds: [],
  basisEvidenceIds: [],
  basisArtifacts:
    orderedUnique([
      sealedCandidate.materialization,
      ...sealedCandidate.materializationEvidence
    ])
}
```

This is lifecycle plumbing only. It does not establish publication truth.

### 5.3 Review campaign bundle

```ts
interface EstablishReviewCampaignBundleV1 {
  readonly kind: "establish-review-campaign-bundle";
  readonly campaign: ReviewCampaignRef;
  readonly prerequisiteBasis:
    ReviewCampaignPrerequisiteBasisRefV1;
  readonly obligations: readonly ObligationRef[];
  readonly workItems: readonly WorkItemRef[];
}
```

For every `EstablishReviewCampaignBundleV1`, require exactly:

```text
campaign.provenance.kind == runner-produced

campaign.provenance.originatingRunId ==
    exact GateARun runId

prerequisiteBasis.reviewCampaignId ==
    campaign.reviewCampaignId

prerequisiteBasis.candidateId ==
    campaign.provenance.candidateId

prerequisiteBasis.semanticSubject ==
    campaign.semanticSubject

prerequisiteBasis.protocolBundle ==
    campaign.protocolBundle

prerequisiteBasis.retryPolicy runtime-validates as
    GateACognitiveRetryPolicyMechanicalFactV1

prerequisiteBasis.retryPolicy contains no runner-limit fields

prerequisiteBasis.retryPolicy role arrays contain only
    CognitiveExecutionRole values

prerequisiteBasis.retryPolicy role arrays are duplicate-free

prerequisiteBasis.reviewContext.campaign ==
    campaign

prerequisiteBasis.reviewContext.runId ==
    campaign.provenance.originatingRunId

prerequisiteBasis.reviewContext.candidate.candidateId ==
    campaign.provenance.candidateId

prerequisiteBasis.initialReviewerExecutionInputs.prompt exists and is intact

prerequisiteBasis.initialReviewerExecutionInputs.packet exists and is intact

prerequisiteBasis.initialReviewerExecutionInputs.prompt.repositoryPath == null

prerequisiteBasis.initialReviewerExecutionInputs.packet.repositoryPath == null

prerequisiteBasis.initialReviewerExecutionInputs.packetRepositoryPath ==
    "formal/reviews/packets/" +
    prerequisiteBasis.initialReviewerExecutionInputs.packet.sha256 +
    ".json"
```

Runtime-validate every NIB-S basis invariant, including exact candidate order,
qualifying-profile set equality, identity-resolution/static-identity bindings,
duplicate freedom, evidence integrity, and campaign bindings. M2 does not
recompute selection or candidate order.

M2 recomputes and requires:

```text
campaign.reviewCampaignId ==
deriveReviewCampaignId(
    "review-campaign.v1",
    runId,
    campaign.semanticSubject.selector,
    campaign.semanticSubject.sha256,
    campaign.protocolBundle.protocolId,
    campaign.protocolBundle.sha256
)
```

The same logical `ReviewCampaignId` with a different payload is
`INVALID_MUTATION`. An exact duplicate already-present campaign is not inserted
a second time.

Given campaign `C`, established `ReviewerPrerequisiteResolution P`, and exact
M3-produced `ReviewContext R`, M1 constructs exactly:

```ts
ReviewCampaignPrerequisiteBasisRefV1 {
  reviewCampaignId:
    C.reviewCampaignId,

  candidateId:
    C.provenance.candidateId,

  semanticSubject:
    C.semanticSubject,

  protocolBundle:
    C.protocolBundle,

  retryPolicy:
    P.retryPolicy,

  reviewContext:
    R,

  initialReviewerExecutionInputs:
    P.initialReviewerExecutionInputs,

  minimumIndependentReviewers:
    P.minimumIndependentReviewers,

  acquisitionMode:
    P.acquisitionMode,

  qualifyingReviewerProfileIds:
    P.qualifyingReviewerProfileIds,

  reviewerAcquisitionCandidates:
    P.reviewerAcquisitionCandidates,

  evidence:
    P.evidence,
}
```

Apply no field transformation, sorting, normalization, or profile rewriting.
M1 selects only the first-round acquisition candidates. M5 constructs the
protocol-derived assurance obligations and WorkItems for those selected
reviewers and returns the complete initial ledger products to M1.

The campaign, prerequisite basis, and complete initial M5-produced
obligations/WorkItems are committed atomically in the same revision. M2
preserves the exact complete supplied prerequisite basis. M2 does not derive
`retryPolicy`, read P, reinterpret `retryPolicy`, apply it during campaign-
bundle admission, or merge it with runner hard limits. The first reviewer-
acquisition round is part of those M5-owned semantic products after first-round
selection by M1.

The exact `prerequisiteBasis` is retained inside the immutable authoritative
`EstablishReviewCampaignBundleV1` mutation artifact. No extra mutable record is
authority.

Later reviewer-acquisition WorkItems may be added only through the existing
`AdmitAssuranceLedgerDeltaV1` path. No new mutation kind and no additional state
writer are introduced.

M2 validates only exact structural and binding integrity. It MUST NOT choose
reviewer profiles, compute acquisition rounds, interpret finding content, guess
provider-reported identities, decide pool-exhaustion semantics, or create M5
operational causes. M2 does not reconstruct the prompt or packet, read P,
construct `ReviewContext`, or select any reviewer.
`EstablishReviewCampaignBundleV1` remains unchanged in name and external shape;
its existing `prerequisiteBasis` now uses the corrected V1 basis.

No runner-created executable campaign may become visible before its complete
initial bundle is admitted.

Imported repository campaigns are not created through this mutation; they are
registered from exact M3 evaluation context during
`AdmitAssuranceLedgerDeltaV1`.

### 5.4 Operational blockers

```ts
interface EstablishOperationalBlockersV1 {
  readonly kind: "establish-operational-blockers";
  readonly obligationsToAdd: readonly ObligationRef[];
  readonly blockers: readonly OperationalBlocker[];
  readonly basisArtifacts: readonly ArtifactRef[];
}
```

Require exactly:

```text
blockers is non-empty

obligationsToAdd is duplicate-free by obligationId

obligationsToAdd is ordered by obligationId unsigned ASCII ascending

every obligationsToAdd ObligationRef:
    belongs to exact GateARun
    has an intact definition ArtifactRef
    has no already-admitted incompatible logical payload

every obligation in obligationsToAdd is referenced by at least one blocker
co-admitted in the same EstablishOperationalBlockersV1

every blocker.obligationId names exactly one:
    already-admitted obligation
    OR
    obligation in obligationsToAdd
```

An obligation supplied in `obligationsToAdd` must not be an unrelated generic
obligation. This mutation is not a generic arbitrary-obligation insertion path.

If an obligation with the same exact logical identity is already admitted, the
caller must omit it from `obligationsToAdd`. Every existing producer path whose
obligation is already admitted uses `obligationsToAdd = []` when invoking
`EstablishOperationalBlockersV1`, including repository-control preflight and any
existing recovery or publication path that invokes this mutation. Existing
cause semantics do not change.

The same obligation ID with incompatible payload is:

```text
INVALID_MUTATION
```

No `WorkItem` is automatically created by this mutation. No obligation is
automatically satisfied by blocker disposition.

For a blocking condition requiring a new obligation, the new `ObligationRef`
and materialized `OperationalBlocker` must become authoritative in the same
`StateRevision`. There must be no authoritative intermediate state where:

```text
a new blocking obligation exists but its corresponding blocker does not
```

or:

```text
a blocker references a not-yet-admitted obligation
```

When a new obligation has the exact M7-B publication-preparation definition,
M2 additionally requires:

```text
blocker source producer == repository-control
M7-B validate_publication_operational_cause accepts the exact cause
M7-B validate_publication_preparation_obligation accepts the obligation
obligationId recomputes under publication-preparation-obligation.v1
obligation and cause run/candidate/qualification/target bindings are exact
```

The publication-preparation obligation and blocker are co-admitted in one
revision. When the exact obligation already exists, `obligationsToAdd == []` as
usual.

When `blocker.source.producer == "mechanical-validation"`, permit only the two
M6 `1.2.0` cause kinds:

```text
gate-a-qualification-not-established
post-publication-integrity-not-established
```

Require exactly:

```text
M6 validate_mechanical_validation_operational_cause accepts exact cause
M6 validate_mechanical_validation_obligation accepts exact obligation

obligationId recomputes through
mechanical-validation-obligation.v1

candidate binding is exact
basis binding is exact
cause and obligation kind agree
workItemId == null
executionId == null
resolutionContracts == []
```

M2 validates the exact M6 producer representation and bindings; it does not
invent, normalize or reinterpret producer cause meaning.

When the exact obligation is not already admitted:

```text
obligationsToAdd == [exact blocking obligation]
```

The obligation and blocker are co-admitted atomically. When the exact obligation
already exists:

```text
obligationsToAdd == []
```

An incompatible same-ID obligation is `INVALID_MUTATION` under the common rule.

Every admitted `OperationalBlocker` must satisfy the accepted M8-B
operational-boundary identity and Operator Action Request contract.

M2 does not invent or normalize an operational blocker identity.

For every blocker it verifies:

```text
operatorRequest ArtifactRef exists and is intact
Operator Action Request runtime shape is valid
OAR/blocker field bindings are exact
BlockerId recomputes under the exact M8-B identity policy selected by OAR.source
```

`basisArtifacts` remain evidence/provenance for the producing condition. They
are not implicitly part of `BlockerId`.

### 5.5 Execution authorization

```ts
type ExecutionCreationRequestBasis =
  | {
      readonly kind: "initial-work";
    }
  | {
      readonly kind: "protocol-retry";
      readonly retryAuthorizationId: ExecutionRetryAuthorizationId;
    }
  | {
      readonly kind: "proven-not-executed";
      readonly priorExecutionId: ExecutionId;
    };

interface AuthorizeExecutionV1 {
  readonly kind: "authorize-execution";
  readonly workItemId: WorkItemId;
  readonly basis: ExecutionCreationRequestBasis;
}
```

Caller does not provide `ExecutionId` or `attemptOrdinal`.

M2 derives them.

Attempt ordinals begin at:

```text
1
```

Identity:

```text
deriveId(
  "execution.v1",
  workItemId,
  decimal attemptOrdinal
)
```

The persisted internal creation basis is exactly one of:

```text
initial-work
protocol-retry
proven-not-executed
operator-replacement
```

For `operator-replacement`, the persisted internal basis is exactly:

```ts
interface OperatorReplacementCreationBasisV1 {
  readonly kind: "operator-replacement";
  readonly priorExecutionId: ExecutionId;
  readonly blockerId: BlockerId;
  readonly operatorResolution: ArtifactRef;
}
```

This basis is created only by the atomic
`AdmitOperatorResolutionV1` replacement path.

It is not accepted through `AuthorizeExecutionV1`.

The presence of a successor Execution carrying a one-shot basis is itself the
append-only proof that the basis was consumed.

There is no mutable `consumed` flag.

### 5.6 Arm dispatch

```ts
interface ArmExecutionDispatchV1 {
  readonly kind: "arm-execution-dispatch";
  readonly executionId: ExecutionId;
  readonly workItemId: WorkItemId;
  readonly ownershipGeneration: OwnershipGeneration;
  readonly revalidationBasis: readonly ArtifactRef[];
  readonly dispatchEvidence: readonly ArtifactRef[];
  readonly recoveryCapability: RecoveryCapabilityRef | null;
}
```

The enclosing mutation artifact itself is the durable:

```text
dispatchIntent
```

for the resulting `ArmedExecutionDispatchRef`.

Successful commit is the exact transition:

```text
AUTHORIZED-NOT-DISPATCHED
→
POSSIBLY-DISPATCHED
```

and the side-effect permission linearization point.

### 5.7 Direct execution outcome

```ts
interface AdmitExecutionOutcomeV1 {
  readonly kind: "admit-execution-outcome";
  readonly outcome:
    | {
        readonly kind: "captured";
        readonly value: CapturedExecutionResult;
      }
    | {
        readonly kind: "technical-failure";
        readonly value: TechnicalExecutionFailure;
      };
}
```

This is used only when the owning executor directly returns a known terminal
capture/failure after an armed dispatch.

For a repository-control publication Execution whose direct M7 capture will be
submitted to `PublicationObservationQualificationRequest`,
`AdmitExecutionOutcomeV1` must commit that exact
`CapturedExecutionResult` before
`AdmitPublicationObservationQualificationV1` may be admitted.

The publication-observation qualification mutation never introduces a
previously unknown execution result.

An execution already routed through uncertainty/recovery is terminalized through
`AdmitExecutionRecoveryV1`, not this mutation.

### 5.8 Uncertainty enrichment

```ts
interface AdmitExecutionUncertaintyV1 {
  readonly kind: "admit-execution-uncertainty";
  readonly unresolved: UnresolvedExecutionRecoveryRef;
}
```

This mutation does not make an execution unresolved.

Arm already did that.

It only enriches the exact armed unresolved execution.

### 5.9 Recovery

```ts
interface AdmitExecutionRecoveryV1 {
  readonly kind: "admit-execution-recovery";
  readonly resolution: ExecutionRecoveryResolution | null;
  readonly lastPending: ReconciliationPendingRef | null;
  readonly blockers: readonly OperationalBlocker[];
  readonly blockerIdsToDispose: readonly BlockerId[];
}
```

Valid shapes are exactly:

```text
PROVEN-NOT-EXECUTED:
    resolution != null
    resolution.classification = PROVEN-NOT-EXECUTED
    lastPending = null

PROVEN-COMPLETED:
    resolution != null
    resolution.classification = PROVEN-COMPLETED
    lastPending = null

UNRESOLVABLE:
    resolution != null
    resolution.classification = UNRESOLVABLE
    exactly its required blocker is present
    lastPending = null

pending-policy-exhausted:
    resolution = null
    lastPending != null
    one exact operational blocker is present
```

`blockerIdsToDispose` may contain only operational blockers whose exact causal
condition is mechanically superseded by the admitted recovery fact.

M2 never chooses this set.

It verifies the supplied disposition is structurally legal.

### 5.10 Assurance-ledger delta

```ts
interface AdmitAssuranceLedgerDeltaV1 {
  readonly kind: "admit-assurance-ledger-delta";
  readonly evaluationContext: GateAEvaluationContext;
  readonly cognitiveAttemptValidations:
    readonly CognitiveAttemptValidationResult[];
  readonly delta: AssuranceLedgerDelta;
}
```

Require:

```text
delta.expectedStateRevision == mutation.baseStateRevision

evaluationContext.authorityEvaluation ArtifactRef exists and is intact

its runner-owned runtime shape is valid

its run/state/candidate/S/P/current/stale campaign-ID bindings equal the exact
evaluationContext
```

Repository-selected/imported campaigns may be registered only from exact
campaigns present in the validated `GateAEvaluationContext`.

For a newly registered imported campaign require:

```text
provenance.kind == repository-imported
originatingRunId == null
candidateId == null
repositoryCommitSha is exact projected repository_commit
```

The same `ReviewCampaignId` plus the same exact campaign payload creates no
duplicate logical fact. The same `ReviewCampaignId` plus an incompatible payload
is `INVALID_MUTATION`.

M2 does not infer currentness. M2 does not construct imported campaigns. M2
validates and adopts the exact M3 result only.

This mutation may atomically establish:

```text
observed repository ReviewCampaignRefs
cognitive-attempt classification facts
EvidenceRefs
FindingRefs
AdjudicationRefs
ReAdjudicationRefs
ObligationDispositionRefs
RepairIntentRefs
DecisionRequestRefs
zero or one AssuranceRepositoryProjectionRef
ObligationRefs
WorkItemRefs
ExecutionRetryAuthorizationRefs
CampaignBlockers
CandidateReviewReadinessRef
CandidateReviewReadiness designation
```

M5 remains producer of its ledger semantics.

For every newly admitted runner-produced `FindingRef`, require:

```text
reviewCampaign exists
reviewCampaign.provenance.kind == runner-produced
candidateId == reviewCampaign.provenance.candidateId
sourceReviewExecutionId resolves by exact string equality to a local cognitive
WorkItem.workItemId
that WorkItem belongs to the same ReviewCampaign
sourceRunnerExecutionId != null
sourceRunnerExecutionId resolves to one Execution of that WorkItem
that exact Execution is the qualifying source occurrence established by the
accepted receipt/evidence basis
```

For every newly admitted repository-imported `FindingRef`, require:

```text
reviewCampaign exists
reviewCampaign.provenance.kind == repository-imported
candidateId == null
sourceRunnerExecutionId == null
sourceReviewExecutionId satisfies the hostile-review EXEC-* lexical contract
no local WorkItem or Execution existence requirement
findingId equals the exact source record finding_id
```

M2 does not interpret finding semantics. An exact duplicate `FindingRef` is
idempotent. The same `findingId` with incompatible source, provenance or content
is `INVALID_MUTATION`. Never fabricate local WorkItem/Execution provenance for
an imported finding.

The validated `authorityEvaluation` preserves every exact
`RepositoryReviewObservationV1`, including each `sourceRecord` and complete
ordered `referencedArtifacts` closure. M2 validates artifact existence and
shape but does not reinterpret M6 mechanical validity or M5 finding semantics.

If `delta.assuranceRepositoryProjectionToEstablish != null`, require:

```text
projection.runId == exact GateARun runId
currentCandidate != null
projection.sourceCandidateId == currentCandidate.candidateId
projection.semanticSubject == currentCandidate.semanticSubject
projection.protocolBundle == evaluationContext.protocolBundle
projection.projection exists and is intact
projection.projection.mediaType == application/json
basisArtifacts is duplicate-free and every item is intact
projectionId recomputes under the exact NIB-S formula
runner-owned projection structure is valid

decoded AssuranceRepositoryProjectionArtifactV1.entries.length >= 1

decoded entries are ordered by exact UTF-8 repositoryPath bytes ascending
and are duplicate-free by exact repositoryPath

every decoded entry.content exists and is intact

every decoded entry.content.repositoryPath == null

every decoded entry.content.mediaType obeys the exact NIB-S 13.0.0
repositoryPath/media-type mapping

no decoded entry targets a forbidden namespace

decoded projection.sourceCandidateId == projection.sourceCandidateId

decoded projection.semanticSubject == projection.semanticSubject

decoded projection.protocolBundle == projection.protocolBundle

no other unconsumed projection exists whose sourceCandidateId ==
    projection.sourceCandidateId
```

M2 admits the projection append-only in the same atomic delta revision. An exact
existing value is idempotent; incompatible same identity or a competing second
unconsumed projection is `INVALID_MUTATION`.

M2 validates structure and integrity only. It does not inspect review semantic
meaning, model-output meaning, whether raw textual bytes are valid JSON,
finding semantics, or challenge semantics.

If `delta.candidateReviewReadiness != null`, require no unconsumed assurance
projection exists for its candidate. Readiness cannot precede exact evidence
materialization into the successor candidate.

Every `OperationalBlocker` in final `delta.blockersToAdd` passes existing M8-B
identity/OAR validation. For an M5 operational blocker require:

```text
source.kind == producer-occurrence
source.producer == assurance-ledger
source.baseStateRevision == delta.expectedStateRevision
```

M2 invents neither producer cause nor blocker. Semantic blockers remain M5-owned
semantic products.

### 5.11 Non-cognitive mechanical validation

```ts
type NonCognitiveMechanicalValidationRequest = Exclude<
  MechanicalValidationRequest,
  CognitiveAttemptValidationRequest
>;

type NonCognitiveMechanicalValidationResult = Exclude<
  MechanicalValidationResult,
  CognitiveAttemptValidationResult
>;

interface AdmitMechanicalValidationObservationV1 {
  readonly kind: "admit-mechanical-validation-observation";
  readonly request: NonCognitiveMechanicalValidationRequest;
  readonly result: NonCognitiveMechanicalValidationResult;
}
```

Cognitive-attempt validation is forbidden here.

It belongs only to `AdmitAssuranceLedgerDeltaV1`.

### 5.12 Gate A qualification

```ts
interface AdmitGateAQualificationV1 {
  readonly kind: "admit-gate-a-qualification";
  readonly qualification: GateAQualificationRef;
}
```

M2 must find an already-admitted passing exact Gate A mechanical validation
observation whose candidate, campaign sets, and evidence match this
qualification.

Let that exact observation be request `Q` and result `R`. Require:

```text
Q.kind == gate-a-qualification
R.requestKind == gate-a-qualification
R.passed == true
Q.runId == exact GateARun
Q.candidate.candidateId == qualification.candidateId
Q.reviewReadiness.candidateId == qualification.candidateId
R.candidateId == qualification.candidateId
R.currentReviewCampaignIds == qualification.currentReviewCampaignIds
R.contributingReviewCampaignIds ==
    qualification.contributingReviewCampaignIds
R.evidence == qualification.validatorEvidence in exact result order
```

Recompute exactly:

```text
qualification.qualificationId ==
deriveId(
  "gate-a-qualification.v1",
  Q.runId,
  qualification.candidateId,
  Q.reviewReadiness.reviewReadinessId,
  decimal R.evidence.length,
  R.evidence[0].sha256,
  R.evidence[1].sha256,
  ...
)
```

The SHA input strings remain canonical lowercase; generic `deriveId` renders
the final digest uppercase. Any mismatch is `INVALID_MUTATION`. M2 does not
invent or normalize the ID.

During successful `AdmitGateAQualificationV1`, for every outstanding
publication-preparation obligation satisfying:

```text
obligation.candidateId == qualification.candidateId
AND obligation qualificationId != qualification.qualificationId
```

append exactly one supersession in the same revision:

```ts
{
  kind: "superseded",
  obligationId: exact old preparation obligation,
  replacementObligationIds: [],
  basisEvidenceIds: [],
  basisArtifacts: exact qualification.validatorEvidence
}
```

Replaying the exact same qualification never supersedes its matching
preparation obligation.

### 5.13 Publication intent

```ts
interface EstablishPublicationIntentV1 {
  readonly kind: "establish-publication-intent";
  readonly intent: PublicationIntentRef;
  readonly publicationObligation: ObligationRef;
  readonly publicationWorkItem: WorkItemRef;
}
```

At most one effective publication intent may exist for one exact
candidate/qualification transition.

Historical intents remain retained.

### 5.13.1 Publication intent identity

M2 recomputes `PublicationIntentRef.publicationIntentId` exactly as:

```text
deriveId(
    "publication-intent.v1",
    runId,
    candidateId,
    qualificationId,
    transition.target.repositoryIdentity,
    transition.target.remoteEndpoint,
    transition.target.refName,
    transition.predecessor.commitSha,
    transition.predecessor.treeSha,
    transition.successor.commitSha,
    transition.successor.treeSha
)
```

Publication intent identity excludes:

```text
StateRevision
ownership generation
timestamp
preparationEvidence
ancestryEvidence ArtifactRef identities
WorkItemId
ExecutionId
```

M2 must recompute and require exact equality.

Replaying an identical preparation for the exact same transition therefore
produces the same logical intent identity. A different predecessor or successor
produces a different intent identity.

### 5.13.2 Publication obligation and WorkItem identities

M2 recomputes the co-admitted identities exactly as:

```text
publicationObligation.obligationId =
deriveId(
    "publication-obligation.v1",
    intent.publicationIntentId
)
```

```text
publicationWorkItem.workItemId =
deriveId(
    "publication-work-item.v1",
    intent.publicationIntentId
)
```

M2 requires:

```text
publicationObligation.runId == intent.runId
publicationObligation.candidateId == intent.candidateId
publicationObligation.reviewCampaignId == null
publicationObligation.definition ArtifactRef exists and is intact

publicationWorkItem.runId == intent.runId
publicationWorkItem.candidateId == intent.candidateId
publicationWorkItem.reviewCampaignId == null
publicationWorkItem.executor == "repository-control"

publicationWorkItem.sourceObligationIds
    == [publicationObligation.obligationId]

publicationWorkItem.operation ArtifactRef exists and is intact

every publicationWorkItem.inputRefs ArtifactRef exists and is intact
publicationWorkItem.inputRefs is duplicate-free
```

The exact runtime schema of:

```text
publicationObligation.definition
publicationWorkItem.operation
```

and the pure binding extractor proving the operation represents the exact
`PublicationIntentRef` belong to M7-B `1.0.0`. M2 requires:

```text
M7-B extract_publication_intent_from_operation(
  publicationWorkItem.operation
) == exact intent
```

GREEN remains blocked until the required Git Dependency Contract exists.

M2 must not infer publication binding merely from:

```text
executor == "repository-control"
candidateId
target
repository path
```

### 5.13.3 Admission preconditions

For `EstablishPublicationIntentV1`, M2 requires all of the following before
admission:

```text
intent.runId == exact GateARun

intent.candidateId == exact currentCandidate.candidateId

intent.qualificationId ==
    exact currently projected gateQualification.qualificationId

intent.transition.target ==
    exact immutable run.publicationTarget

intent.transition.relationship == "fast-forward"

intent.transition.predecessor is ancestor-or-equal to
    intent.transition.successor by accepted M7 evidence

every intent.preparationEvidence ArtifactRef exists and is intact

every intent.transition.ancestryEvidence ArtifactRef exists and is intact

publication obligation/work bindings pass section 5.13.2
```

M2 does not reinterpret Git ancestry evidence.

It validates the construction/reference bindings fixed by NIB-S and M7-B
`1.0.0`.

### 5.13.4 Initial versus replacement intent

Before inserting the new intent bundle, M2 obtains the currently projected
applicable publication intent for the current exact
candidate/qualification:

```text
priorIntent
```

**Case A — no prior intent**

M2 atomically appends in one StateRevision:

```text
intent
publicationObligation
publicationWorkItem
```

No prior publication-obligation supersession is created. Any matching
publication-preparation obligation is handled by section 5.13.5.

**Case B — the exact same intent identity already exists and is currently projected**

M2 rejects the proposal as:

```text
INVALID_MUTATION
```

M2 does not create another StateRevision solely to duplicate the same effective
intent.

**Case C — a different prior intent exists for the same exact current candidate/qualification**

M2 finds its exact co-admitted:

```text
priorPublicationObligation
priorPublicationWorkItem
```

The new intent may replace it automatically only when ALL of these are true:

```text
no PublicationConfirmationRef exists for priorIntent

and every armed Execution in priorPublicationWorkItem is replacement-safe.

Define `replacement-safe(E)` exactly as:

```text
E has an exact terminal PROVEN-NOT-EXECUTED recovery resolution

OR

E has exactly one authoritative PublicationNonApplicationRef
```

Additionally, no prior WorkItem Execution is currently:

```text
unresolved POSSIBLY-DISPATCHED
pending recovery
UNRESOLVABLE without a non-application fact
PROVEN-COMPLETED publication application
confirmed publication producer
progression-superseded uncertain Execution lacking prior exact safe disposition
```

A direct captured result alone is neither safe nor unsafe. Its authoritative
M7 publication qualification decides.

A `TechnicalExecutionFailure` after Arm is not replacement-safe merely because
it is terminal.

A `PublicationNonApplicationRef` does not itself authorize another Execution
for the same WorkItem.
```

If these conditions do not hold, M2 rejects as:

```text
INVALID_MUTATION
```

M2 does not create a blocker inside M2.

M2 does not invent an operator action from an invalid proposal.

If replacement is safe, M2 atomically appends in the SAME StateRevision:

```text
new intent
new publicationObligation
new publicationWorkItem

one exact ObligationDispositionRef {
    kind: "superseded",
    obligationId: priorPublicationObligation.obligationId,
    replacementObligationIds: [
        new publicationObligation.obligationId
    ],
    basisEvidenceIds: [],
    basisArtifacts: intent.preparationEvidence
}
```

M2 requires:

```text
priorPublicationObligation is currently outstanding
```

The supersession disposition is M2 lifecycle plumbing fixed by this brief.

It does not assert repository truth beyond the already validated new
`PublicationIntent` proposal.

The prior intent, prior obligation, prior WorkItem, and prior Executions are
never mutated or deleted.

### 5.13.5 Publication-preparation obligation transition

For every successful `EstablishPublicationIntentV1`, derive the exact matching
publication-preparation obligation identity from:

```text
intent.runId
intent.candidateId
intent.qualificationId
intent.transition.target
exact preparation-obligation definition
```

If no such obligation exists, append no preparation disposition. If it exists
and remains outstanding, atomically append exactly this disposition in the same
StateRevision as the first effective publication-intent bundle:

```ts
{
  kind: "superseded",
  obligationId: preparationObligation.obligationId,
  replacementObligationIds: [
    publicationObligation.obligationId
  ],
  basisEvidenceIds: [],
  basisArtifacts: intent.preparationEvidence
}
```

There is no intermediate revision containing both an effective publication
intent and an outstanding matching preparation obligation.

### 5.14 Publication observation qualification

```ts
interface AdmitPublicationObservationQualificationV1 {
  readonly kind: "admit-publication-observation-qualification";
  readonly request: PublicationObservationQualificationRequest;
  readonly result: PublicationObservationQualificationResult;
}
```

This mutation is the only M2 admission boundary for an M7 publication
observation qualification result.

For every request kind define:

```text
I = request.intent
C = request.candidate
W = exact publication WorkItem co-admitted with I
O = exact publication obligation co-admitted with I
```

M2 requires this common branch before either result branch is admitted:

```text
I exists
I == exact currently projected publicationIntent

C exists
C == exact currentCandidate

C.candidateId == I.candidateId

I.qualificationId ==
    exact currently projected gateQualification.qualificationId

W exists
W == exact publication WorkItem co-admitted with I

W.executor == "repository-control"
W.candidateId == C.candidateId

O exists
O is exact publication obligation co-admitted with I
O is currently outstanding
```

The exact runtime-validated publication operation/input representation and
binding extractor belong to M7-B `1.0.0`. The coding agent may not infer that
binding from repository-control executor identity alone.

#### Executed-publication branch

For:

```text
request.kind == "executed-publication"
```

let:

```text
E = request.executionResult.execution
```

M2 retains all existing executed-publication requirements:

```text
E exists
E has a successful Arm
no progression supersession
request.executionResult already authoritative
W is the exact owning WorkItem
exact runtime M7 binding is established
```

More precisely:

```text
no ExecutionProgressionSupersessionRef exists for E

request.executionResult equals one exact already-authoritative
CapturedExecutionResult for E

that captured result was admitted either:
    directly through AdmitExecutionOutcomeV1
    or
    as the captured recovered outcome of a PROVEN-COMPLETED
    AdmitExecutionRecoveryV1

M2 retains which exact authoritative admission introduced the result; it never
infers direct-versus-recovered provenance from the captured payload.

W == the exact publication WorkItem owning E
```

A recovered captured result remains eligible for ordinary executed-publication
qualification, including confirmation, but it is never eligible to establish
publication non-application.

For:

```text
result.kind = "confirmed"
```

M2 requires:

```text
result.confirmation.publicationIntentId ==
    I.publicationIntentId

result.confirmation.candidateId ==
    C.candidateId

result.confirmation.transition ==
    I.transition

result.publishedView.publicationConfirmationId ==
    result.confirmation.publicationConfirmationId

result.publishedView.candidateId == C.candidateId

result.publishedView.target == I.transition.target

result.publishedView.authority == I.transition.successor
    by exact commit SHA and tree SHA
```

For:

```text
result.kind = "not-applied"
```

M2 requires:

```text
result.nonApplication.publicationIntentId ==
    I.publicationIntentId

result.nonApplication.candidateId ==
    C.candidateId

result.nonApplication.executionId ==
    E.executionId

result.nonApplication.workItemId ==
    W.workItemId

result.nonApplication.dispatchIntent ==
    exact Arm dispatchIntent for E

result.nonApplication.attemptResult ==
    request.executionResult.rawResult

request.executionResult was introduced for E by one exact direct
AdmitExecutionOutcomeV1 whose outcome.kind == "captured"

no AdmitExecutionRecoveryV1 is the authoritative introduction of that captured
result

proof/basis ArtifactRefs intact

M7-B validate_publication_non_application accepts the exact non-application
binding
```

If the direct-outcome provenance conditions fail, M2 rejects the proposed
`not-applied` mutation as `INVALID_MUTATION` and appends no
`PublicationNonApplicationRef`. A captured result introduced by
`AdmitExecutionRecoveryV1` may not be used for this branch.

M2 atomically appends the exact publication-observation qualification
request/result basis and exact `PublicationNonApplicationRef` for this branch.
It appends:

```text
NO PublicationConfirmationRef
NO PublishedRepositoryViewRef
NO publication obligation disposition
```

A `PublicationNonApplicationRef` does not satisfy `O` and does not manufacture
an Execution outcome.

For:

```text
result.kind = "blocked"
```

M1 does not submit this blocked result through
`AdmitPublicationObservationQualificationV1`. It requires
`result.cause.producer == "repository-control"`, binds only the exact already-
determined publication obligation, WorkItem, and optional Execution occurrence
anchors, and asks M8-B to materialize the blocker. M1 then commits that exact
blocker through `EstablishOperationalBlockersV1` with `obligationsToAdd = []`
because the publication obligation is already authoritative. M2 applies its
ordinary M8-B identity/OAR validation and appends no confirmation or published
view. M2 does not interpret the repository-control cause or construct another
blocker.

#### Already-current branch

For:

```text
request.kind == "already-current"
```

M2 requires exactly:

```text
I.transition.predecessor ==
    I.transition.successor

zero Execution exists for W

request.observation.publicationIntentId ==
    I.publicationIntentId

request.observation.candidateId ==
    C.candidateId

request.observation.target ==
    I.transition.target

request.observation.observedAuthority ==
    I.transition.successor
    by exact commit SHA and tree SHA

every observation evidence ArtifactRef intact

M7-B validate_already_current_observation accepts the exact already-current
observation
```

`result.kind = "not-applied"` is invalid for this request kind. The
already-current request may produce `confirmed` but never `not-applied`.
`result.kind = "blocked"` is not used merely because the target changed before
qualification; orchestration declines to submit the stale request and
re-enters preparation instead.

For a confirmed result in either legal branch, M2 recomputes and requires:

```text
result.confirmation.publicationConfirmationId ==
deriveId(
  "publication-confirmation.v1",
  result.confirmation.publicationIntentId
)

result.confirmation.publicationIntentId == I.publicationIntentId
```

M2 then requires M7-B `validate_publication_confirmation_bundle` to accept the
exact intent, request, confirmation and published view, requires all exact
bindings above, and atomically appends in the same `StateRevision`:

```text
exact publication-observation qualification request/result basis
exact PublicationConfirmationRef
exact PublishedRepositoryViewRef identity descriptor
one exact ObligationDispositionRef {
    kind: "satisfied",
    obligationId: O.obligationId,
    basisEvidenceIds: [],
    basisArtifacts: <exact sequence below>
}
```

For `executed-publication`, `basisArtifacts` is the ordered duplicate-free
first-occurrence sequence:

```text
[
    request.executionResult.rawResult,
    ...request.executionResult.runtimeEvidence,
    ...result.confirmation.materialIdentityEvidence
]
```

For `already-current`, `basisArtifacts` is the ordered duplicate-free
first-occurrence sequence:

```text
[
    ...request.observation.evidence,
    ...result.confirmation.materialIdentityEvidence
]
```

M2 requires `O` had no prior disposition. There must never be an authoritative
revision with a new `PublicationConfirmationRef` while `O` remains outstanding.
Only `result.kind = "confirmed"` creates a `PublicationConfirmationRef`.
A captured publication result by itself never establishes publication
confirmation. A blocked publication qualification is a known M7 domain result
and is not an M8 execution-uncertainty classification.

### 5.15 Operator resolution

M2 accepts only an M8-validated state effect.

M2 consumes the NIB-S `OperatorResolutionStateEffect` union unchanged.

The public M2 mutation remains:

```ts
interface AdmitOperatorResolutionV1 {
  readonly kind: "admit-operator-resolution";
  readonly envelope: OperatorResolutionEnvelope;
  readonly effect: OperatorResolutionStateEffect;
}
```

The exact operator-resolution artifact union and the mapping from each accepted
artifact to one of these state effects belong to the M8 NIB-M.

GREEN may not begin until that M8 contract is closed.

M1 does not choose `effect`.

For:

```text
effect.kind = resolve-blocker-only
```

let:

```text
B = exact OperationalBlocker named by envelope.blockerId
R = envelope.resolution
```

M2 requires:

```text
envelope.runId == exact run

B exists
B is currently outstanding
B.kind == operational

R exists as an intact immutable ArtifactRef

the exact OperatorResolutionEnvelope is M8-validated
the exact state effect is M8-validated
```

M2 atomically appends in one StateRevision:

```text
the exact accepted OperatorResolutionEnvelope
the exact target blocker disposition
```

and nothing else merely because that blocker was disposed.

`resolve-blocker-only` does not:

```text
satisfy an obligation
supersede an obligation
create an Execution
create an ExecutionProgressionSupersessionRef
establish preflight
establish reviewer prerequisites
establish publication confirmation
establish mechanical-validation success
create semantic authority
```

The authoritative producer boundary must mechanically re-evaluate any
underlying condition after blocker disposition.

For:

```text
effect.kind = resolve-blocker-and-replace-execution
```

let:

```text
E = exact prior Execution named by effect.priorExecutionId
W = exact authoritative WorkItem for E
B = exact OperationalBlocker named by envelope.blockerId
R = envelope.resolution
```

M2 requires:

```text
envelope.runId == exact run

B exists
B is currently outstanding
B.kind == operational
B.executionId == E.executionId

E exists
E.workItemId == W.workItemId
E is the current WorkItem execution tail

no ExecutionProgressionSupersessionRef already names E as priorExecutionId
no later Execution for W already exists

at least one W.sourceObligationIds member remains outstanding

run is not GATE-A-READY
semantic progression does not prohibit replacement

historical Execution count for W < 5

R exists as an intact immutable ArtifactRef
```

M2 does not interpret `R` as execution truth.

M8 owns validation of the exact operator-resolution artifact union and supplies
the already validated `OperatorResolutionStateEffect`.

M2 derives exactly one successor:

```text
successor.attemptOrdinal = E.attemptOrdinal + 1

successor.executionId =
    deriveId(
        "execution.v1",
        W.workItemId,
        decimal successor.attemptOrdinal
    )

successor.workItemId = W.workItemId
```

M2 constructs exactly one:

```ts
ExecutionProgressionSupersessionRef {
  runId: exact runId,
  workItemId: W.workItemId,
  priorExecutionId: E.executionId,
  successorExecutionId: successor.executionId,
  blockerId: B.blockerId,
  operatorResolution: R,
}
```

The successor's persisted creation basis is exactly:

```ts
{
  kind: "operator-replacement",
  priorExecutionId: E.executionId,
  blockerId: B.blockerId,
  operatorResolution: R,
}
```

M2 atomically appends in one StateRevision:

```text
the exact accepted OperatorResolutionEnvelope
the exact target blocker disposition
the exact ExecutionProgressionSupersessionRef
the exact successor Execution
the exact successor operator-replacement creation basis
```

There is no authoritative intermediate state in which:

```text
the prior Execution is superseded but no successor exists

or

the successor exists without the exact supersession relation
```

Progression supersession does not append:

```text
CapturedExecutionResult
TechnicalExecutionFailure
ExecutionRecoveryResolution
ReconciliationPendingRef
NonExecutionProofRef
RecoveryIndeterminacyRef
```

for the prior Execution merely because replacement was authorized.

### 5.15.1 Execution progression supersession

`ExecutionProgressionSupersessionRef` is append-only.

One prior Execution may have at most one progression supersession.

A supersession:

```text
revokes future campaign-progression authority for the prior Execution
revokes future automatic-recovery eligibility for the prior Execution
preserves the prior Execution in immutable historical state
does not assert any external execution outcome
```

A later result or observation for the superseded prior Execution may remain
available as audit material outside progression authority, but M2 must reject
any new post-supersession mutation that would use it to create authoritative
campaign progression.

A progression supersession is irreversible within the GateARun.

It is never removed when:

```text
the prior executor later returns
the prior provider later reports a result
the successor succeeds
the successor fails
ownership changes
the run resumes
```

### 5.16 Gate A ready

```ts
interface EstablishGateAReadyV1 {
  readonly kind: "establish-gate-a-ready";
  readonly qualificationId: GateAQualificationId;
  readonly publicationConfirmationId: PublicationConfirmationId;
}
```

M2 finds and verifies the exact passing post-publication mechanical validation
fact internally.

No caller-supplied boolean can establish readiness.

## 6. Common commit algorithm

```text
commitAuthoritativeMutation(request):

    verify exact local ownership handle
    verify mutation ArtifactRef exists and is intact

    parse exact GateAStateMutationArtifactV1
    validate with M0

    BEGIN IMMEDIATE authoritative DB

    verify trustworthy run authority

    if durable max generation != request.authority.generation:
        rollback
        return ownership-lost(current generation)

    if exact session/generation does not equal authority:
        rollback
        return ownership-lost(current generation)

    currentRevision = exact current revision

    if request.expectedStateRevision != currentRevision:
        rollback
        return stale-state(currentRevision)

    require mutation.runId == request.runId
    require mutation.baseStateRevision == currentRevision

    validate mutation-specific references
    recompute every M2-owned identity
    validate producer-owned identities through accepted M0/domain contracts
    verify all ArtifactRefs
    validate terminality matrix
    validate retry/capability rules

    determine exact set of new append-only facts

    if zero new authoritative facts:
        reject INVALID_MUTATION("NO_NEW_FACTS")

    nextRevision = currentRevision + 1

    append state_revisions(nextRevision)
    append all mutation facts with introduced_revision = nextRevision

    reconstruct exact resulting snapshot using snapshot/integrity M2
    run complete resulting-state invariant check

    COMMIT

    return committed(nextRevision, snapshot)
```

An exact already-existing object may be referenced again when another new fact
is being admitted.

Same logical ID + different payload is `INVALID_MUTATION`.

Already-authoritative contradictory retained history is `INTEGRITY_FAILURE`.

## 7. Execution authorization algorithm

For WorkItem `W`:

```text
require W exists
require at least one source obligation is outstanding
require run is not GATE-A-READY
require semantic progression does not prohibit new work
require no outstanding OperationalBlocker exists
```

Let existing executions for W be ordered by `attemptOrdinal`.

### Initial

```text
basis = initial-work

require no existing execution for W
ordinal = 1
```

### Protocol retry

```text
basis = protocol-retry(R)

require R exists
require R.workItemId == W
require R.priorExecutionId == current execution tail
require R is not already named by another execution creation basis
require prior execution has exact basis required by R.reason
require prior execution is terminal
```

For:

```text
technical-failure
```

the exact prior `TechnicalExecutionFailure` must exist.

For:

```text
protocol-invalid
```

the exact admitted M6 classification must be `protocol-invalid`, role must be
`initial-reviewer` or `challenge`, and exact validation evidence required by the
authorization must already be authoritative or co-admitted.

A `qualified` attempt cannot back a retry.

### Proven-not-executed

```text
basis = proven-not-executed(E)

require E == current execution tail
require exact terminal recovery resolution for E is PROVEN-NOT-EXECUTED
require no successor execution already consumed that PNE basis
```

### Common

```text
ordinal = current tail ordinal + 1
executionId = deriveId("execution.v1", W, ordinal)

insert execution
insert exact creation basis
```

## 8. Retry hard limits

These are v1 runner safety limits:

```text
attemptOrdinal starts at 1

maximum total historical Executions per WorkItem = 5

maximum automatic technical-failure replacement Executions = 2

maximum protocol-invalid replacement Executions = 1

maximum consecutive PROVEN-NOT-EXECUTED replacement Executions = 2
```

Provider/transport retries below one Pi M4 adapter call do not count.

Operator-authorized replacement does not create a protocol retry authorization
but still counts against the absolute total of five Executions.

No generic operator `"retry anyway"` path exists.

When a limit is exhausted, another `AuthorizeExecutionV1` is invalid.

The owning M5/M8 path must instead establish the exact required operational
blocker.

M2 never manufactures that blocker merely because it rejected an invalid
proposal.

## 9. Arm algorithm

For Execution `E`:

```text
require E exists
require E is the current tail for its WorkItem
require E has no Arm fact
require E has no terminal outcome
require E has no terminal recovery resolution
require E's WorkItem has at least one outstanding source obligation
require no semantic terminal prevents new side effects
require no outstanding OperationalBlocker exists

require mutation.ownershipGeneration == current WriteAuthorityRef.generation
require mutation base revision == exact current revision

require every revalidationBasis ArtifactRef is intact
require every dispatchEvidence ArtifactRef is intact
require recoveryCapability artifact is intact when non-null
```

For an `Execution E` whose `WorkItem W` is a repository-control publication
WorkItem, M2 additionally requires:

```text
snapshot.publicationIntent != null

let I = snapshot.publicationIntent

W is the exact WorkItem co-admitted with I

E.workItemId == W.workItemId

W.candidateId == snapshot.currentCandidate.candidateId

I.candidateId == snapshot.currentCandidate.candidateId

I.qualificationId ==
    snapshot.gateQualification.qualificationId

the exact publication obligation co-admitted with I is outstanding

M7-B extract_publication_intent_from_operation(W.operation) == exact I

recoveryCapability != null
recoveryCapability.executor == repository-control
M7-B validate_publication_recovery_operation accepts
    recoveryCapability.reconciliationOperation against exact I

the Arm revalidation basis equals exactly one
GateAPublicationArmRevalidationV1 ArtifactRef accepted by
M7-B validate_publication_arm_revalidation for I

that binding names:
    exact I
    exact W
    exact snapshot.currentCandidate
    exact snapshot.gateQualification
    exact I.transition.target
    exact I.transition.predecessor
    exact I.transition.successor
    exact successor projection
```

M2 does not independently interpret remote Git state.

M7 establishes repository-domain revalidation evidence.

M2 validates that the exact accepted M7 binding is current, structurally bound
to I, and supplied to the exact current-intent WorkItem/Execution.

M7-B `1.0.0` owns the exact revalidation artifact schema and pure binding-
validation contract.

If `W` belongs to a historical PublicationIntent instead of the exact projected
current one:

```text
ArmExecutionDispatchV1 is INVALID_MUTATION
```

No Arm fact is written.

No uncertainty is created.

No M8 recovery is invoked because the external-effect permission boundary was
never crossed.

On commit:

```text
store Arm fact
store exact mutation artifact as dispatchIntent
```

After commit, the snapshot/integrity M2 brief must reconstruct:

```ts
ArmedExecutionDispatchRef {
  execution: E,
  workItem: W,
  dispatchIntent: exact Arm mutation ArtifactRef,
  dispatchEvidence,
  recoveryCapability,
}
```

and until terminal disposition:

```text
E ∈ snapshot.unresolvedExecutions
```

No later failure to invoke the executor reverses the Arm fact.

## 10. Outcome algorithm

Direct outcome requires:

```text
Arm exists
no ExecutionProgressionSupersessionRef exists for E
no direct terminal outcome exists
no terminal recovery resolution exists
no explicit uncertainty enrichment has transferred disposition to M8
outcome.execution == exact E
```

`captured` and `technical-failure` are mutually exclusive.

Admission terminalizes the execution.

For cognitive captured outcomes, terminal execution does not imply protocol
qualification.

M6/M5 classification follows separately.

## 11. Uncertainty enrichment algorithm

Require:

```text
Arm exists
execution remains unresolved
no ExecutionProgressionSupersessionRef exists for E
no terminal recovery resolution exists

unresolved.execution == armed execution
unresolved.workItem == exact authoritative WorkItem
unresolved.dispatchIntent == exact Arm mutation ArtifactRef

unresolved.dispatchEvidence contains every exact Arm dispatchEvidence item
without modification

any appended evidence is intact

if terminalOutcome != null:
    terminalOutcome.execution == same E
```

At most one executor-origin uncertainty enrichment may be admitted for one
Execution.

Later M8 reconciliation facts use `AdmitExecutionRecoveryV1`.

## 12. Recovery algorithm

### PROVEN-NOT-EXECUTED

```text
require E armed and unresolved
no ExecutionProgressionSupersessionRef exists for E
require M8 resolution binds exact E
append terminal recovery resolution
E leaves unresolved projection
```

It establishes one possible creation basis for one successor execution.

### PROVEN-COMPLETED

```text
require E armed and unresolved
no ExecutionProgressionSupersessionRef exists for E
require recoveredOutcome.execution == E
append terminal recovery resolution
append recovered terminal outcome provenance
E leaves unresolved projection
```

When the recovered outcome belongs to repository publication and
`recoveredOutcome.kind = "captured"`, that exact captured result is thereafter
the authoritative `CapturedExecutionResult` that may be supplied in a
`PublicationObservationQualificationRequest`.

For publication qualification, a recovered captured result may produce
`confirmed` or `blocked`, but it may never produce `not-applied`. M2 rejects a
`not-applied` mutation whose result was introduced by `AdmitExecutionRecoveryV1`;
M1 must fail the recovered `not-applied` path before submitting that mutation.

No second direct-outcome admission is required or permitted for the same
Execution.

Captured and technical-failure recovered outcomes remain distinct.

### UNRESOLVABLE

```text
require E armed and unresolved
no ExecutionProgressionSupersessionRef exists for E
require blocker.executionId == E
append terminal UNRESOLVABLE resolution
append blocker
E leaves unresolved projection
blocker remains outstanding
```

### Pending-policy exhaustion

```text
require lastPending binds E
no ExecutionProgressionSupersessionRef exists for E
require lastPending recovery capability is exact
append pending observation
append exact operational blocker
E remains unresolved
```

A later mechanical recovery may both establish a terminal recovery resolution
and dispose the exact pending blocker in one StateRevision.

## 13. Cognitive-attempt admission

For every supplied `CognitiveAttemptValidationResult`:

```text
execution exists
no ExecutionProgressionSupersessionRef exists for E
execution is cognitive WorkItem execution
captured result is already authoritative
validation capturedResult equals exact authoritative capture
executionRequest.dispatch.execution == E
executionRequest.dispatch.workItem == exact W
prompt/packet/campaign/protocol/role/profile bindings are exact
validation evidence artifacts exist
at most one authoritative classification exists for E
```

For `protocol-invalid`:

```text
role ∈ { initial-reviewer, challenge }
protocolErrors non-empty
qualified classification does not exist
```

If delta establishes a retry authorization from this result, the exact
validation evidence and retry authorization are admitted in the same revision.

For `qualified`:

```text
protocolErrors = []
no retry authorization may cite E
E must be current WorkItem tail
no later Execution may exist
```

The delta must contain the complete schema-v3 receipt EvidenceRef required by
the M5 brief.

M2 validates its structural binding through the accepted M5 receipt-artifact
schema.

There is no durable state:

```text
qualified classification
without its required complete receipt admission
```

## 14. Obligations

One obligation has zero or one terminal disposition.

```text
no disposition → outstanding
satisfied      → terminal satisfied
superseded     → terminal superseded
```

`satisfied` and `superseded` are mutually exclusive.

For supersession:

```text
replacementObligationIds may be empty
replacement IDs must be duplicate-free
every replacement exists or is co-admitted
all belong to same run
source cannot replace itself
resulting complete supersession graph must remain acyclic
```

Outstandingness is direct, not transitive:

```text
outstanding(O) = O has no direct disposition
```

Disposition never automatically:

```text
disposes a blocker
cancels an armed execution
satisfies another obligation
```

## 15. WorkItems

Require:

```text
sourceObligationIds length >= 1
duplicate-free
all source obligations exist/co-admitted
all belong to same run
candidate exists
reviewCampaign exists when non-null
operation and inputRefs exist
executor is exact closed WorkExecutor
```

A WorkItem may source multiple obligations.

One obligation may source multiple WorkItems.

A new Execution is forbidden when every source obligation has a disposition.

An already-armed Execution remains subject to outcome/recovery closure even if
all source obligations are later disposed.

### Publication Intent WorkItems

A PublicationIntent WorkItem is created only through
`EstablishPublicationIntentV1`.

It is never created through:

```text
EstablishReviewCampaignBundleV1
AdmitAssuranceLedgerDeltaV1
generic orchestration invention
```

Exactly one publication WorkItem exists per PublicationIntent.

Exactly one publication obligation exists per PublicationIntent.

Its `sourceObligationIds` contains only that exact publication obligation.

When a later safe publication intent supersedes the prior publication
obligation, any authorized-but-unarmed Execution of the old WorkItem remains
historical and becomes non-dispatchable under the Arm current-intent check.

Obligation supersession does not cancel or manufacture an outcome for an
already-armed Execution.

## 16. Blockers

M2 persists blockers append-only.

A blocker is outstanding iff no internal blocker disposition exists.

Semantic blockers cannot receive same-run disposition.

Operational blockers may be disposed only by:

```text
exact accepted OperatorResolution
or
exact mechanically superseding recovery allowed by its causal blocker kind
```

There is no generic `ResolveBlockerV1`.

Blocker disposition never satisfies its obligation automatically.

Operational-blocker identity is governed by the accepted M8-B
operational-boundary contract.

M2 recognizes exactly two policies:

```text
non-recovery producer blocker
→ occurrence identity
→ includes immutable producer causeDescriptor.sha256
→ includes baseStateRevision

M8 recovery blocker
→ stable causal identity
→ excludes StateRevision and reconciliation episode
```

M2 must not inject `StateRevision`, ownership generation, episode identity,
timestamp, or another occurrence discriminator into a recovery blocker ID.

M2 validates the exact supplied blocker identity; it does not create another
identity policy.

## 17. Semantic terminality matrix

Once any SemanticBlocker has been admitted:

```text
semanticProgressionTerminal = true
```

Forbidden afterward:

```text
new ReviewCampaign
new ordinary WorkItem
new candidate repair
new qualification
new publication intent
Gate A ready
new not-yet-armed semantic side effect
```

Still admissible when causally required to close prior effects:

```text
outcome of already-armed Execution
uncertainty enrichment for already-armed Execution
recovery facts
operational blocker arising from that recovery
operator resolution needed for those operational facts
required evidence/history closure
```

## 18. Gate A ready preconditions

`EstablishGateAReadyV1` is accepted only when all hold:

```text
semanticProgressionTerminal == false
outstanding blockers == []
outstanding obligations == []

exact projected GateAQualification exists
exact projected PublicationConfirmation exists

one admitted post-publication MechanicalValidationResult exists where:
    passed == true
    candidateId == qualification.candidateId
    publicationConfirmationId == exact confirmation
    target == exact confirmed target
    validatedAuthority == exact confirmed successor authority
```

After Gate A ready fact exists, no later campaign-state mutation is accepted.

Read-only load and ownership acquisition remain permitted.

## 19. Example

Cognitive WorkItem `W1` receives:

```text
E1 attemptOrdinal 1
```

E1 is armed, returns a completed response, and is admitted as captured.

M6 classifies it:

```text
protocol-invalid
```

M5 returns one retry authorization `R1`.

One `AdmitAssuranceLedgerDeltaV1` revision atomically admits:

```text
M6 classification(E1)
validation evidence
R1
```

M1 later requests:

```ts
{
  kind: "authorize-execution",
  workItemId: "W1",
  basis: {
    kind: "protocol-retry",
    retryAuthorizationId: "R1",
  },
}
```

M2 creates:

```text
E2
attemptOrdinal = 2
creation basis = R1
```

R1 is now consumed because E2 exists.

E2 is armed.

The process crashes before M4 returns.

On restart E2 is already unresolved from the Arm fact.

M8 proves the provider never executed E2:

```text
PROVEN-NOT-EXECUTED(E2)
```

M2 admits the recovery.

A new authorization creates E3 from the exact PNE basis.

E3 is armed, captured, and M6 classifies it `qualified`.

The M5 delta admits in one revision:

```text
qualified(E3)
complete receipt for W1:
    attempts = [E1, E3]
required EvidenceRef
resulting ledger products
```

E2 is absent from the receipt attempt list because it never reached the
cognitive call boundary.

Its runner history remains authoritative.

## 20. Edge cases

* Wrong `expectedStateRevision`: return `stale-state`; no facts inserted.
* Wrong generation: return `ownership-lost`; no facts inserted.
* Same logical ID with different payload: invalid mutation.
* Exact duplicate mutation against current revision with no new fact:
  `NO_NEW_FACTS`.
* Retry authorization already consumed: invalid mutation.
* PNE basis already consumed: invalid mutation.
* WorkItem has an authorized-not-dispatched tail: no successor may be created.
* Arm attempted twice: invalid mutation.
* Outcome without Arm: invalid mutation.
* Executor uncertain enrichment changes WorkItem or dispatch intent: invalid.
* Qualified cognitive result accompanied by retry authorization: invalid.
* Protocol-invalid result for an unvalidated cognitive role: invalid.
* Supersession introduces cycle: invalid.
* Semantic blocker disposition proposed: invalid.
* Gate A ready with one outstanding obligation: invalid.
* Gate A ready with old/unbound post-publication validation: invalid.
* Operator resolution attempts replacement after absolute Execution cap:
  invalid.
* Already-armed execution may still close after semantic terminality.
* Artifact reference exists in JSON but CAS bytes fail verification:
  integrity/invocation failure before commit.
* `candidate.materialization` differs from `sealedCandidate.materialization`:
  `INVALID_MUTATION`.
* Repaired `sealedCandidate` parent differs from `currentCandidate`:
  `INVALID_MUTATION`.
* Repaired `sealedCandidate` RepairIntent differs from candidate RepairIntent:
  `INVALID_MUTATION`.
* Candidate names a missing/non-admitted RepairIntent: `INVALID_MUTATION`.
* RepairIntent `candidateId` differs from `currentCandidate`: `INVALID_MUTATION`.
* The same RepairIntent already produced one CandidateRevision:
  `INVALID_MUTATION`.
* Repaired sealed-candidate `materializationEvidence` does not retain exact
  source candidate materialization: `INVALID_MUTATION`.
* Repaired sealed-candidate `materializationEvidence` does not retain exact
  RepairIntent.approvedPatch: `INVALID_MUTATION`.

* Non-C0 candidate has both provenance IDs null: `INVALID_MUTATION`.
* Candidate/sealed-candidate repair or projection provenance differs:
  `INVALID_MUTATION`.
* Candidate names a missing or wrong-parent repair/projection:
  `INVALID_MUTATION`.
* Assurance-only subject differs from parent/projection: `INVALID_MUTATION`.
* RepairIntent or projection already produced a candidate: `INVALID_MUTATION`.
* A second unconsumed projection for one source candidate: `INVALID_MUTATION`.
* Readiness is non-null while its candidate has an unconsumed projection:
  `INVALID_MUTATION`.

## 21. Constraints

* One successful mutation equals one StateRevision.
* One StateRevision may establish multiple related facts atomically.
* No mutation updates or deletes history.
* M2 does not schedule WorkItems.
* M2 does not infer M3 currentness.
* M2 does not reclassify M6 cognitive results.
* M2 does not derive M5 semantic conclusions.
* M2 does not derive M8 recovery classifications.
* No authorization is represented by a mutable consumed flag.
* Arm is irreversible.
* External-effect uncertainty is conservative after Arm.
* No execution branch may fork from a non-tail Execution.
* No campaign mutation may bypass ownership generation and StateRevision CAS.

## 22. Integration

M1 always constructs and seals one exact mutation artifact before calling:

```ts
const committed = await campaignState.commitAuthoritativeMutation({
  runId,
  authority,
  expectedStateRevision: snapshot.stateRevision,
  mutation: mutationRef,
});
```

On:

```text
committed
```

M1 discards its prior snapshot and uses only the returned snapshot.

On:

```text
stale-state
ownership-lost
```

M1 does not replay the external effect that motivated the mutation.

It reloads or re-enters the appropriate orchestration/recovery path.

For repository publication, the required admission order is:

```text
conditional-ref-update:
    Arm exact publication Execution
    ↓
    obtain direct or recovered CapturedExecutionResult
    ↓
    make that CapturedExecutionResult authoritative
    ↓
    M7 qualify_publication_observation({ kind: executed-publication, ... })
    ↓
    if result == not-applied:
        require the exact result was introduced directly through
            AdmitExecutionOutcomeV1
        reject recovered-origin results as INVALID_MUTATION
    ↓
already-current:
    EstablishPublicationIntentV1
    ↓
    obtain one fresh exact read-only target observation
    ↓
    M7 qualify_publication_observation({ kind: already-current, ... })
    ↓
AdmitPublicationObservationQualificationV1(request, result)
↓
if confirmed:
    PublicationConfirmationRef + PublishedRepositoryViewRef
    + exact publication-obligation satisfied disposition in the same revision
if not-applied:
    PublicationNonApplicationRef only
    + no confirmation/view/disposition
if blocked:
    no publication-observation qualification mutation;
    exact repository-control cause → M8-B materialization
    → EstablishOperationalBlockersV1
```

A `not-applied` result is valid only for the executed-publication request kind.
M1 may not commit a bare publication confirmation/view pair or a confirmation
whose exact publication obligation remains outstanding.

The snapshot/integrity M2 brief performs all resulting-state reconstruction and
invariant validation before SQLite commit.

## 23. Protocol-v8 semantic mutation boundary

Keep exactly two independent authority dimensions:

```text
WriteAuthorityRef
→ exclusive authority for one GateARun mutation stream

AdmissionAuthorityRefV1
→ exclusive live semantic-dispatch authority for one exact QLEK
```

One never substitutes for the other. T2 and T3 require both. T1, T4, and T5 do
not require GateARun write authority because they do not mutate a GateARun.

Every new protocol-v8 semantic operation below is legal only for the exact
published P8 bundle. While `formal/verification.yaml` selects P6, none becomes
active campaign behavior. P6 remains current, P7 remains permanently inactive,
and P8 remains inactive.

## 24. T2 AuthorizeSemanticExecutionV1

Use the exact M0 representation:

```ts
interface AuthorizeSemanticExecutionV1 {
  readonly kind:
    "authorize-semantic-execution";
  readonly workItemId:
    WorkItemId;
  readonly basis:
    ExecutionCreationRequestBasis;
  readonly semanticQuestion:
    ValidatedSemanticQuestionRefV1;
  readonly admissionAuthority:
    AdmissionAuthorityRefV1;
}
```

Accept only existing public bases `initial-work`, `protocol-retry`, and
`proven-not-executed`. Do not add `operator-replacement` to the public semantic
T2 basis.

In the same run mutation transaction require exactly:

```text
exact local GateARun WriteAuthority is held
exact local AdmissionAuthority lock handle is held
admissionAuthority.domainId == local SemanticAuthorityDomainId
admissionAuthority.epoch == exact current epoch
admissionAuthority.generation == exact latest grant for (K, current epoch)
semanticQuestion.qlek == admissionAuthority.qlek
semanticQuestion binding/evidence intact
WorkItem exists
WorkItem is an exact native P8 semantic WorkItem under the later M5 operation contract
no consumable Admission exists for K
no SemanticAdmissionConflict exists for K
no protocol-valid completion awaits reconciliation
no unvalidated captured semantic completion exists for K
no unresolved semantic hazard exists for K
no other non-retired local unarmed semantic trajectory exists for K
all ordinary AuthorizeExecutionV1 outer rules hold
```

The future synchronized M5 operation schema supplies the exact marker/binding
for a native P8 semantic WorkItem. M2 does not infer it from role strings and
does not design the M5 schema here.

When `semanticQuestion.boundCandidateRevisionId != null`, require that exact
CandidateRevision to exist in this GateARun and require
`WorkItem.candidateId == semanticQuestion.boundCandidateRevisionId`. Do not
require currentness at T2; fresh candidate currentness belongs to T3.

Atomically insert in one exact run `StateRevision`:

```text
one new ExecutionRef
its ordinary exact execution-creation basis
one SemanticExecutionBindingRefV1
```

No visible authoritative revision may contain a new P8 semantic Execution
without its binding. Never write authority generation into
`SemanticExecutionBindingRefV1`.

If exact reconstructed state already contains one non-retired native unarmed
semantic trajectory for K, do not create a sibling. Expose it through
`SemanticQuestionStateV1.resumableUnarmedExecution`, even when it belongs to
another GateARun. Progressing it requires separate normal WriteAuthority for the
owning run. A busy owning-run lock never permits another same-K Execution.

A never-Armed local semantic Execution ceases to be resumable only when retained
authoritative run history makes it definitively non-dispatchable before Arm,
including authoritative pre-Arm supersession, irreversible run termination, or
candidate-bound current-candidate inequality. Temporary blockage and absence of
a live process owner do not retire it.

## 25. Generic semantic authorization exclusion

Preserve `AuthorizeExecutionV1` unchanged for historical/current
non-P8-semantic execution, including P8 initial-reviewer execution. Once the
active M5 operation contract identifies a WorkItem as a native P8 semantic
question:

```text
generic AuthorizeExecutionV1
→ INVALID_MUTATION
```

Only `AuthorizeSemanticExecutionV1` may create its Execution.

Existing generic operator replacement must reject any prior Execution carrying a
P8 `SemanticExecutionBindingRefV1`:

```text
AdmitOperatorResolutionV1
+
semantic prior Execution
+
request to atomically create operator-replacement successor
→ INVALID_MUTATION
```

C9-B defines no semantic operator-replacement mechanism. Exact PNE and
protocol-authorized semantic retry remain possible only through lawful T2
bases.

## 26. T3 ArmSemanticExecutionDispatchV1

Use the exact M0 representation. In one single `BEGIN IMMEDIATE` authoritative
transaction require:

```text
all ordinary ArmExecutionDispatchV1 preconditions
SemanticExecutionBinding(E,K) exists
no prior normal Arm(E)
no prior SemanticArmBinding(E,...)
exact local AdmissionAuthority handle is held
authority domain == local domain
authority K == binding K
authority epoch == current domain epoch
authority generation == latest durable generation for (K, epoch)
no Admission claim currently permits reuse
no conflict exists
no captured semantic completion awaits validation
no protocol-valid semantic completion awaits reconciliation
no unresolved semantic hazard from another trajectory exists
E is the exact retained native unarmed trajectory for K
```

When the binding contains non-null bound candidate C, read exact authoritative
`GateARun.currentCandidate` inside this same transaction and require
`currentCandidate.candidateId == C`. Combine this direct check with the expected
run `StateRevision` CAS. Never accept caller-provided currentness. This one
linearization point prevents candidate advance between check and Arm.

When the binding is candidate-independent, perform no candidate-ID equality
check. WorkItem candidate provenance remains occurrence provenance and never
becomes QLEK identity.

One successful transaction introduces in the same run revision:

```text
ordinary M2 Arm(E)
+
SemanticArmBinding(E, K, local domainId, current epoch, authority generation)
```

No partial state is legal. The commit durably establishes
`POSSIBLY-DISPATCHED` and semantic sampling hazard before M4 may cross its
external effect boundary.

After successful T3 commit, release the exact process-local QLEK lock handle
before returning normal success. Durable grant and Arm binding remain. On
`stale-state`, `ownership-lost`, or another non-commit result, do not silently
release or reuse authority; the caller explicitly invokes
`releaseAdmissionAuthority` when abandoning the attempt.

If an Execution has `SemanticExecutionBindingRefV1`:

```text
generic ArmExecutionDispatchV1
→ INVALID_MUTATION
```

Only `ArmSemanticExecutionDispatchV1` may Arm it.

## 27. AdmitProtocolV8SemanticValidationV1

Admit exact future M6 output through:

```ts
interface AdmitProtocolV8SemanticValidationV1 {
  readonly kind:
    "admit-protocol-v8-semantic-validation";
  readonly result:
    ProtocolV8SemanticValidationResultV1;
}
```

Require:

```text
exact execution exists
SemanticExecutionBinding exists
result.qlek == exact binding.qlek
exact normal Arm exists
exact SemanticArmBinding exists
exact CapturedExecutionResult exists
no TechnicalExecutionFailure exists
result.execution equals exact retained execution locator
all validationEvidence intact
no prior incompatible P8 semantic validation exists for E
```

For `protocol-valid`, additionally require exact equality between
`result.semanticQuestionBinding` and `binding.semanticQuestionBinding`, plus
intact candidate, execution-receipt-v4, origin-witness-v1, and binding artifacts.
M2 verifies exact authoritative M6 provenance, retained-history agreement, and
artifact integrity only. It never decides whether those artifacts semantically
prove V.

A protocol-invalid authoritative result means a completed semantic response
exists and deterministic P8 validation established no protocol-valid candidate.
It clears hazard for exact E but does not itself authorize another Execution;
T2 still requires the exact owning M5 retry/replacement basis.

A protocol-valid result does not create SemanticAdmission. It creates mandatory
T4 reconciliation. Until T4 completes, K is non-consumable and same-K resampling
is forbidden. This mutation is run-local authoritative history and increments
the exact owning GateARun `StateRevision`.

## 28. T4 ReconcileSemanticCompletion

T4 requires no GateARun WriteAuthority and writes only global semantic history.
Implement exactly:

```text
resolve exact local SemanticExecutionBinding(E,K)
require exact authoritative P8 semantic validation for E
require classification == protocol-valid

acquire exact K lock non-blocking
if BUSY:
    return busy(K)

BEGIN IMMEDIATE authoritative DB

re-read exact execution, binding, SemanticArmBinding, captured result,
protocol-valid validation, and global semantic state K
require every immutable ref intact

incoming = exact SemanticAdmissionRecordV1 from M6 validation
W = exact M6-validated origin witness artifact

if no existing admission claim for K:
    insert incoming claim and first origin witness atomically
    COMMIT
    release K lock
    return admitted

if exact same admissionId exists:
    require exact semanticCandidate SHA equality
    require exact semanticQuestionBinding SHA equality
    append exact witness only when absent
    COMMIT only when a new fact exists; otherwise ROLLBACK read-equivalent transaction
    release K lock
    return converged(witnessAdded)

if one or more different admissionIds exist:
    require same admissionId never maps to different candidate bytes
    require same K never maps to incompatible semantic-question-binding bytes
    require same candidate bytes never map to incompatible admissionId
    insert incoming claim if new
    insert incoming witness if new
    append every distinct canonical conflict pair:
        lower admissionId → admissionA
        higher admissionId → admissionB
    select no winner
    COMMIT
    release K lock
    return conflict
```

T4 never checks whether the originating candidate is still current. A lawfully
Armed old-candidate protocol-valid completion reconciles into exact old K.

Same K/same V produces one admission, zero or more additional lawful witnesses,
no new admission, and no resampling. Same K/different V retains every claim,
appends canonical conflicts, sets consumability to null, and selects no first,
last, majority, model, or current-run winner.

T4 increments no GateARun `StateRevision`.

## 29. T5 semantic merge effects

Persistence/ownership owns T5 coordination and transaction boundaries. Within
that exact transaction, mutation semantics are:

```text
append every new external hazard clearance
append every new external unresolved hazard
append every external unarmed trajectory as audit-only provenance

for every validated external admission:
    merge with exact T4 same-K/same-V/different-V rules
    union exact lawful witnesses

for every pending protocol-valid completion:
    reconcile through the exact T4 admission/conflict algorithm

append every required canonical conflict pair
```

Imported unarmed trajectories never become local Executions, never enter
`semantic_execution_bindings`, and never become armable. Same-K/same-V imported
history retains one admission and unions witnesses. Same admissionId requires
exact candidate and semantic-question-binding SHA equality; different candidate
bytes are `IDENTITY-HASH-COLLISION` / integrity failure. Same K plus the same
candidate bytes but an incompatible admissionId is semantic identity integrity
failure, not winner selection. Same-K/different-V creates conflicts and no
winner.

T5 transfers no receipt ownership, `reused_executions[]`,
`supporting_executions[]`, or ReviewCampaign provenance. Origin witnesses retain
their original execution and domain. T5 increments no GateARun `StateRevision`.

## 30. Hazard effects and crash behavior

For exact local Armed semantic Execution E, hazard clears only through exact
PROVEN-NOT-EXECUTED recovery, exact `TechnicalExecutionFailure`, exact
authoritative protocol-invalid validation, or protocol-valid validation plus its
corresponding admission and lawful origin witness. The technical branch is
lawful because accepted M4-A positively proves no completed semantic response.

Never clear hazard from timeout, process death, missing response, MAYBE-SENT,
unknown, UNRESOLVABLE, operator acknowledgement, progression supersession,
candidate staleness, run termination, root change, or Admission absence.

Preserve exactly:

```text
T2 crash after commit before T3
→ Execution + binding remain
→ no Arm and no hazard
→ later T1 returns same resumable unarmed Execution

T3 crash after commit
→ normal Arm + SemanticArmBinding remain
→ hazard blocks fresh same-K sampling

captured response crash before M6 validation
→ captured result remains
→ validation-required; no resampling

protocol-valid validation crash before T4
→ validation remains
→ reconciliation-required; no resampling

T4 crash before commit
→ no partial Admission/witness; retry T4

T4 crash after commit
→ exact claims/witnesses/conflicts reconstruct
→ retry converges idempotently
```

## 31. Existing behavior and module dependencies

Do not reinterpret `AuthorizeExecutionV1`, `ArmExecutionDispatchV1`, P6
classification, P6 execution receipt v3, current retry semantics, recovery, or
publication except for exact native-P8 semantic generic-path exclusions above.
P8 initial-reviewer execution remains outside C1 single-admission semantics.

Do not modify the Pi M4 Dependency Contract. QLEK remains runner-owned metadata
outside the Pi adapter surface. Later M1 owns scheduling and cross-run ownership
orchestration; later M5 owns semantic-question derivation/operation marking and
qualification; later M6 owns QLEK recomputation, P8 completion validation and
external-history validation; M7 owns CandidateView construction; M8 owns
operator/recovery policy. C9-B designs none of those internal algorithms.
